from __future__ import annotations

import inspect
import json
import math
from collections.abc import Callable
from functools import lru_cache
from typing import (
    TYPE_CHECKING,
    Annotated,
    Any,
    ClassVar,
)

import mcp_types
import pydantic_core
from mcp.shared.tool_name_validation import validate_and_warn_tool_name
from mcp_types import (
    CallToolResult,
    ContentBlock,
    Icon,
    TextContent,
    ToolAnnotations,
    ToolExecution,
)
from mcp_types import Tool as MCPTool
from pydantic import (
    BaseModel,
    Field,
    PrivateAttr,
    PydanticSchemaGenerationError,
    model_validator,
)
from pydantic.json_schema import SkipJsonSchema

from fastmcp.exceptions import ToolError
from fastmcp.utilities.authorization import AuthCheck
from fastmcp.utilities.components import FastMCPComponent
from fastmcp.utilities.json_schema import is_object_schema
from fastmcp.utilities.logging import get_logger
from fastmcp.utilities.prefab import (
    is_prefab_app,
    is_prefab_component,
    prefab_app_from_component,
)
from fastmcp.utilities.tasks import TaskConfig
from fastmcp.utilities.types import (
    Audio,
    File,
    Image,
    NotSet,
    NotSetT,
    get_cached_typeadapter,
)

if TYPE_CHECKING:
    from fastmcp.tools.function_tool import FunctionTool
    from fastmcp.tools.tool_transform import ArgTransform, TransformedTool

# Re-export from function_tool module

logger = get_logger(__name__)

_JSONABLE_ADAPTER = get_cached_typeadapter(Any)


def _default_title(name: str) -> str:
    """Derive a display title from a tool name.

    The MCP spec says clients should fall back to `name` for display when
    `title` is absent, but some clients (e.g. ChatGPT) instead drop the tool
    entirely. Always emitting a title avoids depending on that fallback.
    """
    return name.replace("_", " ").replace("-", " ").title()


def default_serializer(data: Any) -> str:
    return _JSONABLE_ADAPTER.dump_json(data, fallback=str).decode()


@lru_cache(maxsize=5000)
def _get_json_serializer(annotation: Any) -> pydantic_core.SchemaSerializer:
    """Build a serializer that follows the real JSON serialization contract.

    `ser_json_inf_nan="constants"` keeps non-finite floats as NaN/Infinity JSON
    tokens instead of silently rewriting them to null, so the tokens that reach
    the wire can be rejected at the JSON boundary (see `_reject_nonfinite`).
    The schema is the annotation's own, so custom serializers and explicit
    per-model policies keep control of their output.
    """
    return pydantic_core.SchemaSerializer(
        get_cached_typeadapter(annotation).core_schema,
        config={"ser_json_inf_nan": "constants"},
    )


def _reject_nonfinite(value: Any, path: str = "$") -> None:
    """Raise ToolError if a non-finite float survived JSON serialization.

    JSON cannot represent NaN or Infinity. A non-finite float in the parsed
    output means the value would reach the client as an invalid JSON literal
    (or be silently rewritten to null by stricter serializers). Values the
    serialization contract legitimately converted — custom serializers or
    explicit per-model `ser_json_inf_nan` policies — never appear here.
    """
    if isinstance(value, float) and not math.isfinite(value):
        raise ToolError(
            f"Tool result contains a non-finite float ({value!r}) at {path}; "
            "JSON cannot represent NaN or Infinity"
        )
    if isinstance(value, dict):
        for key, item in value.items():
            _reject_nonfinite(item, f"{path}.{key}")
    elif isinstance(value, list | tuple):
        for index, item in enumerate(value):
            _reject_nonfinite(item, f"{path}[{index}]")


def _serialize_to_jsonable(data: Any, annotation: Any = Any) -> Any:
    """Serialize through the real JSON serialization contract.

    The value is serialized to JSON and parsed back, so the output is exactly
    what would go on the wire. JSON cannot represent NaN or Infinity: rather
    than letting them be silently rewritten to null, any non-finite float that
    survives serialization is rejected. Falls back for unsupported annotations.
    """
    if (
        annotation is inspect.Signature.empty
        or annotation is None
        or annotation is Any
        or annotation is ...
        or isinstance(annotation, str)
    ):
        serializer = _get_json_serializer(Any)
    else:
        try:
            serializer = _get_json_serializer(annotation)
        except PydanticSchemaGenerationError:
            serializer = _get_json_serializer(Any)

    payload = serializer.to_json(data)
    value = json.loads(payload)
    # Only walk the structure when a NaN/Infinity token was emitted; the
    # substring check keeps clean results on the cheap path.
    if b"NaN" in payload or b"Infinity" in payload:
        _reject_nonfinite(value)
    return value


class ToolResult(BaseModel):
    _raw_mcp_result: CallToolResult | None = PrivateAttr(default=None)

    content: list[ContentBlock] = Field(
        description="List of content blocks for the tool result"
    )
    structured_content: dict[str, Any] | None = Field(
        default=None, description="Structured content matching the tool's output schema"
    )
    meta: dict[str, Any] | None = Field(
        default=None, description="Runtime metadata about the tool execution"
    )
    is_error: bool = Field(
        default=False,
        description="Whether this result represents a tool execution error. "
        "When True, it maps to CallToolResult.is_error so the error is returned "
        "to the client rather than raised.",
    )

    def __init__(
        self,
        content: list[ContentBlock] | Any | None = None,
        structured_content: dict[str, Any] | Any | None = None,
        meta: dict[str, Any] | None = None,
        is_error: bool = False,
    ):
        if content is None and structured_content is None:
            raise ValueError("Either content or structured_content must be provided")
        elif content is None:
            content = structured_content

        converted_content: list[ContentBlock] = _convert_to_content(result=content)

        if structured_content is not None:
            # Convert Prefab types to their wire-format envelope before
            # generic serialization, so the renderer gets the right shape.
            if is_prefab_app(structured_content):
                structured_content = _prefab_to_json(structured_content)
            elif is_prefab_component(structured_content):
                structured_content = _prefab_to_json(
                    prefab_app_from_component(structured_content)
                )

            try:
                structured_content = _serialize_to_jsonable(structured_content)
            except pydantic_core.PydanticSerializationError as e:
                logger.error(
                    f"Could not serialize structured content. If this is unexpected, set your tool's output_schema to None to disable automatic serialization: {e}"
                )
                raise
            if not isinstance(structured_content, dict):
                raise ValueError(
                    "structured_content must be a dict or None. "
                    f"Got {type(structured_content).__name__}: {structured_content!r}. "
                    "Tools should wrap non-dict values based on their output_schema."
                )

        super().__init__(
            content=converted_content,
            structured_content=structured_content,
            meta=meta,
            is_error=is_error,
        )

    @classmethod
    def from_mcp_result(cls, result: CallToolResult) -> ToolResult:
        """Wrap a protocol result while preserving its exact wire representation."""
        tool_result = cls(
            content=result.content,
            structured_content=result.structured_content,
            meta=result.meta,
            is_error=result.is_error,
        )
        tool_result._raw_mcp_result = result
        return tool_result

    def to_mcp_result(
        self,
    ) -> (
        list[ContentBlock] | tuple[list[ContentBlock], dict[str, Any]] | CallToolResult
    ):
        if self._raw_mcp_result is not None:
            return self._raw_mcp_result

        # An error result must round-trip through CallToolResult so isError
        # reaches the client; the plain content/tuple returns can't carry it.
        if self.meta is not None or self.is_error:
            return CallToolResult(
                structured_content=self.structured_content,
                content=self.content,
                is_error=self.is_error,
                _meta=self.meta,  # type: ignore[call-arg]  # _meta is Pydantic alias for meta field
            )
        if self.structured_content is None:
            return self.content
        return self.content, self.structured_content


class RawStructuredToolResult(ToolResult):
    """A proxied result whose structured value need not be an object."""

    structured_content: Any = None

    def __init__(
        self,
        content: list[ContentBlock],
        structured_content: Any,
        meta: dict[str, Any] | None = None,
        is_error: bool = False,
    ) -> None:
        # The proxy already received wire-format content from the backend.
        # ToolResult's constructor intentionally rejects non-object values for
        # ordinary tools; the wire handler wraps these for legacy clients.
        BaseModel.__init__(
            self,
            content=content,
            structured_content=structured_content,
            meta=meta,
            is_error=is_error,
        )

    def to_mcp_result(self) -> CallToolResult:
        # Serialize the current public fields so response middleware edits are
        # reflected on the wire, including when it uses model_copy().
        return CallToolResult(
            content=self.content,
            structured_content=self.structured_content,
            is_error=self.is_error,
            _meta=self.meta,  # type: ignore[call-arg]
        )


class InputRequiredToolResult(ToolResult):
    """The full result of a single multi-round-trip leg (SEP-2322).

    The protocol is stateless: each MRTR leg is a complete request→response
    cycle. When a guard tool returns an `InputRequiredResult` from its body to
    ask the client for input, that ask is the *legitimate result* of this tool
    call — not a pause, not an error, not a third control-flow outcome. FastMCP
    wraps it in this `ToolResult` subclass so it flows through the middleware
    chain as an ordinary return value: `call_next(...)` returns it, default
    middleware completes normally on the leg, and middleware authors can
    identify an ask with a simple `isinstance(result, InputRequiredToolResult)`
    check.

    Invariant: the wrapped `InputRequiredResult` is never serialized as tool
    content. `content` is always empty; the wire handler (`_on_call_tool`)
    reads `.input_required` and returns it to the runner as the
    `input_required` result. Do not read `.content` / `.structured_content` on
    this subclass — they carry nothing.
    """

    input_required: mcp_types.InputRequiredResult = Field(
        description="The client-input request this leg resolved to (SEP-2322)"
    )

    def __init__(self, input_required: mcp_types.InputRequiredResult) -> None:
        # Bypass ToolResult's content-conversion __init__: an input-required
        # leg carries no tool content (see the invariant above), and
        # `input_required` is a required field ToolResult.__init__ can't set.
        BaseModel.__init__(
            self,
            content=[],
            structured_content=None,
            meta=None,
            is_error=False,
            input_required=input_required,
        )


class Tool(FastMCPComponent):
    """Internal tool registration info."""

    KEY_PREFIX: ClassVar[str] = "tool"

    return_type: Annotated[SkipJsonSchema[Any], Field(exclude=True)] = None
    parameters: Annotated[
        dict[str, Any], Field(description="JSON schema for tool parameters")
    ]
    output_schema: Annotated[
        dict[str, Any] | None, Field(description="JSON schema for tool output")
    ] = None
    annotations: Annotated[
        ToolAnnotations | None,
        Field(description="Additional annotations about the tool"),
    ] = None
    execution: Annotated[
        ToolExecution | None,
        Field(description="Task execution configuration (SEP-1686)"),
    ] = None
    auth: Annotated[
        SkipJsonSchema[AuthCheck | list[AuthCheck] | None],
        Field(description="Authorization checks for this tool", exclude=True),
    ] = None
    timeout: Annotated[
        float | None,
        Field(
            description="Execution timeout in seconds. If None, no timeout is applied."
        ),
    ] = None

    @model_validator(mode="after")
    def _validate_tool_name(self) -> Tool:
        """Validate tool name according to MCP specification (SEP-986)."""
        validate_and_warn_tool_name(self.name)
        return self

    def to_mcp_tool(
        self,
        **overrides: Any,
    ) -> MCPTool:
        """Convert the FastMCP tool to an MCP tool."""
        # Title precedence follows the effective (post-override) values, so a
        # caller renaming or re-annotating a tool doesn't get a stale title.
        name = overrides.get("name", self.name)
        annotations = overrides.get("annotations", self.annotations)
        if isinstance(annotations, dict):
            annotations = ToolAnnotations(**annotations)

        if self.title:
            title = self.title
        elif annotations and annotations.title:
            title = annotations.title
        else:
            title = _default_title(name)

        mcp_tool = MCPTool(
            name=name,
            title=overrides.get("title", title),
            description=overrides.get("description", self.description),
            input_schema=overrides.get("inputSchema", self.parameters),
            output_schema=overrides.get("outputSchema", self.output_schema),
            icons=overrides.get("icons", self.icons),
            annotations=annotations,
            execution=overrides.get("execution", self.execution),
            _meta=overrides.get(  # type: ignore[call-arg]  # _meta is Pydantic alias for meta field
                "_meta", self.get_meta()
            ),
        )

        if (
            self.task_config.supports_tasks()
            and "execution" not in overrides
            and not self.execution
        ):
            mcp_tool.execution = ToolExecution(task_support=self.task_config.mode)

        return mcp_tool

    @classmethod
    def from_function(
        cls,
        fn: Callable[..., Any],
        *,
        name: str | None = None,
        version: str | int | None = None,
        title: str | None = None,
        description: str | None = None,
        icons: list[Icon] | None = None,
        tags: set[str] | None = None,
        annotations: ToolAnnotations | None = None,
        output_schema: dict[str, Any] | NotSetT | None = NotSet,
        meta: dict[str, Any] | None = None,
        task: bool | TaskConfig | None = None,
        timeout: float | None = None,
        auth: AuthCheck | list[AuthCheck] | None = None,
        run_in_thread: bool | None = None,
    ) -> FunctionTool:
        """Create a Tool from a function."""
        from fastmcp.tools.function_tool import FunctionTool

        return FunctionTool.from_function(
            fn=fn,
            name=name,
            version=version,
            title=title,
            description=description,
            icons=icons,
            tags=tags,
            annotations=annotations,
            output_schema=output_schema,
            meta=meta,
            task=task,
            timeout=timeout,
            auth=auth,
            run_in_thread=run_in_thread,
        )

    async def run(self, arguments: dict[str, Any]) -> ToolResult:
        """
        Run the tool with arguments.

        This method is not implemented in the base Tool class and must be
        implemented by subclasses.

        `run()` can EITHER return a list of ContentBlocks, or a tuple of
        (list of ContentBlocks, dict of structured output).

        A tool that requests client input (SEP-2322 multi-round-trip) does so by
        returning an `InputRequiredResult` from its body; the run machinery wraps
        that in an `InputRequiredToolResult` — a `ToolResult` subclass — so it
        stays inside the declared `ToolResult` result type and flows through the
        middleware chain as an ordinary result (see `FunctionTool.run`).
        """
        raise NotImplementedError("Subclasses must implement run()")

    def convert_result(self, raw_value: Any) -> ToolResult:
        """Convert a raw result to ToolResult.

        Handles ToolResult passthrough and converts raw values using the tool's
        attributes (output_schema) for proper conversion.
        """
        if isinstance(raw_value, ToolResult):
            return raw_value

        if isinstance(raw_value, CallToolResult):
            return ToolResult.from_mcp_result(raw_value)

        if is_prefab_app(raw_value):
            return _prefab_to_tool_result(
                raw_value,
                fastmcp_app_name=_get_fastmcp_app_name(self),
            )
        if is_prefab_component(raw_value):
            return _prefab_to_tool_result(
                prefab_app_from_component(raw_value),
                fastmcp_app_name=_get_fastmcp_app_name(self),
            )

        content = _convert_to_content(raw_value)

        # Bytes can't be represented as structured JSON content
        if isinstance(raw_value, bytes):
            return ToolResult(content=content)

        is_content_result = isinstance(
            raw_value, ContentBlock | Audio | Image | File
        ) or (
            isinstance(raw_value, list | tuple)
            and any(
                isinstance(item, ContentBlock | Audio | Image | File)
                for item in raw_value
            )
        )

        # Skip structured content for ContentBlock types only if no output_schema
        # (if output_schema exists, MCP SDK requires structured_content)
        if self.output_schema is None and is_content_result:
            return ToolResult(content=content)

        try:
            structured = _serialize_to_jsonable(raw_value, self.return_type)
        except (pydantic_core.PydanticSerializationError, UnicodeDecodeError) as e:
            if self.output_schema is not None:
                # The declared output schema obligates structured content
                # (the MCP SDK's client-side validation rejects the result
                # without it), so a silent content-only fallback would report
                # success while breaking that contract.
                raise ToolError(
                    f"Could not serialize the return value of tool {self.name!r} "
                    f"for its output schema: {e}. If this is unexpected, set the "
                    "tool's output_schema to None to disable automatic "
                    "serialization."
                ) from e
            return ToolResult(content=content)

        if not is_content_result:
            content = _convert_to_content(structured)

        if self.output_schema is None:
            # No schema - only use structured_content for dicts
            if isinstance(structured, dict):
                return ToolResult(content=content, structured_content=structured)
            return ToolResult(content=content)

        # Has output_schema - wrap if x-fastmcp-wrap-result is set
        wrap_result = self.output_schema.get("x-fastmcp-wrap-result")
        return ToolResult(
            content=content,
            structured_content={"result": structured} if wrap_result else structured,
            meta={"fastmcp": {"wrap_result": True}} if wrap_result else None,
        )

    async def _run(self, arguments: dict[str, Any]) -> ToolResult:
        """Server entry point for tool execution.

        The server calls this method instead of ``run()`` directly so that
        subclasses can customize dispatch. For example, ``FastMCPProviderTool``
        overrides this to delegate to child-server middleware.
        """
        result = await self.run(arguments)
        return self._mark_non_object_result(result)

    def _mark_non_object_result(self, result: ToolResult) -> ToolResult:
        """Mark structured content declared by a non-object output schema.

        Legacy MCP clients require object structured content, so the wire
        handler wraps a `RawStructuredToolResult` under `result` to match the
        wrapper it advertises for non-object schemas.
        """
        if (
            isinstance(result, RawStructuredToolResult | InputRequiredToolResult)
            or result.structured_content is None
            or self.output_schema is None
            or is_object_schema(self.output_schema)
        ):
            return result
        fastmcp_meta = result.meta.get("fastmcp") if result.meta else None
        if isinstance(fastmcp_meta, dict) and fastmcp_meta.get("wrap_result") is True:
            return result
        return RawStructuredToolResult(
            content=result.content,
            structured_content=result.structured_content,
            meta=result.meta,
            is_error=result.is_error,
        )

    @classmethod
    def from_tool(
        cls,
        tool: Tool | Callable[..., Any],
        *,
        name: str | None = None,
        title: str | NotSetT | None = NotSet,
        description: str | NotSetT | None = NotSet,
        tags: set[str] | None = None,
        annotations: ToolAnnotations | NotSetT | None = NotSet,
        output_schema: dict[str, Any] | NotSetT | None = NotSet,
        meta: dict[str, Any] | NotSetT | None = NotSet,
        transform_args: dict[str, ArgTransform] | None = None,
        transform_fn: Callable[..., Any] | None = None,
    ) -> TransformedTool:
        from fastmcp.tools.tool_transform import TransformedTool

        tool = cls._ensure_tool(tool)

        return TransformedTool.from_tool(
            tool=tool,
            transform_fn=transform_fn,
            name=name,
            title=title,
            transform_args=transform_args,
            description=description,
            tags=tags,
            annotations=annotations,
            output_schema=output_schema,
            meta=meta,
        )

    @classmethod
    def _ensure_tool(cls, tool: Tool | Callable[..., Any]) -> Tool:
        """Coerce a callable into a Tool, respecting @tool decorator metadata."""
        if isinstance(tool, Tool):
            return tool

        from fastmcp.decorators import get_fastmcp_meta
        from fastmcp.tools.function_tool import FunctionTool, ToolMeta

        fmeta = get_fastmcp_meta(tool)
        if isinstance(fmeta, ToolMeta):
            return FunctionTool.from_function(tool, metadata=fmeta)

        return cls.from_function(tool)

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.component.type": "tool",
            "fastmcp.provider.type": "LocalProvider",
        }


def _convert_to_single_content_block(
    item: Any,
) -> ContentBlock:
    if isinstance(item, ContentBlock):
        return item

    if isinstance(item, Image):
        return item.to_image_content()

    if isinstance(item, Audio):
        return item.to_audio_content()

    if isinstance(item, File):
        return item.to_resource_content()

    if isinstance(item, str):
        return TextContent(type="text", text=item)

    if isinstance(item, bytes):
        try:
            return TextContent(type="text", text=item.decode("utf-8"))
        except UnicodeDecodeError:
            import base64

            return TextContent(type="text", text=base64.b64encode(item).decode("ascii"))

    return TextContent(type="text", text=default_serializer(item))


_PREFAB_TEXT_FALLBACK = "[Rendered Prefab UI]"


def _get_tool_resolver(app_name: str | None = None) -> Callable[..., str] | None:
    """Get the Prefab peer-reference resolver bound to an app name."""
    try:
        from fastmcp.apps.app import _make_resolver

        return _make_resolver(app_name)
    except ImportError:
        return None


def _prefab_to_json(app: Any, fastmcp_app_name: str | None = None) -> dict[str, Any]:
    """Serialize a PrefabApp, addressing its peer-tool references by identity.

    The resolver writes each reference as ``__<hash>_<local_name>``, and the
    identity behind it is recorded in the payload's meta so that servers
    can re-address the reference on the way out without losing track of
    what it points at.
    """
    from fastmcp.server.providers.prefab_payload import annotate_payload_identities

    data = app.to_json(tool_resolver=_get_tool_resolver(fastmcp_app_name))
    return annotate_payload_identities(data)


def _get_fastmcp_app_name(tool: Tool) -> str | None:
    """Read the FastMCPApp name from a tool's metadata, if present."""
    meta = tool.meta
    if not meta:
        return None
    fastmcp_meta = meta.get("fastmcp")
    if isinstance(fastmcp_meta, dict):
        app = fastmcp_meta.get("app")
        if isinstance(app, str):
            return app
    return None


def _prefab_to_tool_result(app: Any, fastmcp_app_name: str | None = None) -> ToolResult:
    """Convert a PrefabApp to a FastMCP ToolResult."""
    return ToolResult(
        content=[TextContent(type="text", text=_PREFAB_TEXT_FALLBACK)],
        structured_content=_prefab_to_json(app, fastmcp_app_name=fastmcp_app_name),
    )


def _convert_to_content(
    result: Any,
) -> list[ContentBlock]:
    """Convert a result to a sequence of content objects."""

    if result is None:
        return []

    if not isinstance(result, (list | tuple)):
        return [_convert_to_single_content_block(result)]

    # If all items are ContentBlocks, return them as is
    if all(isinstance(item, ContentBlock) for item in result):
        return result

    # If any item is a ContentBlock, convert non-ContentBlock items to TextContent
    # without aggregating them
    if any(isinstance(item, ContentBlock | Image | Audio | File) for item in result):
        return [
            _convert_to_single_content_block(item)
            if not isinstance(item, ContentBlock)
            else item
            for item in result
        ]
    # If none of the items are ContentBlocks, aggregate all items into a single TextContent
    return [TextContent(type="text", text=default_serializer(result))]


__all__ = ["InputRequiredToolResult", "Tool", "ToolResult"]
