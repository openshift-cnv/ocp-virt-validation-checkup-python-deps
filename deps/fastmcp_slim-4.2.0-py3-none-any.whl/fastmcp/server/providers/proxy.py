"""ProxyProvider for proxying to remote MCP servers.

This module provides the `ProxyProvider` class that proxies components from
a remote MCP server via a client factory. It also provides proxy component
classes that forward execution to remote servers.
"""

from __future__ import annotations

import base64
import inspect
import json
import time
import warnings
from collections.abc import Awaitable, Callable, Sequence
from copy import deepcopy
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, Generic, Literal, TypeVar, cast

import anyio
import httpx2
import mcp_types
from mcp import ClientSession
from mcp.client.client import _evicting_message_handler
from mcp.server.connection import Connection
from mcp.server.context import ServerRequestContext
from mcp.shared.exceptions import MCPError
from mcp.shared.inbound import x_mcp_header_map
from mcp_types import (
    METHOD_NOT_FOUND,
    BlobResourceContents,
    ElicitRequestFormParams,
    TextResourceContents,
)
from mcp_types.version import MODERN_PROTOCOL_VERSIONS
from pydantic import ValidationError
from pydantic.networks import AnyUrl

from fastmcp._warnings import FastMCPDeprecationWarning
from fastmcp.client.client import Client, SDKServer, _connection_failure
from fastmcp.client.elicitation import ElicitResult, create_elicitation_callback
from fastmcp.client.logging import LogMessage, create_log_callback
from fastmcp.client.roots import RootsList, create_roots_callback
from fastmcp.client.sampling import create_sampling_callback
from fastmcp.client.telemetry import client_span
from fastmcp.client.transports import ClientTransportT
from fastmcp.client.transports.base import TransportOptions
from fastmcp.exceptions import ResourceError, ToolError
from fastmcp.mcp_config import MCPConfig
from fastmcp.prompts import Message, Prompt, PromptResult
from fastmcp.prompts.base import InputRequiredPromptResult, PromptArgument
from fastmcp.resources import Resource, ResourceTemplate
from fastmcp.resources.base import (
    InputRequiredResourceResult,
    ResourceContent,
    ResourceResult,
)
from fastmcp.resources.template import forward_uri
from fastmcp.server.context import Context
from fastmcp.server.dependencies import fastmcp_request_ctx, get_context
from fastmcp.server.middleware import CallNext, Middleware, MiddlewareContext
from fastmcp.server.providers.addressing import is_app_tool_with_identity
from fastmcp.server.providers.aggregate import ProviderErrorStrategy
from fastmcp.server.providers.base import Provider
from fastmcp.server.server import FastMCP
from fastmcp.telemetry import inject_trace_context
from fastmcp.tools.base import (
    InputRequiredToolResult,
    RawStructuredToolResult,
    Tool,
    ToolResult,
)
from fastmcp.utilities.components import FastMCPComponent, get_fastmcp_metadata
from fastmcp.utilities.json_schema import is_object_schema
from fastmcp.utilities.logging import get_logger
from fastmcp.utilities.tasks import TaskConfig
from fastmcp.utilities.versions import VersionSpec, version_sort_key

if TYPE_CHECKING:
    from pathlib import Path

    from fastmcp.client.transports import ClientTransport
    from fastmcp.server.extensions import ServerExtension

logger = get_logger(__name__)

# Type alias for client factory functions
ClientFactoryT = Callable[[], Client] | Callable[[], Awaitable[Client]]
ProxyIdentity = Literal["proxy", "upstream"]


class _ForwardingClientSession(ClientSession):
    """A session that does not enforce the backend's declared output schema.

    `ClientSession.call_tool` normally validates a tool's structured content
    against the output schema the backend advertised, raising if they disagree.
    That check belongs to whoever consumes the result. A proxy only relays it,
    and the end client runs the same check for itself, so enforcing it mid-path
    turns a backend's schema bug into a proxy error and hides the real response.
    """

    async def validate_tool_result(
        self, name: str, result: mcp_types.CallToolResult
    ) -> None:
        return None


# Default proxy-backend connection settings: relay results without policing
# the backend's output schema, and forward eligible caller headers upstream
# without inheriting frontend-owned MCP transport state.
PROXY_TRANSPORT_OPTIONS = TransportOptions(
    session_class=_ForwardingClientSession,
    forward_incoming_headers=True,
)


def _with_proxy_transport_options(
    options: TransportOptions | None,
) -> TransportOptions:
    """Layer proxy-owned settings onto options supplied by another client layer."""
    return replace(
        options or PROXY_TRANSPORT_OPTIONS,
        session_class=PROXY_TRANSPORT_OPTIONS.session_class,
    )


#: Transport-level failures that can escape a backend connection attempt.
#: `Client._connect` wraps most connect failures in a ``RuntimeError("Client
#: failed to connect: ...")``, but a transport can also surface an httpx or
#: anyio stream error directly. Every proxy entry point that opens a backend
#: connection normalizes these into an ``MCPError`` so callers see a protocol
#: error instead of a raw transport exception.
_PROXY_TRANSPORT_CAUSES: tuple[type[Exception], ...] = (
    TimeoutError,
    httpx2.HTTPError,
    anyio.ClosedResourceError,
    anyio.EndOfStream,
    anyio.BrokenResourceError,
)
_PROXY_TRANSPORT_ERRORS: tuple[type[Exception], ...] = (
    RuntimeError,
    *_PROXY_TRANSPORT_CAUSES,
)


def _has_transport_cause(error: RuntimeError) -> bool:
    cause = error.__cause__
    while cause is not None:
        if isinstance(cause, _PROXY_TRANSPORT_CAUSES):
            return True
        cause = cause.__cause__
    return False


def _proxy_upstream_error(error: Exception) -> MCPError:
    """Report an unreachable backend the same way however the failure arrived.

    Depending on where the dead connection is noticed, the proxy sees either
    FastMCP's own `RuntimeError("Client failed to connect: ...")` or the raw
    transport error underneath it. Both describe one thing — the proxy could
    not reach its upstream — so both are presented identically rather than
    leaking the race into the message the front client reads.
    """
    return MCPError(
        code=mcp_types.INTERNAL_ERROR,
        message=str(_connection_failure(error)),
    )


# Request `_meta` keys that describe one negotiated MCP connection. They never
# cross the proxy: a modern backend session stamps its own negotiated values on
# every request, and a handshake-era backend must not receive them at all.
_CONNECTION_META_KEYS = frozenset(
    {
        mcp_types.PROTOCOL_VERSION_META_KEY,
        mcp_types.CLIENT_INFO_META_KEY,
        mcp_types.CLIENT_CAPABILITIES_META_KEY,
    }
)


def _forwardable_request_meta(ctx: Context | None) -> dict[str, Any] | None:
    """Frontend request metadata that may cross onto the backend connection.

    This is the proxy's one sanctioned read of the inbound request's `_meta`:
    progress tokens, tracing, task, and application metadata pass through,
    while connection-owned keys (`_CONNECTION_META_KEYS`) are dropped because
    they describe the frontend connection, not the backend one.
    """
    request_context = ctx.request_context if ctx is not None else None
    if request_context is None or not request_context.meta:
        return None
    forwarded = {
        key: value
        for key, value in request_context.meta.items()
        if key not in _CONNECTION_META_KEYS
    }
    return forwarded or None


def _forwardable_server_meta(
    meta: dict[str, Any] | None,
    identity: ProxyIdentity = "proxy",
) -> dict[str, Any]:
    """Backend result metadata that may cross onto the frontend connection.

    Connection-owned keys never cross. The backend's ``serverInfo`` stamp is an
    identity decision at the response boundary: under the default ``"proxy"``
    identity it is dropped so the gateway's own seam stamps the gateway
    identity, and under ``"upstream"`` it is preserved so terminal results keep
    advertising the backend, matching what discovery advertised.
    """
    forwarded = {
        key: value
        for key, value in (meta or {}).items()
        if key not in _CONNECTION_META_KEYS
    }
    if identity != "upstream":
        forwarded.pop(mcp_types.SERVER_INFO_META_KEY, None)
    return forwarded


def _session_request_meta(
    meta: dict[str, Any] | None,
) -> mcp_types.RequestParamsMeta | None:
    """Adapt forwardable metadata for a direct backend-session call.

    Direct session calls bypass the high-level client mixins, so trace context
    is injected here, matching what the mixins do on the legacy client paths.
    """
    return cast(
        "mcp_types.RequestParamsMeta | None", inject_trace_context(meta) or None
    )


async def _relay_read_resource(
    client: Client, uri: str, ctx: Context | None
) -> mcp_types.ReadResourceResult | mcp_types.InputRequiredResult:
    """Read a backend resource, surfacing a guard ask rather than driving it.

    Mirrors `ProxyTool.run`: on a modern backend the low-level session is used
    so an `InputRequiredResult` (SEP-2322) comes back as a result for the parent
    to forward, instead of the high-level client trying to answer it here — the
    proxy has no back-channel to the real user, so driving it fails outright.
    The inbound request's continuation state travels down so the backend guard
    sees the client's answers on its own `ctx.input_responses`.
    """
    meta = _forwardable_request_meta(ctx)
    if client.protocol_version not in MODERN_PROTOCOL_VERSIONS:
        return await client.read_resource_mcp(uri, meta=meta)
    return await client._await_with_session_monitoring(
        client.session.read_resource(
            uri,
            meta=_session_request_meta(meta),
            input_responses=ctx.input_responses if ctx else None,
            request_state=ctx.request_state if ctx else None,
            allow_input_required=True,
        )
    )


def _stash_proxy_request_context(client: Client, ctx: Context) -> None:
    """Stash the proxy's ``RequestContext`` on a ``ProxyClient`` before a backend call.

    Every proxy component (tool, resource, template, prompt) must call this
    before relaying to its backend so the forwarding handlers can restore the
    proxy's request context before relaying a server-initiated request
    (roots/sampling/elicitation) back to the proxy's client. Required for every
    proxy client: under SDK v2 an in-memory backend shares this event loop, so a
    handler's ``get_context()`` would otherwise resolve to the backend context
    and the server-initiated request would hang until timeout.

    We stash a ``(RequestContext, weakref[FastMCP])`` tuple — never a ``Context``
    instance — because ``Context`` properties are themselves ContextVar-dependent
    and would resolve stale values in the receive loop.
    """
    if isinstance(client, ProxyClient):
        client._proxy_rc_ref[0] = (
            ctx.request_context,
            ctx._fastmcp,  # weakref to FastMCP, not the Context
        )


class ProxyInitializeMiddleware(Middleware):
    """Deprecated middleware for forwarding instructions during initialization."""

    def __init__(self, proxy: FastMCPProxy) -> None:
        warnings.warn(
            "`ProxyInitializeMiddleware` is deprecated and will be removed in a "
            "future release. `FastMCPProxy` now installs "
            "`ProxyMetadataMiddleware` automatically.",
            FastMCPDeprecationWarning,
            stacklevel=2,
        )
        self.proxy = proxy

    async def on_initialize(
        self,
        context: MiddlewareContext[mcp_types.InitializeRequest],
        call_next: CallNext[
            mcp_types.InitializeRequest,
            mcp_types.InitializeResult | None,
        ],
    ) -> mcp_types.InitializeResult | None:
        client = await self.proxy._get_client()
        upstream_instructions: str | None = None
        try:
            if isinstance(client, ProxyClient):
                ctx = context.fastmcp_context
                if ctx is not None:
                    client._proxy_rc_ref[0] = (
                        ctx.request_context,
                        ctx._fastmcp,
                    )
            async with client:
                # Entering the context already ran connect-time negotiation.
                # `initialize()` returns the handshake result on a legacy backend,
                # but raises on a modern (server/discover) backend, which has no
                # InitializeResult. That mismatch only arises when an explicit
                # `mode=` pins the backend to a different era than this legacy
                # front (the era-mirroring default keeps the two in lockstep, so
                # a legacy front always reaches a legacy backend here). Skip the
                # handshake-only call when the backend negotiated the modern era.
                if client.protocol_version not in MODERN_PROTOCOL_VERSIONS:
                    await client.initialize()
                    # Capture the upstream's instructions while the session is
                    # live; `initialize_result` clears once the context exits.
                    init_result = client.initialize_result
                    if init_result is not None:
                        upstream_instructions = init_result.instructions
        except MCPError:
            raise
        except _PROXY_TRANSPORT_ERRORS as error:
            raise _proxy_upstream_error(error) from error

        result = await call_next(context)

        # Forward the upstream server's instructions unless the proxy defines its
        # own. `instructions` is part of the MCP InitializeResult and is meant to
        # steer the model, so a proxy that dropped it would silently degrade any
        # downstream consumer relying on upstream guidance.
        if (
            result is not None
            and self.proxy.instructions is None
            and upstream_instructions is not None
        ):
            result.instructions = upstream_instructions

        return result


# -----------------------------------------------------------------------------
# Proxy Component Classes
# -----------------------------------------------------------------------------


class ProxyTool(Tool):
    """A Tool that represents and executes a tool on a remote server."""

    task_config: TaskConfig = TaskConfig(mode="forbidden")
    _backend_name: str | None = None
    _identity: ProxyIdentity = "proxy"

    def __init__(
        self,
        client_factory: ClientFactoryT,
        *,
        identity: ProxyIdentity = "proxy",
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._client_factory = client_factory
        self._identity = identity

    async def _get_client(self) -> Client:
        """Gets a client instance by calling the sync or async factory."""
        client = self._client_factory()
        if inspect.isawaitable(client):
            client = cast(Client, await client)
        return client

    def model_copy(self, **kwargs: Any) -> ProxyTool:
        """Override to preserve _backend_name when name changes."""
        update = kwargs.get("update", {})
        if "name" in update and self._backend_name is None:
            # First time name is being changed, preserve original for backend calls
            update = {**update, "_backend_name": self.name}
            kwargs["update"] = update
        return super().model_copy(**kwargs)

    @classmethod
    def from_mcp_tool(
        cls,
        client_factory: ClientFactoryT,
        mcp_tool: mcp_types.Tool,
        *,
        identity: ProxyIdentity = "proxy",
    ) -> ProxyTool:
        """Factory method to create a ProxyTool from a raw MCP tool schema."""
        return cls(
            client_factory=client_factory,
            identity=identity,
            name=mcp_tool.name,
            title=mcp_tool.title,
            description=mcp_tool.description,
            parameters=mcp_tool.input_schema,
            annotations=mcp_tool.annotations,
            output_schema=mcp_tool.output_schema,
            icons=mcp_tool.icons,
            meta=mcp_tool.meta,
            tags=get_fastmcp_metadata(mcp_tool.meta).get("tags", []),
            execution=mcp_tool.execution,
        )

    async def run(
        self,
        arguments: dict[str, Any],
        context: Context | None = None,
    ) -> ToolResult:
        """Executes the tool by making a call through the client."""
        backend_name = self._backend_name or self.name
        with client_span(
            f"tools/call {backend_name}",
            "tools/call",
            backend_name,
            tool_name=backend_name,
        ) as span:
            span.set_attribute("fastmcp.provider.type", "ProxyProvider")
            client = await self._get_client()
            async with client:
                ctx = context or get_context()
                _stash_proxy_request_context(client, ctx)
                # Forward the inbound request's hop-safe `_meta` (trace
                # context, progress token, etc.) to the backend. Task
                # submission is a first-class params field rather than context
                # state, so there is no separate task-metadata injection here.
                meta = _forwardable_request_meta(ctx)

                if client.protocol_version in MODERN_PROTOCOL_VERSIONS:
                    # Modern backend: call the session directly (not
                    # `call_tool_mcp`, which would *drive* a multi-round-trip ask
                    # to completion on this proxy). A guard tool's
                    # `InputRequiredResult` (SEP-2322) must instead surface as a
                    # result so the parent's middleware and wire seam own the
                    # round. Forward the inbound request's continuation state
                    # down so the backend guard tool sees the client's answers
                    # on its own `ctx.input_responses` / `ctx.request_state`.
                    request_meta = _session_request_meta(meta)
                    # SEP-2243: a modern backend rejects a `tools/call` whose
                    # `x-mcp-header` argument is not mirrored into an `Mcp-Param-*`
                    # header. The SDK client emits those headers only for tools it
                    # has listed (it caches the annotation map on `list_tools`),
                    # but a proxied call goes straight to `call_tool` on a fresh
                    # session. Seed the session's map from the backend tool's
                    # advertised schema so the header is emitted and the call is
                    # accepted; an unannotated schema yields an empty map and no
                    # headers, matching the client's own behavior.
                    header_map = x_mcp_header_map(self.parameters)
                    if header_map:
                        client.session._x_mcp_header_maps[backend_name] = header_map
                    result = await client._await_with_session_monitoring(
                        client.session.call_tool(
                            name=backend_name,
                            arguments=arguments,
                            meta=request_meta,
                            # Forward upstream progress the same way the legacy
                            # `call_tool_mcp` path does — without this handler a
                            # backend tool's `ctx.report_progress()` is dropped
                            # on modern proxy calls.
                            progress_callback=client._progress_handler,
                            input_responses=ctx.input_responses,
                            request_state=ctx.request_state,
                            allow_input_required=True,
                        )
                    )
                    # A backend ask round-trips into an InputRequiredToolResult
                    # so the parent's middleware observes it and the parent's
                    # wire handler unwraps it (era-gated on the parent's own
                    # connection).
                    if isinstance(result, mcp_types.InputRequiredResult):
                        return InputRequiredToolResult(result)
                    tool_result = cast("mcp_types.CallToolResult", result)
                else:
                    # Legacy backend: the multi-round-trip result type does not
                    # exist there, so keep the original path.
                    tool_result = await client.call_tool_mcp(
                        name=backend_name, arguments=arguments, meta=meta
                    )
            # Pass an upstream error result through faithfully rather than
            # collapsing it into a raised ToolError — this preserves the
            # backend's content (including non-text and structured content),
            # and the client still raises on isError by default.
            # Preserve backend's meta (includes task metadata for background tasks)
            structured_content = tool_result.structured_content
            meta = _forwardable_server_meta(tool_result.meta, self._identity) or None
            has_structured_content = (
                "structured_content" in tool_result.model_fields_set
            )
            if has_structured_content and (
                not isinstance(structured_content, dict)
                or (
                    self.output_schema is not None
                    and not is_object_schema(self.output_schema)
                )
            ):
                return RawStructuredToolResult(
                    content=tool_result.content,
                    structured_content=structured_content,
                    meta=meta,
                    is_error=tool_result.is_error,
                )

            return ToolResult(
                content=tool_result.content,
                structured_content=structured_content,
                meta=meta,
                is_error=tool_result.is_error,
            )

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.provider.type": "ProxyProvider",
            "fastmcp.proxy.backend_name": self._backend_name or self.name,
        }


class ProxyResource(Resource):
    """A Resource that represents and reads a resource from a remote server."""

    task_config: TaskConfig = TaskConfig(mode="forbidden")
    _cached_content: ResourceResult | None = None
    _backend_uri: str | None = None
    _identity: ProxyIdentity = "proxy"

    def __init__(
        self,
        client_factory: ClientFactoryT,
        *,
        _cached_content: ResourceResult | None = None,
        identity: ProxyIdentity = "proxy",
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._client_factory = client_factory
        self._cached_content = _cached_content
        self._identity = identity

    async def _get_client(self) -> Client:
        """Gets a client instance by calling the sync or async factory."""
        client = self._client_factory()
        if inspect.isawaitable(client):
            client = cast(Client, await client)
        return client

    def model_copy(self, **kwargs: Any) -> ProxyResource:
        """Override to preserve _backend_uri when uri changes."""
        update = kwargs.get("update", {})
        if "uri" in update and self._backend_uri is None:
            # First time uri is being changed, preserve original for backend calls
            update = {**update, "_backend_uri": str(self.uri)}
            kwargs["update"] = update
        return super().model_copy(**kwargs)

    @classmethod
    def from_mcp_resource(
        cls,
        client_factory: ClientFactoryT,
        mcp_resource: mcp_types.Resource,
        *,
        identity: ProxyIdentity = "proxy",
    ) -> ProxyResource:
        """Factory method to create a ProxyResource from a raw MCP resource schema."""

        return cls(
            client_factory=client_factory,
            identity=identity,
            uri=mcp_resource.uri,
            name=mcp_resource.name,
            title=mcp_resource.title,
            description=mcp_resource.description,
            mime_type=mcp_resource.mime_type or "text/plain",
            icons=mcp_resource.icons,
            annotations=mcp_resource.annotations,
            meta=mcp_resource.meta,
            tags=get_fastmcp_metadata(mcp_resource.meta).get("tags", []),
            task_config=TaskConfig(mode="forbidden"),
        )

    async def read(self) -> ResourceResult:
        """Read the resource content from the remote server."""
        if self._cached_content is not None:
            return self._cached_content

        backend_uri = self._backend_uri or str(self.uri)
        with client_span(
            "resources/read",
            "resources/read",
            backend_uri,
            resource_uri=backend_uri,
        ) as span:
            span.set_attribute("fastmcp.provider.type", "ProxyProvider")
            client = await self._get_client()
            ctx = get_context()
            async with client:
                _stash_proxy_request_context(client, ctx)
                result = await _relay_read_resource(client, backend_uri, ctx)
            if isinstance(result, mcp_types.InputRequiredResult):
                return InputRequiredResourceResult(result)
            if not result.contents:
                raise ResourceError(
                    f"Remote server returned empty content for {backend_uri}"
                )

            # Process all items in the result list, not just the first one
            contents: list[ResourceContent] = []
            for item in result.contents:
                if isinstance(item, TextResourceContents):
                    contents.append(
                        ResourceContent(
                            content=item.text,
                            mime_type=item.mime_type,
                            meta=item.meta,
                        )
                    )
                elif isinstance(item, BlobResourceContents):
                    contents.append(
                        ResourceContent(
                            content=base64.b64decode(item.blob),
                            mime_type=item.mime_type,
                            meta=item.meta,
                        )
                    )
                else:
                    raise ResourceError(f"Unsupported content type: {type(item)}")

            return ResourceResult(
                contents=contents,
                meta=_forwardable_server_meta(result.meta, self._identity) or None,
            )

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.provider.type": "ProxyProvider",
            "fastmcp.proxy.backend_uri": self._backend_uri or str(self.uri),
        }


class ProxyTemplate(ResourceTemplate):
    """A ResourceTemplate that represents and creates resources from a remote server template."""

    task_config: TaskConfig = TaskConfig(mode="forbidden")
    _backend_uri_template: str | None = None
    _identity: ProxyIdentity = "proxy"

    def __init__(
        self,
        client_factory: ClientFactoryT,
        *,
        identity: ProxyIdentity = "proxy",
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._client_factory = client_factory
        self._identity = identity

    async def _get_client(self) -> Client:
        """Gets a client instance by calling the sync or async factory."""
        client = self._client_factory()
        if inspect.isawaitable(client):
            client = cast(Client, await client)
        return client

    def model_copy(self, **kwargs: Any) -> ProxyTemplate:
        """Override to preserve _backend_uri_template when uri_template changes."""
        update = kwargs.get("update", {})
        if "uri_template" in update and self._backend_uri_template is None:
            # First time uri_template is being changed, preserve original for backend
            update = {**update, "_backend_uri_template": self.uri_template}
            kwargs["update"] = update
        return super().model_copy(**kwargs)

    @classmethod
    def from_mcp_template(  # type: ignore[override]
        cls,
        client_factory: ClientFactoryT,
        mcp_template: mcp_types.ResourceTemplate,
        *,
        identity: ProxyIdentity = "proxy",
    ) -> ProxyTemplate:  # ty:ignore[invalid-method-override]
        """Factory method to create a ProxyTemplate from a raw MCP template schema."""

        return cls(
            client_factory=client_factory,
            identity=identity,
            uri_template=mcp_template.uri_template,
            name=mcp_template.name,
            title=mcp_template.title,
            description=mcp_template.description,
            mime_type=mcp_template.mime_type or "text/plain",
            icons=mcp_template.icons,
            annotations=mcp_template.annotations,
            parameters={},  # Remote templates don't have local parameters
            meta=mcp_template.meta,
            tags=get_fastmcp_metadata(mcp_template.meta).get("tags", []),
            task_config=TaskConfig(mode="forbidden"),
        )

    async def create_resource(
        self,
        uri: str,
        params: dict[str, Any],
        context: Context | None = None,
    ) -> ProxyResource:
        """Create a resource from the template by calling the remote server."""
        # The path comes from the backend's own template, because the local
        # uri_template may differ; the query is forwarded exactly as sent.
        backend_template = self._backend_uri_template or self.uri_template
        parameterized_uri = forward_uri(backend_template, params, uri)
        client = await self._get_client()
        ctx = context or get_context()
        async with client:
            _stash_proxy_request_context(client, ctx)
            result = await _relay_read_resource(client, parameterized_uri, ctx)

        if isinstance(result, mcp_types.InputRequiredResult):
            # The backend template asked for input. `InputRequiredResourceResult`
            # is a `ResourceResult`, so caching it on the returned resource lets
            # the ask ride the ordinary read path out to the parent's wire
            # handler, which unwraps it.
            return ProxyResource(
                client_factory=self._client_factory,
                identity=self._identity,
                uri=parameterized_uri,
                name=self.name,
                title=self.title,
                description=self.description,
                mime_type=self.mime_type or "text/plain",
                icons=self.icons,
                meta=self.meta,
                tags=get_fastmcp_metadata(self.meta).get("tags", []),
                _cached_content=InputRequiredResourceResult(result),
            )

        if not result.contents:
            raise ResourceError(
                f"Remote server returned empty content for {parameterized_uri}"
            )

        # Process all items in the result list, not just the first one
        contents: list[ResourceContent] = []
        for item in result.contents:
            if isinstance(item, TextResourceContents):
                contents.append(
                    ResourceContent(
                        content=item.text,
                        mime_type=item.mime_type,
                        meta=item.meta,
                    )
                )
            elif isinstance(item, BlobResourceContents):
                contents.append(
                    ResourceContent(
                        content=base64.b64decode(item.blob),
                        mime_type=item.mime_type,
                        meta=item.meta,
                    )
                )
            else:
                raise ResourceError(f"Unsupported content type: {type(item)}")

        cached_content = ResourceResult(
            contents=contents,
            meta=_forwardable_server_meta(result.meta, self._identity) or None,
        )

        return ProxyResource(
            client_factory=self._client_factory,
            identity=self._identity,
            uri=parameterized_uri,
            name=self.name,
            title=self.title,
            description=self.description,
            mime_type=result.contents[
                0
            ].mime_type,  # Use first item's mimeType for backward compatibility
            icons=self.icons,
            meta=self.meta,
            tags=get_fastmcp_metadata(self.meta).get("tags", []),
            _cached_content=cached_content,
        )

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.provider.type": "ProxyProvider",
            "fastmcp.proxy.backend_uri_template": (
                self._backend_uri_template or self.uri_template
            ),
        }


class ProxyPrompt(Prompt):
    """A Prompt that represents and renders a prompt from a remote server."""

    task_config: TaskConfig = TaskConfig(mode="forbidden")
    _backend_name: str | None = None
    _identity: ProxyIdentity = "proxy"

    def __init__(
        self,
        client_factory: ClientFactoryT,
        *,
        identity: ProxyIdentity = "proxy",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._client_factory = client_factory
        self._identity = identity

    async def _get_client(self) -> Client:
        """Gets a client instance by calling the sync or async factory."""
        client = self._client_factory()
        if inspect.isawaitable(client):
            client = cast(Client, await client)
        return client

    def model_copy(self, **kwargs: Any) -> ProxyPrompt:
        """Override to preserve _backend_name when name changes."""
        update = kwargs.get("update", {})
        if "name" in update and self._backend_name is None:
            # First time name is being changed, preserve original for backend calls
            update = {**update, "_backend_name": self.name}
            kwargs["update"] = update
        return super().model_copy(**kwargs)

    @classmethod
    def from_mcp_prompt(
        cls,
        client_factory: ClientFactoryT,
        mcp_prompt: mcp_types.Prompt,
        *,
        identity: ProxyIdentity = "proxy",
    ) -> ProxyPrompt:
        """Factory method to create a ProxyPrompt from a raw MCP prompt schema."""
        arguments = [
            PromptArgument(
                name=arg.name,
                title=arg.title,
                description=arg.description,
                required=arg.required or False,
            )
            for arg in mcp_prompt.arguments or []
        ]
        return cls(
            client_factory=client_factory,
            identity=identity,
            name=mcp_prompt.name,
            title=mcp_prompt.title,
            description=mcp_prompt.description,
            arguments=arguments,
            icons=mcp_prompt.icons,
            meta=mcp_prompt.meta,
            tags=get_fastmcp_metadata(mcp_prompt.meta).get("tags", []),
            task_config=TaskConfig(mode="forbidden"),
        )

    async def render(self, arguments: dict[str, Any]) -> PromptResult:  # type: ignore[override]  # ty:ignore[invalid-method-override]
        """Render the prompt by making a call through the client."""
        backend_name = self._backend_name or self.name
        with client_span(
            f"prompts/get {backend_name}",
            "prompts/get",
            backend_name,
            prompt_name=backend_name,
        ) as span:
            span.set_attribute("fastmcp.provider.type", "ProxyProvider")
            client = await self._get_client()
            ctx = get_context()
            async with client:
                _stash_proxy_request_context(client, ctx)
                meta = _forwardable_request_meta(ctx)
                if client.protocol_version in MODERN_PROTOCOL_VERSIONS:
                    # See `_relay_read_resource`: surface a backend guard's ask
                    # instead of trying to answer it inside the proxy.
                    raw = await client._await_with_session_monitoring(
                        client.session.get_prompt(
                            backend_name,
                            arguments,
                            meta=_session_request_meta(meta),
                            input_responses=ctx.input_responses if ctx else None,
                            request_state=ctx.request_state if ctx else None,
                            allow_input_required=True,
                        )
                    )
                    if isinstance(raw, mcp_types.InputRequiredResult):
                        return InputRequiredPromptResult(raw)
                    result = raw
                else:
                    result = await client.get_prompt(backend_name, arguments, meta=meta)
            # Convert GetPromptResult to PromptResult, preserving meta from result
            # (not the static prompt meta which includes fastmcp tags)
            # Convert PromptMessages to Messages
            messages = [
                Message(content=m.content, role=m.role) for m in result.messages
            ]
            return PromptResult(
                messages=messages,
                description=result.description,
                meta=_forwardable_server_meta(result.meta, self._identity) or None,
            )

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.provider.type": "ProxyProvider",
            "fastmcp.proxy.backend_name": self._backend_name or self.name,
        }


# -----------------------------------------------------------------------------
# ProxyProvider
# -----------------------------------------------------------------------------


_ComponentT = TypeVar("_ComponentT")


class _CacheEntry(Generic[_ComponentT]):
    """A cached sequence of components with a monotonic timestamp."""

    __slots__ = ("items", "timestamp")

    def __init__(self, items: Sequence[_ComponentT], timestamp: float):
        self.items = items
        self.timestamp = timestamp

    def is_fresh(self, ttl: float) -> bool:
        return (time.monotonic() - self.timestamp) < ttl


_DEFAULT_CACHE_TTL: float = 300.0


class ProxyProvider(Provider):
    """Provider that proxies to a remote MCP server via a client factory.

    This provider fetches components from a remote server and returns Proxy*
    component instances that forward execution to the remote server.

    All components returned by this provider have task_config.mode="forbidden"
    because tasks cannot be executed through a proxy.

    Component lists (tools, resources, templates, prompts) are cached so that
    individual lookups (e.g. during ``call_tool``) can resolve from the cache
    instead of opening a new backend connection.  The cache stores the
    backend's raw component metadata and is shared across all sessions;
    per-session visibility and auth filtering are applied after cache lookup
    by the server layer.  The cache is refreshed whenever a ``list_*`` call
    is made, and entries expire after ``cache_ttl`` seconds (default 300).
    Set ``cache_ttl=0`` to disable caching.  Disabling is recommended for
    backends whose component lists change dynamically.

    Example:
        ```python
        from fastmcp import FastMCP
        from fastmcp.server.providers.proxy import ProxyProvider, ProxyClient

        # Create a proxy provider for a remote server
        proxy = ProxyProvider(lambda: ProxyClient("http://localhost:8000/mcp"))

        mcp = FastMCP("Proxy Server")
        mcp.add_provider(proxy)

        # Can also add with a namespace
        mcp.add_provider(proxy, namespace="remote")
        ```
    """

    def __init__(
        self,
        client_factory: ClientFactoryT,
        cache_ttl: float | None = None,
        *,
        identity: ProxyIdentity = "proxy",
        skills: bool = False,
    ):
        """Initialize a ProxyProvider.

        Args:
            client_factory: A callable that returns a Client instance when called.
                           This gives you full control over session creation and reuse.
                           Can be either a synchronous or an asynchronous function.
            cache_ttl: How long (in seconds) to cache component lists for
                      individual lookups.  Defaults to 300.  Set to 0 to
                      disable caching.
            identity: Whether proxied results carry the gateway's server
                      identity (``"proxy"``, the default) or keep the backend's
                      (``"upstream"``), matching what ``ProxyMetadataMiddleware``
                      advertises for discovery.
            skills: Forward the backend's Skills discovery (`skills/list` and
                `skills/get`). Registers `SkillsExtension` on the server
                this provider is added to.
        """
        super().__init__()
        self.client_factory = client_factory
        self.identity = identity
        self._skills = skills
        self._cache_ttl = cache_ttl if cache_ttl is not None else _DEFAULT_CACHE_TTL
        self._tools_cache: _CacheEntry[Tool] | None = None
        self._resources_cache: _CacheEntry[Resource] | None = None
        self._templates_cache: _CacheEntry[ResourceTemplate] | None = None
        self._prompts_cache: _CacheEntry[Prompt] | None = None
        # Generations advance before I/O so older completions cannot roll back
        # a newer refresh attempt.
        self._tools_generation = 0
        self._resources_generation = 0
        self._templates_generation = 0
        self._prompts_generation = 0

    def _use_identity(self, identity: ProxyIdentity) -> None:
        """Adopt the identity a ``ProxyMetadataMiddleware`` was explicitly given.

        Cached components carry the identity they were built with, so a change
        drops the caches and advances the generations to keep in-flight
        listings from caching components built under the old identity.
        """
        if identity == self.identity:
            return
        self.identity = identity
        self._tools_cache = None
        self._resources_cache = None
        self._templates_cache = None
        self._prompts_cache = None
        self._tools_generation += 1
        self._resources_generation += 1
        self._templates_generation += 1
        self._prompts_generation += 1

    def required_extensions(self) -> Sequence[ServerExtension]:
        if not self._skills:
            return ()
        from fastmcp.skills.extension import SkillsExtension

        return (SkillsExtension(),)

    async def _get_client(self) -> Client:
        """Gets a client instance by calling the sync or async factory."""
        client = self.client_factory()
        if inspect.isawaitable(client):
            client = cast(Client, await client)
        return client

    # -------------------------------------------------------------------------
    # Tool methods
    # -------------------------------------------------------------------------

    async def _list_tools(self) -> Sequence[Tool]:
        """List all tools from the remote server."""
        self._tools_generation += 1
        generation = self._tools_generation
        try:
            client = await self._get_client()
            async with client:
                mcp_tools = await client.list_tools()
                tools = [
                    ProxyTool.from_mcp_tool(
                        self.client_factory, t, identity=self.identity
                    )
                    for t in mcp_tools
                ]
        except MCPError as e:
            if e.error.code == METHOD_NOT_FOUND:
                tools = []
            else:
                raise
        except _PROXY_TRANSPORT_ERRORS as error:
            raise _proxy_upstream_error(error) from error
        if generation == self._tools_generation:
            self._tools_cache = _CacheEntry(tools, time.monotonic())
        return tools

    async def _get_tool(
        self, name: str, version: VersionSpec | None = None
    ) -> Tool | None:
        cache = self._tools_cache
        if cache is None or not cache.is_fresh(self._cache_ttl):
            tools = await self._list_tools()
        else:
            tools = cache.items
        matching = [t for t in tools if t.name == name]
        if version:
            matching = [t for t in matching if version.matches(t.version)]
        if not matching:
            return None
        return max(matching, key=version_sort_key)

    async def _get_tool_by_hash(self, tool_hash: str, tool_name: str) -> Tool | None:
        """Resolve an identity against the remote listing.

        The base implementation looks the tool up by its registered name,
        which assumes the name survived to here. Across a proxy it need not:
        a backend that mounts its app under a namespace advertises
        ``crm_save``, and nothing named ``save`` was ever listed. Matching on
        the identity carried in meta is what the identity is for.

        A remote that mounts one app twice sends back two tools claiming one
        identity, exactly as a local composition would. That is refused here
        on the same terms ``AggregateProvider`` refuses it, so a duplicated
        app is caught wherever it is composed rather than only nearby.
        """
        cache = self._tools_cache
        if cache is None or not cache.is_fresh(self._cache_ttl):
            tools = await self._list_tools()
        else:
            tools = cache.items

        matches = [tool for tool in tools if is_app_tool_with_identity(tool, tool_hash)]

        if not matches:
            return None
        distinct = {tool.name for tool in matches}
        if len(distinct) > 1:
            raise ToolError(
                f"Ambiguous app tool {tool_name!r}: {len(distinct)} components share "
                f"the identity {tool_hash!r}. The same app is composed more than "
                f"once, so this call cannot be routed to a single tool."
            )
        return max(matches, key=version_sort_key)

    # -------------------------------------------------------------------------
    # Resource methods
    # -------------------------------------------------------------------------

    async def _list_resources(self) -> Sequence[Resource]:
        """List all resources from the remote server."""
        self._resources_generation += 1
        generation = self._resources_generation
        try:
            client = await self._get_client()
            async with client:
                mcp_resources = await client.list_resources()
                resources = [
                    ProxyResource.from_mcp_resource(
                        self.client_factory, r, identity=self.identity
                    )
                    for r in mcp_resources
                ]
        except MCPError as e:
            if e.error.code == METHOD_NOT_FOUND:
                resources = []
            else:
                raise
        except _PROXY_TRANSPORT_ERRORS as error:
            raise _proxy_upstream_error(error) from error
        if generation == self._resources_generation:
            self._resources_cache = _CacheEntry(resources, time.monotonic())
        return resources

    async def _get_resource(
        self, uri: str, version: VersionSpec | None = None
    ) -> Resource | None:
        cache = self._resources_cache
        if cache is None or not cache.is_fresh(self._cache_ttl):
            resources = await self._list_resources()
        else:
            resources = cache.items
        matching = [r for r in resources if str(r.uri) == uri]
        if version:
            matching = [r for r in matching if version.matches(r.version)]
        if not matching:
            return None
        return max(matching, key=version_sort_key)

    # -------------------------------------------------------------------------
    # Resource template methods
    # -------------------------------------------------------------------------

    async def _list_resource_templates(self) -> Sequence[ResourceTemplate]:
        """List all resource templates from the remote server."""
        self._templates_generation += 1
        generation = self._templates_generation
        try:
            client = await self._get_client()
            async with client:
                mcp_templates = await client.list_resource_templates()
                templates = [
                    ProxyTemplate.from_mcp_template(
                        self.client_factory, t, identity=self.identity
                    )
                    for t in mcp_templates
                ]
        except MCPError as e:
            if e.error.code == METHOD_NOT_FOUND:
                templates = []
            else:
                raise
        except _PROXY_TRANSPORT_ERRORS as error:
            raise _proxy_upstream_error(error) from error
        if generation == self._templates_generation:
            self._templates_cache = _CacheEntry(templates, time.monotonic())
        return templates

    async def _get_resource_template(
        self, uri: str, version: VersionSpec | None = None
    ) -> ResourceTemplate | None:
        cache = self._templates_cache
        if cache is None or not cache.is_fresh(self._cache_ttl):
            templates = await self._list_resource_templates()
        else:
            templates = cache.items
        matching = [t for t in templates if t.matches(uri) is not None]
        if version:
            matching = [t for t in matching if version.matches(t.version)]
        if not matching:
            return None
        return max(matching, key=version_sort_key)

    # -------------------------------------------------------------------------
    # Prompt methods
    # -------------------------------------------------------------------------

    async def _list_prompts(self) -> Sequence[Prompt]:
        """List all prompts from the remote server."""
        self._prompts_generation += 1
        generation = self._prompts_generation
        try:
            client = await self._get_client()
            async with client:
                mcp_prompts = await client.list_prompts()
                prompts = [
                    ProxyPrompt.from_mcp_prompt(
                        self.client_factory, p, identity=self.identity
                    )
                    for p in mcp_prompts
                ]
        except MCPError as e:
            if e.error.code == METHOD_NOT_FOUND:
                prompts = []
            else:
                raise
        except _PROXY_TRANSPORT_ERRORS as error:
            raise _proxy_upstream_error(error) from error
        if generation == self._prompts_generation:
            self._prompts_cache = _CacheEntry(prompts, time.monotonic())
        return prompts

    async def _get_prompt(
        self, name: str, version: VersionSpec | None = None
    ) -> Prompt | None:
        cache = self._prompts_cache
        if cache is None or not cache.is_fresh(self._cache_ttl):
            prompts = await self._list_prompts()
        else:
            prompts = cache.items
        matching = [p for p in prompts if p.name == name]
        if version:
            matching = [p for p in matching if version.matches(p.version)]
        if not matching:
            return None
        return max(matching, key=version_sort_key)

    # -------------------------------------------------------------------------
    # Task methods
    # -------------------------------------------------------------------------

    async def get_tasks(self) -> Sequence[FastMCPComponent]:
        """Return empty list since proxy components don't support tasks.

        Override the base implementation to avoid calling list_tools() during
        server lifespan initialization, which would open the client before any
        context is set. All Proxy* components have task_config.mode="forbidden".
        """
        return []

    # lifespan() uses default implementation (empty context manager)
    # because client cleanup is handled per-request


@dataclass(frozen=True)
class _UpstreamServerMetadata:
    instructions: str | None
    server_info: mcp_types.Implementation | None
    meta: dict[str, Any]

    @classmethod
    def from_result(
        cls,
        result: mcp_types.InitializeResult | mcp_types.DiscoverResult,
        server_info: mcp_types.Implementation | None,
    ) -> _UpstreamServerMetadata:
        """Detach forwarded values from the backend session's adopted result."""
        return cls(
            instructions=result.instructions,
            server_info=(
                server_info.model_copy(deep=True) if server_info is not None else None
            ),
            meta=deepcopy(result.meta or {}),
        )

    @classmethod
    def from_client(cls, client: Client) -> _UpstreamServerMetadata | None:
        result = client.session.initialize_result or client.session.discover_result
        if result is None:
            return None
        return cls.from_result(result, client.session.server_info)

    @classmethod
    def from_discover(cls, result: mcp_types.DiscoverResult) -> _UpstreamServerMetadata:
        raw_server_info = (result.meta or {}).get(mcp_types.SERVER_INFO_META_KEY)
        try:
            server_info = (
                mcp_types.Implementation.model_validate(raw_server_info)
                if raw_server_info is not None
                else None
            )
        except ValidationError:
            server_info = None
        return cls.from_result(result, server_info)


class ProxyMetadataMiddleware(Middleware):
    """Forward optional server metadata from a ``ProxyProvider`` backend.

    Instructions and namespaced metadata are forwarded with frontend values
    taking precedence. Protocol versions, capabilities, cache policy, and result
    type are never copied from the backend. ``identity`` controls whether server
    identity remains the gateway's or uses the backend's when available. It
    defaults to the provider's identity; an explicit value also applies to the
    provider's proxied results, so discovery and results always agree.
    """

    def __init__(
        self,
        provider: ProxyProvider,
        *,
        identity: ProxyIdentity | None = None,
    ) -> None:
        if identity is None:
            identity = provider.identity
        if identity not in ("proxy", "upstream"):
            raise ValueError("identity must be 'proxy' or 'upstream'")
        # Results must report the same identity discovery advertises, so an
        # explicit identity here also decides the provider's result stamps.
        provider._use_identity(identity)
        self.provider = provider
        self.identity = identity

    async def _read_connected(self, client: Client) -> _UpstreamServerMetadata | None:
        """Read metadata without changing the client's adopted negotiation state."""
        if client.mode in MODERN_PROTOCOL_VERSIONS and client.prior_discover is None:
            # An exact pin adopts a synthetic result without probing. Read the
            # real result directly, but do not adopt it into this borrowed session.
            raw = await client.session.send_discover(client.mode)
            result_type = raw.get("resultType")
            if (
                isinstance(result_type, str)
                and result_type not in mcp_types.CORE_RESULT_TYPES
            ):
                return None
            try:
                result = mcp_types.DiscoverResult.model_validate(raw)
            except ValidationError as error:
                logger.debug("Could not read upstream server metadata: %r", error)
                return None
            return _UpstreamServerMetadata.from_discover(result)
        return _UpstreamServerMetadata.from_client(client)

    async def _read_upstream(
        self, client: Client, context: Context | None
    ) -> _UpstreamServerMetadata | None:
        if context is not None:
            _stash_proxy_request_context(client, context)

        try:
            if client.is_connected():
                return await self._read_connected(client)
            async with client:
                return await self._read_connected(client)
        except (MCPError, *_PROXY_TRANSPORT_ERRORS) as error:
            if isinstance(error, RuntimeError) and not _has_transport_cause(error):
                raise
            logger.debug("Could not read upstream server metadata: %r", error)
            return None

    def _updates(
        self,
        result: mcp_types.InitializeResult | mcp_types.DiscoverResult,
        upstream: _UpstreamServerMetadata,
    ) -> dict[str, Any]:
        meta = _forwardable_server_meta(upstream.meta)
        meta.update(result.meta or {})

        updates: dict[str, Any] = {"meta": meta or None}
        if result.instructions is None and upstream.instructions is not None:
            updates["instructions"] = upstream.instructions
        if self.identity == "upstream" and upstream.server_info is not None:
            if isinstance(result, mcp_types.InitializeResult):
                updates["server_info"] = upstream.server_info
            else:
                meta[mcp_types.SERVER_INFO_META_KEY] = upstream.server_info.model_dump(
                    by_alias=True, mode="json", exclude_none=True
                )
                updates["meta"] = meta
        return updates

    async def on_initialize(
        self,
        context: MiddlewareContext[mcp_types.InitializeRequest],
        call_next: CallNext[
            mcp_types.InitializeRequest, mcp_types.InitializeResult | None
        ],
    ) -> mcp_types.InitializeResult | None:
        # Factory errors must occur before the legacy response is committed.
        client = await self.provider._get_client()
        result = await call_next(context)
        if result is None:
            return None
        upstream = await self._read_upstream(client, context.fastmcp_context)
        if upstream is None:
            return result
        return result.model_copy(update=self._updates(result, upstream))

    async def on_discover(
        self,
        context: MiddlewareContext[mcp_types.DiscoverRequest],
        call_next: CallNext[
            mcp_types.DiscoverRequest,
            mcp_types.DiscoverResult | dict[str, Any],
        ],
    ) -> mcp_types.DiscoverResult | dict[str, Any]:
        result = await call_next(context)
        if not isinstance(result, mcp_types.DiscoverResult):
            return result
        client = await self.provider._get_client()
        upstream = await self._read_upstream(client, context.fastmcp_context)
        if upstream is None:
            return result
        return result.model_copy(update=self._updates(result, upstream))


# -----------------------------------------------------------------------------
# Factory Functions
# -----------------------------------------------------------------------------


def _mirror_front_era_mode() -> str | None:
    """Return the backend connect ``mode`` that mirrors the front connection's era.

    A proxy is a server on its front and a client on its back. The two protocol
    eras have mutually exclusive interaction models on a single session, so the
    whole chain must speak one era end-to-end: a modern front must reach a modern
    backend (a guard tool's `InputRequiredResult` round-trips), and a handshake
    front must reach a handshake backend (server-initiated sampling / elicitation
    / roots push-forwarding works). Rather than pin its own era, the proxy speaks
    on its back whatever era was negotiated on its front.

    Reads the negotiated protocol version from the active front request context:

    - modern front → that exact version, so the backend negotiates the same era
      (pinning the version rather than ``"auto"`` makes the eras truly match).
    - handshake front → ``"legacy"``.
    - no request context (e.g. proxy construction before any request) → ``None``,
      leaving the factory's configured default mode in place.
    """
    try:
        ctx = get_context()
    except RuntimeError:
        return None
    rc = ctx.request_context
    if rc is None:
        return None
    version = rc.protocol_version
    if version in MODERN_PROTOCOL_VERSIONS:
        return version
    return "legacy"


def _create_client_factory(
    target: (
        Client[ClientTransportT]
        | ClientTransport
        | FastMCP[Any]
        | SDKServer
        | AnyUrl
        | Path
        | MCPConfig
        | dict[str, Any]
        | str
    ),
    *,
    mode: str | None = None,
) -> ClientFactoryT:
    """Create a client factory from the given target.

    Internal helper that handles the session strategy based on the target type:
    - Connected Client: reuses existing session (with warning about context mixing)
    - Disconnected Client: creates fresh sessions per request
    - Other targets: creates ProxyClient and fresh sessions per request
    """
    if isinstance(target, Client):
        client = target

        def as_proxy_backend(c: Client) -> Client:
            """Apply proxy connection settings to a copy we own.

            The caller handed us their Client; configuring it in place would
            change how their own connections behave, including whether their
            credentials get forwarded upstream.
            """
            fresh = c.new()
            # The caller chose this client's era, so a multi-server MCPConfig
            # target's mounted backend legs should negotiate it too rather than
            # stopping at the composite router (see
            # `TransportOptions.backend_mode`).
            fresh._transport_options = replace(
                _with_proxy_transport_options(fresh._transport_options),
                backend_mode=fresh.mode,
            )
            return fresh

        if client.is_connected() and type(client) is ProxyClient:
            logger.info(
                "Proxy detected connected ProxyClient - creating fresh sessions for each "
                "request to avoid request context leakage."
            )

            def fresh_client_factory() -> Client:
                return as_proxy_backend(client)

            return fresh_client_factory

        if client.is_connected():
            logger.info(
                "Proxy detected connected client - reusing existing session for all requests. "
                "This may cause context mixing in concurrent scenarios, and the session's "
                "existing settings apply, so backend results are validated against their "
                "declared output schema rather than relayed as-is. Pass a disconnected "
                "client to avoid both."
            )

            # The caller's session is already built, so there are no connection
            # settings left to apply — proxy options only take effect at connect
            # time. Reuse is opt-in via passing an already-connected client.
            def reuse_client_factory() -> Client:
                return client

            return reuse_client_factory

        def fresh_client_factory() -> Client:
            return as_proxy_backend(client)

        return fresh_client_factory
    else:
        # target is not a Client, so it's compatible with ProxyClient.__init__.
        #
        # With no explicit mode, the backend MIRRORS the front connection's
        # negotiated era per request (see `_mirror_front_era_mode`): a fresh
        # client is built for each request and its mode is set from the front
        # era, so the whole chain speaks one era end-to-end. Because every
        # request gets its own client whose mode is derived at call time, front
        # connections of different eras never share a backend session — there is
        # no era to bleed across the (metadata-only) provider caches.
        #
        # An explicit mode pins the backend era regardless of the front. This
        # breaks era-consistency and is only appropriate when the backend speaks
        # a single era; the mismatch surfaces through the normal era gates.
        explicit_mode = mode is not None
        client_kwargs: dict[str, Any] = {"mode": mode} if explicit_mode else {}
        base_client = ProxyClient(cast(Any, target), **client_kwargs)

        def proxy_client_factory() -> Client:
            fresh = base_client.new()
            backend_mode = mode
            if not explicit_mode:
                backend_mode = _mirror_front_era_mode()
                if backend_mode is not None:
                    fresh.mode = backend_mode
            if backend_mode is not None:
                # A multi-server MCPConfig target reaches its real backends
                # through proxies mounted on a composite router, so setting the
                # era on this client alone would stop at the router. Carry the
                # era down to those backend legs too (see
                # `TransportOptions.backend_mode`), resolved here — at the
                # moment a client is built for this request — so it tracks the
                # front era rather than whatever was true at construction.
                fresh._transport_options = replace(
                    _with_proxy_transport_options(fresh._transport_options),
                    backend_mode=backend_mode,
                )
            return fresh

        return proxy_client_factory


# -----------------------------------------------------------------------------
# FastMCPProxy - Convenience Wrapper
# -----------------------------------------------------------------------------


class FastMCPProxy(FastMCP):
    """A FastMCP server that acts as a proxy to a remote MCP-compliant server.

    This is a convenience wrapper that creates a FastMCP server with a
    ProxyProvider. For more control, use FastMCP with add_provider(ProxyProvider(...)).

    Example:
        ```python
        from fastmcp.server import create_proxy
        from fastmcp.server.providers.proxy import FastMCPProxy, ProxyClient

        # Create a proxy server using create_proxy (recommended)
        proxy = create_proxy("http://localhost:8000/mcp")

        # Or use FastMCPProxy directly with explicit client factory
        proxy = FastMCPProxy(client_factory=lambda: ProxyClient("http://localhost:8000/mcp"))
        ```
    """

    def __init__(
        self,
        *,
        client_factory: ClientFactoryT,
        provider_error_strategy: ProviderErrorStrategy = "warn",
        identity: ProxyIdentity = "proxy",
        skills: bool = False,
        **kwargs,
    ):
        """Initialize the proxy server.

        FastMCPProxy requires explicit session management via client_factory.
        Use create_proxy() for convenience with automatic session strategy.

        Args:
            client_factory: A callable that returns a Client instance when called.
                           This gives you full control over session creation and reuse.
                           Can be either a synchronous or asynchronous function.
            provider_error_strategy: How provider errors should affect aggregate
                operations. Defaults to ``"warn"`` for compatibility; use
                ``"raise"`` when the proxy should surface upstream failures.
            identity: Whether clients see the proxy's server identity or the
                upstream server's when available, in discovery and in proxied
                result metadata. Defaults to ``"proxy"``
                for compatibility.
            skills: Forward the backend's Skills discovery.
            **kwargs: Additional settings for the FastMCP server.
        """
        super().__init__(**kwargs)
        self.provider_error_strategy = provider_error_strategy
        self.client_factory = client_factory
        provider = ProxyProvider(client_factory, identity=identity, skills=skills)
        self.add_provider(provider)
        self.middleware.append(ProxyMetadataMiddleware(provider))
        self._setup_proxy_ping_handler()

    async def _get_client(self) -> Client:
        client = self.client_factory()
        if inspect.isawaitable(client):
            client = cast(Client, await client)
        return client

    def _setup_proxy_ping_handler(self) -> None:
        async def ping_remote(
            _ctx: ServerRequestContext[Any, Any],
            _params: mcp_types.RequestParams | None,
        ) -> mcp_types.EmptyResult:
            client = await self._get_client()
            async with client:
                await client.ping()
            return mcp_types.EmptyResult()

        self._mcp_server.add_request_handler(
            "ping", mcp_types.RequestParams, ping_remote
        )


# -----------------------------------------------------------------------------
# ProxyClient and Related
# -----------------------------------------------------------------------------


async def default_proxy_roots_handler(
    context: ServerRequestContext[Any, Any],
) -> RootsList:
    """Forward list roots request from remote server to proxy's connected clients.

    A handshake-era backend can still issue `roots/list`, and the proxy is that
    backend's client, so it relays the request onto its own front session. This
    reaches the wire through the SDK session rather than a `Context` method:
    `ctx.list_roots()` is not part of FastMCP's server-authoring API, because
    SEP-2322 removed server-initiated requests from the modern protocol. The
    relay exists only for handshake-era interop on both legs.
    """
    ctx = get_context()
    # Deprecated upstream in SDK v2; the handshake-era relay is the one caller.
    result = await ctx.session.list_roots()  # ty: ignore[deprecated]
    return result.roots


async def default_proxy_sampling_handler(
    messages: list[mcp_types.SamplingMessage],
    params: mcp_types.CreateMessageRequestParams,
    context: ServerRequestContext[Any, Any],
) -> mcp_types.CreateMessageResult | mcp_types.CreateMessageResultWithTools:
    """Forward sampling request from remote server to proxy's connected clients.

    Relays through the SDK session for the same reason as
    `default_proxy_roots_handler`: server-initiated sampling is not part of
    FastMCP's server-authoring API, and this path only ever runs when both legs
    of the proxy speak the handshake era.
    """
    ctx = get_context()
    # Deprecated upstream in SDK v2; the handshake-era relay is the one caller.
    # Relay the request and the client's answer unchanged, so the backend sees
    # the same model, stop reason and content as with a direct connection.
    return await ctx.session.create_message(  # ty: ignore[deprecated]
        messages=list(messages),
        system_prompt=params.system_prompt,
        include_context=params.include_context,
        temperature=params.temperature,
        max_tokens=params.max_tokens,
        stop_sequences=params.stop_sequences,
        metadata=params.metadata,
        model_preferences=params.model_preferences,
        related_request_id=ctx.origin_request_id,
    )


async def default_proxy_elicitation_handler(
    message: str,
    response_type: type,
    params: mcp_types.ElicitRequestParams,
    context: ServerRequestContext[Any, Any],
) -> ElicitResult:
    """Forward elicitation request from remote server to proxy's connected clients."""
    if isinstance(params, ElicitRequestFormParams):
        ctx = get_context()
        result = await ctx.session.elicit(
            message=message,
            requested_schema=params.requested_schema,
            related_request_id=ctx.request_id,
        )
    else:
        if params.elicitation_id is None:
            raise ValueError(
                "URL-mode elicitation request from the remote server has no "
                "elicitationId; the proxy cannot forward it."
            )
        ctx = get_context()
        result = await ctx.session.elicit_url(
            message=message,
            url=params.url,
            elicitation_id=params.elicitation_id,
            related_request_id=ctx.request_id,
        )
    return ElicitResult(action=result.action, content=result.content)


async def default_proxy_log_handler(message: LogMessage) -> None:
    """Forward log notification from remote server to proxy's connected clients."""
    ctx = get_context()
    data = message.data
    # FastMCP servers send {"msg": ..., "extra": ...}; any other MCP server may
    # send any JSON value, which is forwarded as the message text.
    if isinstance(data, dict) and isinstance(data.get("msg"), str):
        msg, extra = data["msg"], data.get("extra")
    else:
        msg, extra = (data if isinstance(data, str) else json.dumps(data)), None
    await ctx.log(msg, level=message.level, logger_name=message.logger, extra=extra)


async def default_proxy_progress_handler(
    progress: float,
    total: float | None,
    message: str | None,
) -> None:
    """Forward progress notification from remote server to proxy's connected clients."""
    ctx = get_context()
    await ctx.report_progress(progress, total, message)


_FORWARDED_LIST_CHANGED_NOTIFICATIONS = (
    mcp_types.ToolListChangedNotification,
    mcp_types.ResourceListChangedNotification,
    mcp_types.PromptListChangedNotification,
)


async def default_proxy_message_handler(
    message: mcp_types.ServerNotification | Exception,
) -> None:
    """Forward list-changed notifications from remote server to proxy's connected clients.

    Logging and progress have dedicated handlers; the tool, resource, and prompt
    list-changed notifications only arrive through the message handler.
    """
    if isinstance(message, _FORWARDED_LIST_CHANGED_NOTIFICATIONS):
        ctx = get_context()
        await ctx.send_notification(message)


def _restore_request_context(
    rc_ref: list[Any],
) -> None:
    """Set the ``request_ctx``, ``_current_context`` and ``_current_server``
    ContextVars from stashed values so a proxy forwarding handler relays to the
    proxy's own client rather than the upstream server.

    Called at the start of every proxy handler invocation. The stashed proxy
    ``RequestContext`` is the correct forwarding target, so we restore it unless
    it is already active. This covers two cases:

    - Stateful proxy: the reused receive-loop task carries a stale ContextVar
      from an earlier request (same session, different request_id).
    - In-memory backend (SDK v2): the backend runs in this event loop, so the
      handler may inherit the *backend's* request_ctx (a different session).

    We stash a ``(RequestContext, weakref[FastMCP])`` tuple — never a
    ``Context`` instance — because ``Context`` properties are themselves
    ContextVar-dependent and would resolve stale values in the receive
    loop.  Instead we construct a fresh ``Context`` here after restoring
    ``request_ctx``, so its property accesses read the correct values.

    This is a set-only repair of a long-lived task's ContextVars, not a
    scope: we never ``reset()`` because the prior values are stale and
    the loop keeps running.  ``_current_server`` is restored alongside
    ``_current_context`` so handlers that resolve the server via
    dependency injection (e.g. ``get_server()``) see the right instance;
    it is set directly rather than via ``Context.__aenter__`` to avoid
    opening a context-manager lifecycle on an unscoped path.
    """
    import weakref

    from fastmcp.server.context import Context, _current_context
    from fastmcp.server.dependencies import _current_server

    stashed = rc_ref[0]
    if stashed is None:
        return

    rc, fastmcp_ref = stashed
    current_rc = fastmcp_request_ctx.get()
    # Restore unless the stashed proxy context is already the active one.
    if current_rc is rc:
        return
    fastmcp_request_ctx.set(rc)
    fastmcp = fastmcp_ref()
    if fastmcp is not None:
        _current_context.set(Context(fastmcp))
        _current_server.set(weakref.ref(fastmcp))


def _make_restoring_handler(handler: Callable, rc_ref: list[Any]) -> Callable:
    """Wrap a proxy handler to restore request_ctx before delegating."""

    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        _restore_request_context(rc_ref)
        return await handler(*args, **kwargs)

    return wrapper


class ProxyClient(Client[ClientTransportT]):
    """A proxy client that forwards advanced interactions between a remote MCP server and the proxy's connected clients.

    Supports forwarding roots, sampling, elicitation, logging, progress, and
    tool, resource, and prompt list-changed notifications.
    Eligible inbound HTTP headers are forwarded by default; set
    `forward_incoming_headers=False` to use only the backend transport's
    configured headers and authentication. Applies to HTTP and SSE backends,
    including backends in an MCP configuration.

    The default forwarding handlers must resolve the *proxy's* request context so
    they relay server-initiated requests (roots/sampling/elicitation) back to the
    proxy's own connected client, not to the upstream server they are talking to.
    Under SDK v2 an in-memory backend runs in the same event loop as this client,
    so a naive ``get_context()`` inside a handler can resolve to the backend's
    context and forward the request straight back to the backend — an infinite
    loop. To avoid that, ``ProxyTool.run`` (and the other proxy components) stash
    the proxy-side ``RequestContext`` in ``_proxy_rc_ref`` before each backend
    call, and the handlers are wrapped to restore it before forwarding.
    """

    # Mutable list shared across copies (Client.new() uses copy.copy, which
    # preserves references to mutable containers). Proxy components write [0]
    # before each backend call; handlers read it to restore the proxy's
    # request_ctx before forwarding. Stores a (RequestContext, weakref[FastMCP])
    # tuple — never a Context instance — because Context properties are
    # ContextVar-dependent and would resolve stale values in the receive loop.
    _proxy_rc_ref: list[Any]
    _proxy_restoring_handler_keys: set[str]

    # A proxy forwards calls; it must not advertise task support to its backend.
    # Proxied tools run synchronously (forbidden mode), and the proxy has no path
    # to drive a backend task on the front connection's behalf, so the internal
    # tasks client extension is not folded into a proxy's backend client.
    _auto_internal_extensions: bool = False

    def __init__(
        self,
        transport: ClientTransportT
        | FastMCP[Any]
        | SDKServer
        | AnyUrl
        | Path
        | MCPConfig
        | dict[str, Any]
        | str,
        *,
        forward_incoming_headers: bool = True,
        **kwargs,
    ):
        if "name" not in kwargs:
            kwargs["name"] = self.generate_name()
        # ProxyClient itself defaults to the handshake era when constructed
        # directly: a single proxy session can only be one era, and handshake
        # keeps the server-initiated push forwarding (sampling / elicitation /
        # roots, via the handlers installed below) that proxies rely on. When a
        # proxy is created from a non-Client target (`create_proxy(target)` /
        # `_create_client_factory`) with no explicit mode, the factory instead
        # MIRRORS the front connection's negotiated era onto this client per
        # request, so the whole chain speaks one era end-to-end. An explicit
        # `mode=` (e.g. `create_proxy(target, mode="auto")`) pins the era and
        # overrides mirroring. The eras are mutually exclusive per session.
        #
        # The handshake default is pinned explicitly rather than inherited from
        # `Client`, whose own default is `"auto"`: mirroring only applies when
        # there is a front request to mirror, so this is the fallback for a
        # directly-constructed ProxyClient, and it must not drift with the
        # client default.
        kwargs.setdefault("mode", "legacy")
        # Install context-restoring handler wrappers BEFORE super().__init__
        # registers them with the Client's session kwargs.
        self._proxy_rc_ref = [None]
        self._proxy_restoring_handler_keys = set()
        for key, default_fn in (
            ("roots", default_proxy_roots_handler),
            ("sampling_handler", default_proxy_sampling_handler),
            ("elicitation_handler", default_proxy_elicitation_handler),
            ("log_handler", default_proxy_log_handler),
            ("progress_handler", default_proxy_progress_handler),
            ("message_handler", default_proxy_message_handler),
        ):
            if key not in kwargs:
                kwargs[key] = _make_restoring_handler(default_fn, self._proxy_rc_ref)
                self._proxy_restoring_handler_keys.add(key)
        super().__init__(transport=transport, **kwargs)  # ty: ignore[no-matching-overload]

        self._transport_options = replace(
            _with_proxy_transport_options(self._transport_options),
            forward_incoming_headers=forward_incoming_headers,
        )

    def _bind_restoring_handlers(self) -> None:
        if "roots" in self._proxy_restoring_handler_keys:
            self._session_kwargs["list_roots_callback"] = create_roots_callback(
                _make_restoring_handler(default_proxy_roots_handler, self._proxy_rc_ref)
            )
        if "sampling_handler" in self._proxy_restoring_handler_keys:
            self._session_kwargs["sampling_callback"] = create_sampling_callback(
                _make_restoring_handler(
                    default_proxy_sampling_handler, self._proxy_rc_ref
                )
            )
        if "elicitation_handler" in self._proxy_restoring_handler_keys:
            self._session_kwargs["elicitation_callback"] = create_elicitation_callback(
                _make_restoring_handler(
                    default_proxy_elicitation_handler, self._proxy_rc_ref
                )
            )
        if "log_handler" in self._proxy_restoring_handler_keys:
            self._session_kwargs["logging_callback"] = create_log_callback(
                _make_restoring_handler(default_proxy_log_handler, self._proxy_rc_ref)
            )
        if "progress_handler" in self._proxy_restoring_handler_keys:
            self._progress_handler = _make_restoring_handler(
                default_proxy_progress_handler, self._proxy_rc_ref
            )
        if "message_handler" in self._proxy_restoring_handler_keys:
            message_handler = _make_restoring_handler(
                default_proxy_message_handler, self._proxy_rc_ref
            )
            self._base_message_handler = message_handler
            self._session_kwargs["message_handler"] = (
                _evicting_message_handler(self._response_cache, message_handler)
                if self._response_cache is not None
                else message_handler
            )

    def new(self) -> ProxyClient[ClientTransportT]:
        new_client = cast(ProxyClient[ClientTransportT], super().new())
        new_client._proxy_rc_ref = [None]
        new_client._proxy_restoring_handler_keys = set(
            self._proxy_restoring_handler_keys
        )
        new_client._bind_restoring_handlers()
        return new_client


class StatefulProxyClient(ProxyClient[ClientTransportT]):
    """A proxy client that provides a stateful client factory for the proxy server.

    The stateful proxy client bound its copy to the server session.
    And it will be disconnected when the session is exited.

    This is useful to proxy a stateful mcp server such as the Playwright MCP server.
    Note that it is essential to ensure that the proxy server itself is also stateful.

    The base ``ProxyClient`` already installs the context-restoring handlers
    (see its docstring); this subclass additionally caches one client per stable
    ``Connection`` and forces disconnect when the connection is torn down.
    """

    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        # SDK v2 constructs a ServerSession per request, so per-session keying
        # would build a fresh proxy client for every request. Key by the stable
        # per-connection `Connection` instead, and tie cleanup to its exit stack.
        self._caches: dict[Connection, Client[ClientTransportT]] = {}

    def new(self) -> StatefulProxyClient[ClientTransportT]:
        return cast(StatefulProxyClient[ClientTransportT], super().new())

    async def __aexit__(self, exc_type, exc_value, traceback) -> None:  # type: ignore[override]  # ty:ignore[invalid-method-override]
        """Release this context without disconnecting the persistent session."""
        with anyio.CancelScope(shield=True):
            async with self._session_state.lock:
                self._session_state.nesting_counter = max(
                    0, self._session_state.nesting_counter - 1
                )

    async def clear(self):
        """Clear all cached clients and force disconnect them."""
        while self._caches:
            _, cache = self._caches.popitem()
            await cache._disconnect(force=True)

    def new_stateful(self) -> Client[ClientTransportT]:
        """Create a new stateful proxy client instance with the same configuration.

        Use this method as the client factory for stateful proxy server.
        """
        session = get_context().session
        # SDK v2: the ServerSession is per-request; the Connection is the stable
        # per-connection object that owns the exit stack. Key the cache and the
        # cleanup callback off it so one proxy client is reused for the whole
        # connection instead of one per request.
        connection = getattr(session, "_connection", None)
        if connection is None:
            raise RuntimeError(
                "Stateful proxy requires a per-connection server session; "
                "no connection is available on the current context."
            )
        proxy_client = self._caches.get(connection, None)

        if proxy_client is None:
            proxy_client = self.new()
            logger.debug(f"{proxy_client} created for {connection}")
            self._caches[connection] = proxy_client

            async def _on_connection_exit():
                self._caches.pop(connection, None)
                logger.debug(f"{proxy_client} will be disconnect")
                # This callback runs while the connection's exit stack is
                # unwinding, which usually happens because the owning task is
                # being cancelled. Shield the disconnect so the forced cleanup
                # actually runs to completion instead of aborting at the first
                # cancellation checkpoint (e.g. acquiring the session lock).
                with anyio.CancelScope(shield=True):
                    await proxy_client._disconnect(force=True)

            connection.exit_stack.push_async_callback(_on_connection_exit)

        return proxy_client
