"""Coordination of independent MCP client connections."""

from __future__ import annotations

import asyncio
import contextlib
import datetime
from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType, TracebackType
from typing import Any

import anyio
import mcp_types
from mcp.client.caching import CacheMode

from fastmcp.client.client import CallToolResult, Client, ConnectMode
from fastmcp.client.progress import ProgressHandler
from fastmcp.mcp_config import MCPConfig
from fastmcp.skills.models import MCPSkill
from fastmcp.skills.skill import Skill
from fastmcp.utilities.async_utils import gather


@dataclass(frozen=True)
class ToolRoute:
    """The client and upstream name behind a public group tool name."""

    server_name: str
    client: Client[Any]
    upstream_name: str


@dataclass(frozen=True)
class _EnteredClient:
    task: asyncio.Task[Any]
    session_task: asyncio.Task[Any] | None


async def _enter_client_context(client: Client[Any]) -> _EnteredClient:
    await client.__aenter__()
    task = asyncio.current_task()
    if task is None:
        raise RuntimeError("Client group entered outside an asyncio task")
    return _EnteredClient(task, client._session_state.session_task)


class ClientGroup:
    """Coordinate independent clients without introducing a proxy server.

    Each client retains its own transport, session, capabilities, and protocol
    version. The group only combines tool and skill discovery and routes tool
    calls.

    Callers may manage the clients' connections themselves or use the group as
    a convenience context manager. The group's context is reentrant in the
    same way a client's is: entries are reference counted, the first entry
    connects every client, and the last exit disconnects them. Entering an
    already-connected FastMCP client is likewise safe because client contexts
    are reference counted.
    """

    def __init__(self, clients: Mapping[str, Client[Any]]) -> None:
        if not clients:
            raise ValueError("ClientGroup requires at least one client")

        self._clients = dict(clients)
        self._exit_stack: contextlib.AsyncExitStack | None = None
        self._nesting_counter = 0
        self._lifecycle_lock = anyio.Lock()
        self._tool_routes: dict[str, ToolRoute] = {}
        self._catalog_loaded = False
        self._route_lock = anyio.Lock()
        # Member closes handed off by exiting contexts; referenced until done.
        self._closers: set[asyncio.Task[bool | None]] = set()

    @property
    def clients(self) -> Mapping[str, Client[Any]]:
        """The group's clients, keyed by server name.

        Read-only: membership is fixed at construction, since discovered routes
        hold the client that advertised each tool and would silently go stale
        if the mapping were swapped underneath them.
        """
        return MappingProxyType(self._clients)

    @classmethod
    def from_config(
        cls,
        config: MCPConfig | dict[str, Any],
        *,
        default_mode: ConnectMode = "auto",
    ) -> ClientGroup:
        """Create one independent client for each configured server.

        A server entry may include a FastMCP-specific ``mode`` field. It applies
        only to that server; entries without one use ``default_mode``.
        """
        parsed = (
            config if isinstance(config, MCPConfig) else MCPConfig.from_dict(config)
        )
        clients: dict[str, Client[Any]] = {}

        for name, server in parsed.mcpServers.items():
            configured_mode = (server.model_extra or {}).get("mode", default_mode)
            if not isinstance(configured_mode, str):
                raise TypeError(f"Protocol mode for server {name!r} must be a string")
            timeout = server.timeout / 1000 if server.timeout is not None else None
            clients[name] = Client(
                server.to_transport(), mode=configured_mode, timeout=timeout
            )

        return cls(clients)

    @property
    def protocol_versions(self) -> dict[str, str | None]:
        return {name: client.protocol_version for name, client in self._clients.items()}

    async def __aenter__(self) -> ClientGroup:
        async with self._lifecycle_lock:
            if self._exit_stack is None:
                self._exit_stack = await self._connect_all()
            self._nesting_counter += 1
        return self

    async def _connect_all(self) -> contextlib.AsyncExitStack:
        stack = contextlib.AsyncExitStack()
        await stack.__aenter__()

        # Connect concurrently: entry latency stays one handshake deep instead
        # of growing linearly with the number of servers. Each member's exit is
        # registered the moment its entry succeeds, so a failed or cancelled
        # entry can unwind exactly the members that connected.
        async def enter_member(client: Client[Any]) -> None:
            entered = await _enter_client_context(client)

            async def exit_client(
                exc_type: type[BaseException] | None,
                exc_value: BaseException | None,
                traceback: TracebackType | None,
            ) -> bool | None:
                return await client._exit_context(
                    entered.session_task,
                    entered.task,
                    exc_type,
                    exc_value,
                    traceback,
                )

            stack.push_async_exit(exit_client)

        try:
            results = await gather(
                (enter_member(client) for client in self._clients.values()),
                return_exceptions=True,
            )
        except BaseException:
            await self._unwind_partial_entry(stack)
            raise

        errors = [result for result in results if isinstance(result, BaseException)]
        if errors:
            await self._unwind_partial_entry(stack)
            raise errors[0]
        return stack

    @staticmethod
    async def _unwind_partial_entry(stack: contextlib.AsyncExitStack) -> None:
        """Disconnect the members a failed or cancelled entry already connected."""
        with anyio.CancelScope(shield=True), contextlib.suppress(Exception):
            await stack.aclose()

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool | None:
        # Release this context's hold before any await, as Client does: a context
        # exited by cancellation can be interrupted at every await, and a hold
        # that is never released keeps every member connected for good.
        self._nesting_counter = max(0, self._nesting_counter - 1)
        held = self._exit_stack
        if self._nesting_counter > 0 or held is None:
            return None
        # Close the members in their own task, so a cancelled exit returns at
        # once instead of waiting on the lifecycle lock, and the close still runs.
        closer = asyncio.create_task(
            self._close_members(held, exc_type, exc_value, traceback)
        )
        self._closers.add(closer)
        closer.add_done_callback(self._closers.discard)
        return await asyncio.shield(closer)

    async def _close_members(
        self,
        held: contextlib.AsyncExitStack,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool | None:
        async with self._lifecycle_lock:
            if self._exit_stack is not held or self._nesting_counter > 0:
                # Closed already, or another context entered while we waited.
                return None
            self._exit_stack = None
            # Keep the known routes: a route needs only its own client, which a
            # caller may connect without the group. Mark the catalog for lazy
            # rediscovery, so the next unknown name re-reads every server.
            self._catalog_loaded = False
            return await held.__aexit__(exc_type, exc_value, traceback)

    def _require_connected(self) -> None:
        disconnected = [
            name for name, client in self._clients.items() if not client.is_connected()
        ]
        if disconnected:
            names = ", ".join(repr(name) for name in disconnected)
            raise RuntimeError(f"ClientGroup clients are not connected: {names}")

    def _get_connected_client(self, server_name: str) -> Client[Any]:
        try:
            client = self._clients[server_name]
        except KeyError as exc:
            raise KeyError(f"Unknown ClientGroup server: {server_name!r}") from exc
        if not client.is_connected():
            raise RuntimeError(
                f"ClientGroup client for server {server_name!r} is not connected"
            )
        return client

    def _require_route_connected(self, route: ToolRoute) -> None:
        if not route.client.is_connected():
            raise RuntimeError(
                f"ClientGroup client for server {route.server_name!r} is not connected"
            )

    async def list_tools(
        self, *, cache_mode: CacheMode = "refresh"
    ) -> list[mcp_types.Tool]:
        """List tools from every client with namespaced names.

        An explicit call is the group's catalog-refresh mechanism, so it
        defaults to `cache_mode="refresh"`: a client-side response cache
        (SEP-2549) is repopulated rather than served, and the routes reflect
        what every server advertises now. Pass `cache_mode="use"` to allow
        cache hits when staleness within the server's hint is acceptable.
        """
        self._require_connected()
        tools: list[mcp_types.Tool] = []
        routes: dict[str, ToolRoute] = {}
        clients = list(self._clients.items())
        tool_lists = await gather(
            client.list_tools(cache_mode=cache_mode) for _, client in clients
        )

        for (server_name, client), server_tools in zip(
            clients, tool_lists, strict=True
        ):
            for tool in server_tools:
                public_name = f"{server_name}_{tool.name}"
                if public_name in routes:
                    raise ValueError(f"Tool name collision: {public_name!r}")
                routes[public_name] = ToolRoute(
                    server_name=server_name,
                    client=client,
                    upstream_name=tool.name,
                )
                tools.append(tool.model_copy(update={"name": public_name}))

        self._tool_routes = routes
        self._catalog_loaded = True
        return tools

    async def list_skills(
        self, *, cache_mode: CacheMode = "use"
    ) -> dict[str, list[MCPSkill]]:
        """List skills from every client that negotiated the Skills extension.

        Results are keyed by server name, since skill URIs are only unique
        within one server. Clients without the extension, because they didn't
        pass `SkillsClientExtension()` or their server doesn't advertise it,
        are left out.
        """
        self._require_connected()
        clients = [
            (name, client)
            for name, client in self._clients.items()
            if client._skills_unavailable_reason() is None
        ]
        skill_lists = await gather(
            client.list_skills(cache_mode=cache_mode) for _, client in clients
        )
        return {
            name: skills for (name, _), skills in zip(clients, skill_lists, strict=True)
        }

    async def get_skill(
        self, server_name: str, uri: str, *, cache_mode: CacheMode = "use"
    ) -> MCPSkill:
        """Fetch one skill entry from the named server."""
        client = self._get_connected_client(server_name)
        return await client.get_skill(uri, cache_mode=cache_mode)

    async def read_skill(
        self, server_name: str, uri: str, *, cache_mode: CacheMode = "use"
    ) -> Skill:
        """Read one whole skill from the named server; see `Client.read_skill`."""
        client = self._get_connected_client(server_name)
        return await client.read_skill(uri, cache_mode=cache_mode)

    async def resolve_tool(self, name: str) -> ToolRoute:
        """Resolve a public tool name to its client and upstream identity.

        A known route only requires its own client to be connected; one dead
        server does not couple failures onto calls routed to healthy servers.
        Loading the catalog (the first resolution, or after a refresh) still
        requires every client, since discovery queries them all.
        """
        route = self._tool_routes.get(name)
        if route is not None:
            self._require_route_connected(route)
            return route
        if self._catalog_loaded:
            raise KeyError(
                f"Unknown tool: {name!r}. If servers changed their tools,"
                " call list_tools() to refresh the catalog."
            )

        async with self._route_lock:
            route = self._tool_routes.get(name)
            if route is not None:
                return route
            if not self._catalog_loaded:
                # Lazy cold-start discovery may serve a cached listing; only an
                # explicit list_tools() call promises a refreshed catalog.
                await self.list_tools(cache_mode="use")
                route = self._tool_routes.get(name)

        if route is None:
            raise KeyError(
                f"Unknown tool: {name!r}. If servers changed their tools,"
                " call list_tools() to refresh the catalog."
            )
        return route

    async def call_tool_mcp(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: datetime.timedelta | float | int | None = None,
        progress_handler: ProgressHandler | None = None,
        meta: dict[str, Any] | None = None,
    ) -> mcp_types.CallToolResult:
        """Call a namespaced tool and return its raw MCP result."""
        route = await self.resolve_tool(name)
        return await route.client.call_tool_mcp(
            route.upstream_name,
            arguments or {},
            timeout=timeout,
            progress_handler=progress_handler,
            meta=meta,
        )

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        version: str | None = None,
        timeout: datetime.timedelta | float | int | None = None,
        progress_handler: ProgressHandler | None = None,
        raise_on_error: bool = True,
        meta: dict[str, Any] | None = None,
    ) -> CallToolResult:
        """Call a namespaced tool through the client that advertised it."""
        route = await self.resolve_tool(name)
        return await route.client.call_tool(
            route.upstream_name,
            arguments,
            version=version,
            timeout=timeout,
            progress_handler=progress_handler,
            raise_on_error=raise_on_error,
            meta=meta,
        )
