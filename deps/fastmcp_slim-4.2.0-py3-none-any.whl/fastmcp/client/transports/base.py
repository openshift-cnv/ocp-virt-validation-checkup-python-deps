import abc
import contextlib
from collections.abc import AsyncGenerator, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal, TypeVar

import httpx2
import mcp_types
from mcp import ClientSession
from mcp.client.extension import NotificationBinding, ResultClaim
from mcp.client.session import (
    ElicitationFnT,
    ListRootsFnT,
    LoggingFnT,
    MessageHandlerFnT,
    SamplingFnT,
)
from mcp.shared._httpx_utils import McpHttpClientFactory
from typing_extensions import TypedDict, Unpack

from fastmcp.client._version_pin import pinned_call

# TypeVar for preserving specific ClientTransport subclass types
ClientTransportT = TypeVar("ClientTransportT", bound="ClientTransport")

#: Attribute set on factories generated from a transport's ``verify`` setting.
#: A non-default factory without this marker was supplied by the caller (for
#: proxies, mTLS, custom headers, ...) and takes precedence over ``verify``.
#: The value is exactly ``True``; dynamic attribute lookup (proxies, mocks)
#: must not be mistaken for the marker.
_VERIFY_FACTORY_MARKER = "_fastmcp_verify_factory"


def _mark_verify_factory(factory: McpHttpClientFactory) -> McpHttpClientFactory:
    """Tag a factory generated from ``verify`` so it can be told apart from a
    caller-supplied factory."""
    setattr(factory, _VERIFY_FACTORY_MARKER, True)
    return factory


def _is_verify_replaceable_factory(factory: object) -> bool:
    """Whether a Client-level ``verify`` may replace this OAuth factory.

    Only the bare ``httpx2.AsyncClient`` default and factories generated from
    a transport's own ``verify`` setting are replaceable. A caller-supplied
    factory must be preserved.
    """
    if factory is httpx2.AsyncClient:
        return True
    return getattr(factory, _VERIFY_FACTORY_MARKER, False) is True


class ClientSessionKwargs(TypedDict, total=False):
    """Keyword arguments for the MCP ClientSession constructor."""

    read_timeout_seconds: float | None
    sampling_callback: SamplingFnT | None
    sampling_capabilities: mcp_types.SamplingCapability | None
    list_roots_callback: ListRootsFnT | None
    logging_callback: LoggingFnT | None
    log_level: mcp_types.LoggingLevel | None
    elicitation_callback: ElicitationFnT | None
    message_handler: MessageHandlerFnT | None
    client_info: mcp_types.Implementation | None
    notification_bindings: Sequence[NotificationBinding[Any]] | None
    extensions: dict[str, dict[str, Any]] | None
    result_claims: Mapping[str, Sequence[ResultClaim[Any]]] | None


class VersionAwareClientSession(ClientSession):
    """A session that skips output-schema revalidation for mismatched pinned calls.

    ``ClientSession.call_tool`` revalidates a tool's structured content against
    the output schema the server advertised, looked up by tool *name*. That
    cache holds only the listed (highest) version's schema, so a call pinned to
    a different version -- which the server executes as the requested version
    -- would be checked against a schema that does not describe its result.

    The session records the version each listed tool advertises in
    ``_meta.fastmcp.version``. A pinned call to that version validates as
    usual; a pinned call to any other version skips the check, since its schema
    is not obtainable over the wire. Every unpinned call validates as before.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._tool_listed_versions: dict[str, str | None] = {}

    def _absorb_tool_listing(
        self, result: mcp_types.ListToolsResult, *, complete: bool
    ) -> mcp_types.ListToolsResult:
        result = super()._absorb_tool_listing(result, complete=complete)
        if complete:
            self._tool_listed_versions = {}
        for tool in result.tools:
            fastmcp_meta = (tool.meta or {}).get("fastmcp")
            version = (
                fastmcp_meta.get("version") if isinstance(fastmcp_meta, dict) else None
            )
            self._tool_listed_versions[tool.name] = (
                str(version) if version is not None else None
            )
        return result

    async def validate_tool_result(
        self, name: str, result: mcp_types.CallToolResult
    ) -> None:
        pin = pinned_call.get()
        if pin is not None and pin.session is self:
            if name not in self._tool_output_schemas:
                await self.list_tools()
            if self._tool_listed_versions.get(name) != pin.version:
                return
        await super().validate_tool_result(name, result)


@dataclass(frozen=True)
class TransportOptions:
    """How one client wants its connection built.

    These belong to the client rather than to the transport, so a transport
    shared between clients doesn't leak one client's settings to another.
    Different client layers may own different fields; a layer that adds its
    settings must preserve the existing options rather than replace the bundle.

    Attributes:
        session_class: The ClientSession class to instantiate. The default
            skips output-schema validation for a tool call pinned to a version
            other than the listed one, whose result no advertised schema
            describes; proxies additionally
            supply a session that skips it for every result, since they relay
            rather than consume them.
        forward_incoming_headers: Whether to forward eligible inbound HTTP
            headers upstream, including authorization. Hop-specific HTTP headers
            and MCP transport, routing, and event-stream state are excluded
            because each backend connection owns that state. Only appropriate
            for proxies; honored by the HTTP and SSE transports and ignored by
            the others.
        backend_mode: The connect `mode` to give backend clients that a wrapping
            transport builds on this client's behalf, so a chain of connections
            speaks one protocol era end to end. `None` leaves each backend
            client at its own default. Honored by `MCPConfigTransport`, whose
            multi-server form mounts a proxy per configured server and resolves
            one shared era for the aggregate; ignored by transports that connect
            to a single backend directly, since those carry the connecting
            client's own session and era.
    """

    session_class: type[ClientSession] = VersionAwareClientSession
    forward_incoming_headers: bool = False
    backend_mode: str | None = None


# SessionKwargs stays exactly the ClientSession constructor's parameters, so a
# transport can splat it into ClientSession without filtering.
SessionKwargs = ClientSessionKwargs


class ClientTransport(abc.ABC):
    """
    Abstract base class for different MCP client transport mechanisms.

    A Transport is responsible for establishing and managing connections
    to an MCP server, and providing a ClientSession within an async context.

    """

    #: Whether this transport can only carry the legacy (handshake) protocol era.
    #: The modern `2026-07-28` era is sessionless and served over Streamable HTTP;
    #: the SSE transport predates it and cannot serve it. When True, a client with
    #: `mode="auto"` negotiates the legacy handshake directly rather than probing
    #: `server/discover` (which some servers answer over SSE but then cannot serve).
    legacy_only: bool = False

    @abc.abstractmethod
    @contextlib.asynccontextmanager
    async def connect_session(
        self,
        *,
        transport_options: TransportOptions | None = None,
        **session_kwargs: Unpack[SessionKwargs],
    ) -> AsyncGenerator[ClientSession, None]:
        """
        Establishes a connection and yields an active ClientSession.

        The ClientSession is *not* expected to be initialized in this context manager.

        The session is guaranteed to be valid only within the scope of the
        async context manager. Connection setup and teardown are handled
        within this context.

        Args:
            transport_options: How the connecting client wants this connection
                               built. Defaults apply when omitted. A transport
                               that wraps others must pass this along.
            **session_kwargs: Keyword arguments to pass to the ClientSession
                              constructor (e.g., callbacks, timeouts).

        Yields:
            A mcp.ClientSession instance.
        """
        raise NotImplementedError
        yield  # ty:ignore[invalid-yield]

    def __repr__(self) -> str:
        # Basic representation for subclasses
        return f"<{self.__class__.__name__}>"

    async def close(self):  # noqa: B027
        """Close the transport."""

    def get_session_id(self) -> str | None:
        """Get the session ID for this transport, if available."""
        return None

    def _set_auth(self, auth: httpx2.Auth | Literal["oauth"] | str | None):
        if auth is not None:
            raise ValueError("This transport does not support auth")
