from __future__ import annotations

import csv
from io import StringIO
from typing import Any

from benedict.serializers.abstract import AbstractSerializer
from benedict.utils import type_util


class CSVSerializer(AbstractSerializer[str, list[dict[str, Any]]]):
    """
    This class describes a csv serializer.
    """

    def __init__(self) -> None:
        super().__init__(
            extensions=[
                "csv",
            ],
        )

    def decode(self, s: str, **kwargs: Any) -> list[dict[str, Any]]:
        # kwargs.setdefault('delimiter', ',')
        if kwargs.pop("quote", False):
            # TODO: add tests coverage
            kwargs.setdefault("quoting", csv.QUOTE_ALL)
        columns = kwargs.pop("columns", None)
        columns_row = kwargs.pop("columns_row", True)
        # let csv handle line endings and preserve newlines in quoted fields
        f = StringIO(s, newline="")
        r = csv.reader(f, **kwargs)
        ln = 0
        data = []
        for row in r:
            if ln == 0 and columns_row:
                if not columns:
                    columns = row
                ln += 1
                continue
            d = dict(zip(columns, row))
            data.append(d)
            ln += 1
        return data

    def encode(self, d: list[dict[str, Any]], **kwargs: Any) -> str:
        ls = d
        # kwargs.setdefault('delimiter', ',')
        if kwargs.pop("quote", False):
            kwargs.setdefault("quoting", csv.QUOTE_ALL)
        kwargs.setdefault("lineterminator", "\n")
        columns = kwargs.pop("columns", None)
        columns_row = kwargs.pop("columns_row", True)
        headers = columns
        if not columns and len(ls) and type_util.is_dict(ls[0]):
            # keep original keys for values lookup, use their string labels as headers
            columns = sorted(ls[0].keys(), key=str)
            headers = [str(key) for key in columns]
        f = StringIO()
        w = csv.writer(f, **kwargs)
        if columns_row and columns:
            w.writerow(headers)
        for item in ls:
            if type_util.is_dict(item):
                row = [item.get(key, "") for key in columns]
            elif type_util.is_collection(item):  # type: ignore[unreachable]
                # TODO: add tests coverage
                row = item
            else:
                # TODO: add tests coverage
                row = [item]
            w.writerow(row)
        data = f.getvalue()
        return data
