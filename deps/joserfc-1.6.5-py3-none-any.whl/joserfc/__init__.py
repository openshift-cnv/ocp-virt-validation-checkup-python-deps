__version__ = "1.6.5"
__homepage__ = "https://jose.authlib.org/en/"
__author__ = "Hsiaoming Yang <me@lepture.com>"
__license__ = "BSD-3-Clause"
