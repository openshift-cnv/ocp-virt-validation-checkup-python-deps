"""FastMCPProvider for wrapping FastMCP servers as providers.

This module provides the `FastMCPProvider` class that wraps a FastMCP server
and exposes its components through the Provider interface.

It also provides FastMCPProvider* component classes that delegate execution to
the wrapped server's middleware, ensuring middleware runs when components are
executed.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator, Generator, Sequence
from contextlib import asynccontextmanager, contextmanager
from typing import TYPE_CHECKING, Any

from pydantic import AnyUrl

from fastmcp.prompts.base import Prompt, PromptResult
from fastmcp.resources.base import Resource, ResourceResult
from fastmcp.resources.template import ResourceTemplate, forward_uri
from fastmcp.server.providers.base import Provider
from fastmcp.server.telemetry import delegate_span
from fastmcp.tools.base import Tool, ToolResult
from fastmcp.utilities.components import FastMCPComponent
from fastmcp.utilities.versions import VersionSpec

if TYPE_CHECKING:
    from fastmcp.server.extensions import ServerExtension
    from fastmcp.server.server import FastMCP


# -----------------------------------------------------------------------------
# FastMCPProvider component classes
# -----------------------------------------------------------------------------


class FastMCPProviderTool(Tool):
    """Tool that delegates execution to a wrapped server's middleware.

    When `run()` is called, this tool invokes the wrapped server's
    `_call_tool_middleware()` method, ensuring the server's middleware
    chain is executed.
    """

    _server: Any = None  # FastMCP, but Any to avoid circular import
    _original_name: str | None = None

    def __init__(
        self,
        server: Any,
        original_name: str,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._server = server
        self._original_name = original_name

    @classmethod
    def wrap(cls, server: Any, tool: Tool) -> FastMCPProviderTool:
        """Wrap a Tool to delegate execution to the server's middleware."""
        return cls(
            server=server,
            original_name=tool.name,
            name=tool.name,
            version=tool.version,
            description=tool.description,
            parameters=tool.parameters,
            output_schema=tool.output_schema,
            tags=tool.tags,
            annotations=tool.annotations,
            task_config=tool.task_config,
            execution=tool.execution,
            meta=tool.get_meta(),
            title=tool.title,
            icons=tool.icons,
        )

    async def _run(self, arguments: dict[str, Any]) -> ToolResult:
        """Delegate to the child server's call_tool().

        fn_key is already set by the parent server before calling this method. A
        child tool that requests client input (SEP-2322) returns an
        `InputRequiredToolResult`, which forwards through this delegation to the
        parent's wire handler unchanged.
        """
        from fastmcp.server.extensions import _delegate_extension_interceptors

        # Pass exact version so child executes the correct version
        version = VersionSpec(eq=self.version) if self.version else None

        with (
            _delegate_extension_interceptors(self._server),
            delegate_span(
                self._original_name or "",
                "FastMCPProvider",
                self._original_name or "",
                method="tools/call",
            ),
        ):
            return await self._server.call_tool(
                self._original_name,
                arguments,
                version=version,
            )

    async def run(self, arguments: dict[str, Any]) -> ToolResult:
        """Delegate to the child server's call_tool().

        This is called when the tool is used within a TransformedTool
        forwarding function or other contexts.
        """
        from fastmcp.server.extensions import _delegate_extension_interceptors

        # Pass exact version so child executes the correct version
        version = VersionSpec(eq=self.version) if self.version else None

        with _delegate_extension_interceptors(self._server):
            return await self._server.call_tool(
                self._original_name, arguments, version=version
            )

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.provider.type": "FastMCPProvider",
            "fastmcp.delegate.original_name": self._original_name,
        }


class FastMCPProviderResource(Resource):
    """Resource that delegates reading to a wrapped server's read_resource().

    When `read()` is called, this resource invokes the wrapped server's
    `read_resource()` method, ensuring the server's middleware chain is executed.
    """

    _server: Any = None  # FastMCP, but Any to avoid circular import
    _original_uri: str | None = None

    def __init__(
        self,
        server: Any,
        original_uri: str,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._server = server
        self._original_uri = original_uri

    @classmethod
    def wrap(cls, server: Any, resource: Resource) -> FastMCPProviderResource:
        """Wrap a Resource to delegate reading to the server's middleware."""
        return cls(
            server=server,
            original_uri=str(resource.uri),
            uri=resource.uri,
            version=resource.version,
            name=resource.name,
            description=resource.description,
            mime_type=resource.mime_type,
            tags=resource.tags,
            annotations=resource.annotations,
            task_config=resource.task_config,
            meta=resource.get_meta(),
            title=resource.title,
            icons=resource.icons,
        )

    async def _read(self) -> ResourceResult:
        """Delegate to the child server's read_resource().

        fn_key is already set by the parent server before calling this method.
        """
        # Pass exact version so child reads the correct version
        version = VersionSpec(eq=self.version) if self.version else None

        with delegate_span(
            self._original_uri or "",
            "FastMCPProvider",
            self._original_uri or "",
            method="resources/read",
        ):
            return await self._server.read_resource(self._original_uri, version=version)

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.provider.type": "FastMCPProvider",
            "fastmcp.delegate.original_uri": self._original_uri,
        }


class FastMCPProviderPrompt(Prompt):
    """Prompt that delegates rendering to a wrapped server's render_prompt().

    When `render()` is called, this prompt invokes the wrapped server's
    `render_prompt()` method, ensuring the server's middleware chain is executed.
    """

    _server: Any = None  # FastMCP, but Any to avoid circular import
    _original_name: str | None = None

    def __init__(
        self,
        server: Any,
        original_name: str,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._server = server
        self._original_name = original_name

    @classmethod
    def wrap(cls, server: Any, prompt: Prompt) -> FastMCPProviderPrompt:
        """Wrap a Prompt to delegate rendering to the server's middleware."""
        return cls(
            server=server,
            original_name=prompt.name,
            name=prompt.name,
            version=prompt.version,
            description=prompt.description,
            arguments=prompt.arguments,
            tags=prompt.tags,
            task_config=prompt.task_config,
            meta=prompt.get_meta(),
            title=prompt.title,
            icons=prompt.icons,
        )

    async def _render(self, arguments: dict[str, Any] | None = None) -> PromptResult:
        """Delegate to the child server's render_prompt().

        fn_key is already set by the parent server before calling this method.
        """
        # Pass exact version so child renders the correct version
        version = VersionSpec(eq=self.version) if self.version else None

        with delegate_span(
            self._original_name or "",
            "FastMCPProvider",
            self._original_name or "",
            method="prompts/get",
        ):
            return await self._server.render_prompt(
                self._original_name, arguments, version=version
            )

    async def render(self, arguments: dict[str, Any] | None = None) -> PromptResult:
        """Delegate to the child server's render_prompt().

        This is called when the prompt is used within a transformed context
        or other contexts.
        """
        # Pass exact version so child renders the correct version
        version = VersionSpec(eq=self.version) if self.version else None

        return await self._server.render_prompt(
            self._original_name, arguments, version=version
        )

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.provider.type": "FastMCPProvider",
            "fastmcp.delegate.original_name": self._original_name,
        }


class FastMCPProviderResourceTemplate(ResourceTemplate):
    """Resource template that creates FastMCPProviderResources.

    When `create_resource()` is called, this template creates a
    FastMCPProviderResource that will invoke the wrapped server's middleware
    when read.
    """

    _server: Any = None  # FastMCP, but Any to avoid circular import
    _original_uri_template: str | None = None

    def __init__(
        self,
        server: Any,
        original_uri_template: str,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._server = server
        self._original_uri_template = original_uri_template

    @classmethod
    def wrap(
        cls, server: Any, template: ResourceTemplate
    ) -> FastMCPProviderResourceTemplate:
        """Wrap a ResourceTemplate to create FastMCPProviderResources."""
        wrapped = cls(
            server=server,
            original_uri_template=template.uri_template,
            uri_template=template.uri_template,
            version=template.version,
            name=template.name,
            description=template.description,
            mime_type=template.mime_type,
            parameters=template.parameters,
            tags=template.tags,
            annotations=template.annotations,
            task_config=template.task_config,
            meta=template.get_meta(),
            title=template.title,
            icons=template.icons,
            security=template.security,
        )
        # Mounts wrap every template on every list, so share the source's
        # compiled pattern instead of rebuilding it per wrapper.
        template._compiled_pattern()
        wrapped._pattern = template._pattern
        wrapped._list_query_params = template._list_query_params
        return wrapped

    async def create_resource(self, uri: str, params: dict[str, Any]) -> Resource:
        """Create a FastMCPProviderResource for the given URI.

        The `uri` is the external/transformed URI (e.g., with namespace prefix).
        We use `_original_uri_template` with `params` to construct the internal
        URI that the nested server understands.
        """
        # Expand the original template's path; forward the query as sent
        original_uri = forward_uri(self._original_uri_template or "", params, uri)
        return FastMCPProviderResource(
            server=self._server,
            original_uri=original_uri,
            uri=AnyUrl(uri),
            name=self.name,
            description=self.description,
            mime_type=self.mime_type,
            tags=self.tags,
            annotations=self.annotations,
            meta=self.meta,
            title=self.title,
            icons=self.icons,
        )

    async def _read(self, uri: str, params: dict[str, Any]) -> ResourceResult:
        """Delegate to the child server's read_resource().

        fn_key is already set by the parent server before calling this method.
        """
        # Expand the original template's path; forward the query as sent
        original_uri = forward_uri(self._original_uri_template or "", params, uri)

        # Pass exact version so child reads the correct version
        version = VersionSpec(eq=self.version) if self.version else None

        with delegate_span(
            original_uri,
            "FastMCPProvider",
            self._original_uri_template or "",
            method="resources/read",
        ):
            return await self._server.read_resource(original_uri, version=version)

    def get_span_attributes(self) -> dict[str, Any]:
        return super().get_span_attributes() | {
            "fastmcp.provider.type": "FastMCPProvider",
            "fastmcp.delegate.original_uri_template": self._original_uri_template,
        }


# -----------------------------------------------------------------------------
# FastMCPProvider
# -----------------------------------------------------------------------------


class FastMCPProvider(Provider):
    """Provider that wraps a FastMCP server.

    This provider enables mounting one FastMCP server onto another, exposing
    the mounted server's tools, resources, and prompts through the parent
    server.

    Components returned by this provider are wrapped in FastMCPProvider*
    classes that delegate execution to the wrapped server's middleware chain.
    This ensures middleware runs when components are executed.

    Example:
        ```python
        from fastmcp import FastMCP
        from fastmcp.server.providers import FastMCPProvider

        main = FastMCP("Main")
        sub = FastMCP("Sub")

        @sub.tool
        def greet(name: str) -> str:
            return f"Hello, {name}!"

        # Mount directly - tools accessible by original names
        main.add_provider(FastMCPProvider(sub))

        # Or with namespace
        from fastmcp.server.transforms import Namespace
        provider = FastMCPProvider(sub)
        provider.add_transform(Namespace("sub"))
        main.add_provider(provider)
        ```

    Note:
        Normally you would use `FastMCP.mount()` which handles proxy conversion
        and creates the provider with namespace automatically.
    """

    def __init__(self, server: FastMCP[Any]):
        """Initialize a FastMCPProvider.

        Args:
            server: The FastMCP server to wrap.
        """
        super().__init__()
        self.server = server

    def required_extensions(self) -> Sequence[ServerExtension]:
        """Expose the mounted server's bundled and auto-registerable extensions."""
        return self.server.required_extensions()

    @contextmanager
    def _extension_runtime(
        self, available: frozenset[str], *, root: FastMCP | None
    ) -> Generator[None, None, None]:
        with self.server._extension_runtime(available, root=root):
            yield

    # -------------------------------------------------------------------------
    # Tool methods
    # -------------------------------------------------------------------------

    async def _list_tools(self) -> Sequence[Tool]:
        """List all tools from the mounted server as FastMCPProviderTools.

        Runs the mounted server's middleware so filtering/transformation applies.
        Wraps each tool as a FastMCPProviderTool that delegates execution to
        the nested server's middleware.
        """
        raw_tools = await self.server.list_tools()
        return [FastMCPProviderTool.wrap(self.server, t) for t in raw_tools]

    async def _get_tool(
        self, name: str, version: VersionSpec | None = None
    ) -> Tool | None:
        """Get a tool by name as a FastMCPProviderTool.

        Passes the full VersionSpec to the nested server, which handles both
        exact version matching and range filtering. Uses get_tool to ensure
        the nested server's transforms are applied.
        """
        # Lookups must use the child's state store, just as its list and
        # execution methods do, before the parent applies its own rules.
        from fastmcp.server.context import Context

        async with Context(fastmcp=self.server):
            raw_tool = await self.server.get_tool(name, version)
        if raw_tool is None:
            return None
        return FastMCPProviderTool.wrap(self.server, raw_tool)

    async def get_app_tool(self, app_name: str, tool_name: str) -> Tool | None:
        """Delegate to nested server's get_app_tool, wrapping for middleware."""
        from fastmcp.server.context import Context

        async with Context(fastmcp=self.server):
            raw_tool = await self.server.get_app_tool(app_name, tool_name)
        if raw_tool is None:
            return None
        wrapped = FastMCPProviderTool.wrap(self.server, raw_tool)
        from fastmcp.server.providers.addressing import hashed_backend_name

        wrapped._original_name = hashed_backend_name(app_name, tool_name)
        return wrapped

    async def _get_tool_by_hash(self, tool_hash: str, tool_name: str) -> Tool | None:
        """Delegate to nested server's get_tool_by_hash, wrapping for middleware.

        The nested server applies its own transforms, visibility, and auth.
        The call is forwarded under the hashed name so the nested server
        resolves the same tool again rather than whatever its listed name
        reaches.
        """
        from fastmcp.server.context import Context

        async with Context(fastmcp=self.server):
            raw_tool = await self.server.get_tool_by_hash(tool_hash, tool_name)
        if raw_tool is None:
            return None
        wrapped = FastMCPProviderTool.wrap(self.server, raw_tool)
        wrapped._original_name = f"{tool_hash}_{tool_name}"
        return wrapped

    # -------------------------------------------------------------------------
    # Resource methods
    # -------------------------------------------------------------------------

    async def _list_resources(self) -> Sequence[Resource]:
        """List all resources from the mounted server as FastMCPProviderResources.

        Runs the mounted server's middleware so filtering/transformation applies.
        Wraps each resource as a FastMCPProviderResource that delegates reading
        to the nested server's middleware.
        """
        raw_resources = await self.server.list_resources()
        return [FastMCPProviderResource.wrap(self.server, r) for r in raw_resources]

    async def _get_resource(
        self, uri: str, version: VersionSpec | None = None
    ) -> Resource | None:
        """Get a concrete resource by URI as a FastMCPProviderResource.

        Passes the full VersionSpec to the nested server, which handles both
        exact version matching and range filtering. Uses get_resource to ensure
        the nested server's transforms are applied.
        """
        from fastmcp.server.context import Context

        async with Context(fastmcp=self.server):
            raw_resource = await self.server.get_resource(uri, version)
        if raw_resource is None:
            return None
        return FastMCPProviderResource.wrap(self.server, raw_resource)

    # -------------------------------------------------------------------------
    # Resource template methods
    # -------------------------------------------------------------------------

    async def _list_resource_templates(self) -> Sequence[ResourceTemplate]:
        """List all resource templates from the mounted server.

        Runs the mounted server's middleware so filtering/transformation applies.
        Returns FastMCPProviderResourceTemplate instances that create
        FastMCPProviderResources when materialized.
        """
        raw_templates = await self.server.list_resource_templates()
        return [
            FastMCPProviderResourceTemplate.wrap(self.server, t) for t in raw_templates
        ]

    async def _get_resource_template(
        self, uri: str, version: VersionSpec | None = None
    ) -> ResourceTemplate | None:
        """Get a resource template that matches the given URI.

        Passes the full VersionSpec to the nested server, which handles both
        exact version matching and range filtering. Uses get_resource_template
        to ensure the nested server's transforms are applied.
        """
        from fastmcp.server.context import Context

        async with Context(fastmcp=self.server):
            raw_template = await self.server.get_resource_template(uri, version)
        if raw_template is None:
            return None
        return FastMCPProviderResourceTemplate.wrap(self.server, raw_template)

    # -------------------------------------------------------------------------
    # Prompt methods
    # -------------------------------------------------------------------------

    async def _list_prompts(self) -> Sequence[Prompt]:
        """List all prompts from the mounted server as FastMCPProviderPrompts.

        Runs the mounted server's middleware so filtering/transformation applies.
        Returns FastMCPProviderPrompt instances that delegate rendering to the
        wrapped server's middleware.
        """
        raw_prompts = await self.server.list_prompts()
        return [FastMCPProviderPrompt.wrap(self.server, p) for p in raw_prompts]

    async def _get_prompt(
        self, name: str, version: VersionSpec | None = None
    ) -> Prompt | None:
        """Get a prompt by name as a FastMCPProviderPrompt.

        Passes the full VersionSpec to the nested server, which handles both
        exact version matching and range filtering. Uses get_prompt to ensure
        the nested server's transforms are applied.
        """
        from fastmcp.server.context import Context

        async with Context(fastmcp=self.server):
            raw_prompt = await self.server.get_prompt(name, version)
        if raw_prompt is None:
            return None
        return FastMCPProviderPrompt.wrap(self.server, raw_prompt)

    # -------------------------------------------------------------------------
    # Task registration
    # -------------------------------------------------------------------------

    async def get_tasks(self) -> Sequence[FastMCPComponent]:
        """Return task-eligible components from the mounted server.

        Returns the child's ACTUAL components (not wrapped) so their actual
        functions get registered with Docket. Gets components with child
        server's transforms applied, then applies this provider's transforms
        for correct registration keys.
        """
        # Get tasks with child server's transforms already applied
        components = list(await self.server.get_tasks())

        return [
            c
            for c in await self._apply_task_transforms(components)
            if c.task_config.supports_tasks()
        ]

    # -------------------------------------------------------------------------
    # Lifecycle methods
    # -------------------------------------------------------------------------

    @asynccontextmanager
    async def lifespan(self) -> AsyncGenerator[None, None]:
        """Start the mounted server's lifespan.

        Sets ``_lifespan_root_active=True`` to signal to the wrapped server's
        ``_docket_lifespan`` that it is running below an existing root in the
        same runtime tree, then delegates to its full ``_lifespan_manager``.
        The root's Docket / Worker / SharedContext are reused through
        ContextVars (``_current_docket`` etc.); the mounted server's user
        lifespan, ``_lifespan_result`` cache, and its own sub-providers
        (nested mounts) all run normally.

        The flag is reset as soon as ``_lifespan_manager`` finishes entering,
        so it doesn't leak into the caller's async scope. Unrelated servers
        entered later in the same task (e.g. siblings via ``AsyncExitStack``)
        correctly see no active root and start their own infrastructure.
        """
        from fastmcp.server.mixins.lifespan import _lifespan_root_active

        token = _lifespan_root_active.set(True)
        flag_active = True
        try:
            async with self.server._lifespan_manager():
                # Inner entry is complete; the flag's job (telling _docket_lifespan
                # to no-op during _lifespan_manager's setup) is done. Reset now so
                # unrelated lifespans entered later in this task aren't misclassified
                # as nested.
                _lifespan_root_active.reset(token)
                flag_active = False
                yield
        finally:
            if flag_active:
                _lifespan_root_active.reset(token)
