from collections import defaultdict
from copy import copy
from glob import glob
from gzip import GzipFile
import io
import logging
import os
import os.path as osp
from pathlib import Path
from posixpath import join as pjoin
import tarfile
import unicodedata

from . import common
from .config import isabs_ish

log = logging.getLogger(__name__)


def _normalize_for_match(path):
    """Return *path* in a canonical Unicode form for filename comparison.

    File selection must be normalisation-insensitive. On macOS (APFS/HFS+) a
    name written NFC and the same name written NFD denote a single file but are
    byte-distinct; the include/exclude sets are keyed by ``glob()`` output while
    the candidate names come from ``os.walk`` / the VCS listing, so without this
    an exclude rule written in one form silently fails to match a file stored in
    the other and the file is packed into the sdist anyway (CWE-176, CWE-697).

    NFC (canonical composition) is used deliberately; NFKC must NOT be used, as
    its compatibility folding (e.g. U+FF0F FULLWIDTH SOLIDUS -> '/') would change
    path semantics and could make a rule match unintended files.
    """
    return unicodedata.normalize('NFC', path)


def _symlink_target_escapes(arcname_relpath: str, linkname: str) -> bool:
    """Return whether a symlink would point outside the project / archive root.

    This mirrors the containment check that :mod:`tarfile`'s ``data`` extraction
    filter applies: an absolute target, or a relative target whose ``..``
    components climb above the archive root, would on extraction point outside
    the extraction directory, enabling arbitrary file read/overwrite (a tar-slip
    / path traversal, CWE-22).

    Parameters
    ----------
    arcname_relpath : str
        Path of the symlink relative to the project root, i.e. its location
        within the archive.
    linkname : str
        The raw symlink target, as stored on disk.

    Returns
    -------
    bool
        ``True`` if the link escapes the project root and must be rejected;
        ``False`` if it stays within the tree (including ``..`` that does not
        escape) and is safe to pack.
    """
    if isabs_ish(linkname):
        return True
    resolved = osp.normpath(osp.join(osp.dirname(arcname_relpath), linkname))
    return resolved == os.pardir or resolved.startswith(os.pardir + os.sep)


def clean_tarinfo(ti, mtime=None):
    """Clean metadata from a TarInfo object to make it more reproducible.

    - Set uid & gid to 0
    - Set uname and gname to ""
    - Normalise permissions to 644 or 755
    - Set mtime if not None
    """
    ti = copy(ti)
    ti.uid = 0
    ti.gid = 0
    ti.uname = ''
    ti.gname = ''
    ti.mode = common.normalize_file_permissions(ti.mode)
    if mtime is not None:
        ti.mtime = mtime
    return ti


class FilePatterns:
    """Manage a set of file inclusion/exclusion patterns relative to basedir"""
    def __init__(self, patterns, basedir):
        self.basedir = basedir

        self.dirs = set()
        self.files = set()

        for pattern in patterns:
            for path in sorted(glob(osp.join(basedir, pattern), recursive=True)):
                rel = osp.relpath(path, basedir)
                if osp.isdir(path):
                    self.dirs.add(rel)
                else:
                    self.files.add(rel)

        # Unicode-normalised views used only for matching. The raw self.dirs /
        # self.files are kept unchanged because they are also used to open the
        # actual files on disk, which on a normalisation-sensitive filesystem
        # (e.g. Linux ext4) must use the exact on-disk bytes.
        self._match_files = {_normalize_for_match(f) for f in self.files}
        self._match_dirs = {_normalize_for_match(d) for d in self.dirs}

    def match_file(self, rel_path):
        rel_path = _normalize_for_match(rel_path)
        if rel_path in self._match_files:
            return True

        return any(rel_path.startswith(d + os.sep) for d in self._match_dirs)

    def match_dir(self, rel_path):
        rel_path = _normalize_for_match(rel_path)
        if rel_path in self._match_dirs:
            return True

        # Check if it's a subdirectory of any directory in the list
        return any(rel_path.startswith(d + os.sep) for d in self._match_dirs)


class SdistBuilder:
    """Builds a minimal sdist

    These minimal sdists should work for PEP 517.
    The class is extended in flit.sdist to make a more 'full fat' sdist,
    which is what should normally be published to PyPI.
    """
    def __init__(self, module, metadata, cfgdir, reqs_by_extra, entrypoints,
                 extra_files, data_directory, include_patterns=(), exclude_patterns=()):
        self.module = module
        self.metadata = metadata
        self.cfgdir = cfgdir
        self.reqs_by_extra = reqs_by_extra
        self.entrypoints = entrypoints
        self.extra_files = extra_files
        self.data_directory = data_directory
        self.includes = FilePatterns(include_patterns, str(cfgdir))
        self.excludes = FilePatterns(exclude_patterns, str(cfgdir))

    @classmethod
    def from_ini_path(cls, ini_path: Path):
        # Local import so bootstrapping doesn't try to load toml
        from .config import read_flit_config
        ini_info = read_flit_config(ini_path)
        srcdir = ini_path.parent
        module = common.Module(ini_info.module, srcdir)
        metadata = common.make_metadata(module, ini_info)
        extra_files = [ini_path.name, *map(osp.normpath, ini_info.referenced_files)]
        return cls(
            module, metadata, srcdir, ini_info.reqs_by_extra,
            ini_info.entrypoints, extra_files, ini_info.data_directory,
            ini_info.sdist_include_patterns, ini_info.sdist_exclude_patterns,
        )

    def prep_entry_points(self):
        # Reformat entry points from dict-of-dicts to dict-of-lists
        res = defaultdict(list)
        for groupname, group in self.entrypoints.items():
            for name, ep in sorted(group.items()):
                res[groupname].append(f'{name} = {ep}')

        return dict(res)

    def select_files(self):
        """Pick which files from the source tree will be included in the sdist

        This is overridden in flit itself to use information from a VCS to
        include tests, docs, etc. for a 'gold standard' sdist.
        """
        cfgdir_s = str(self.cfgdir)
        return [
            osp.relpath(p, cfgdir_s) for p in self.module.iter_files()
        ] + [
            osp.relpath(p, cfgdir_s) for p in common.walk_data_dir(self.data_directory)
        ] + self.extra_files

    def apply_includes_excludes(self, files):
        cfgdir_s = str(self.cfgdir)
        files = {f for f in files if not self.excludes.match_file(f)}

        for f_rel in self.includes.files:
            if not self.excludes.match_file(f_rel):
                files.add(f_rel)

        for rel_d in self.includes.dirs:
            for dirpath, dirs, dfiles in os.walk(osp.join(cfgdir_s, rel_d)):
                for file in dfiles:
                    f_abs = osp.join(dirpath, file)
                    f_rel = osp.relpath(f_abs, cfgdir_s)
                    if not self.excludes.match_file(f_rel):
                        files.add(f_rel)

                # Filter subdirectories before os.walk scans them
                dirs[:] = [d for d in dirs if not self.excludes.match_dir(
                    osp.relpath(osp.join(dirpath, d), cfgdir_s)
                )]

        crucial_files = set(self.extra_files)
        if not self.module.is_stub_pkg:
            crucial_files.add(str(self.module.file.relative_to(self.cfgdir)))
        # Compare normalisation-insensitively (the selected names come from
        # os.walk and may be NFD on macOS, while crucial names come from config
        # and are typically NFC); otherwise a present crucial file could be
        # falsely reported as missing and abort an otherwise valid build.
        selected = {_normalize_for_match(f) for f in files}
        missing_crucial = {
            f for f in crucial_files if _normalize_for_match(f) not in selected
        }
        if missing_crucial:
            raise Exception("Crucial files were excluded from the sdist: {}"
                            .format(", ".join(missing_crucial)))

        return sorted(files)

    @property
    def dir_name(self):
        return common.normalize_dist_name(self.metadata.name, self.metadata.version)

    def build(self, target_dir):
        os.makedirs(str(target_dir), exist_ok=True)
        target = target_dir / f'{self.dir_name}.tar.gz'
        source_date_epoch = os.environ.get('SOURCE_DATE_EPOCH', '')
        mtime = int(source_date_epoch) if source_date_epoch else None
        # For the gzip timestamp, default to 2016-1-1 00:00 (UTC)
        # This makes the sdist reproducible even without SOURCE_DATE_EPOCH,
        # if the source file mtimes don't change, i.e. from the same checkout.
        gz = GzipFile(str(target), mode='wb', mtime=(mtime or 1451606400))
        tf = tarfile.TarFile(str(target), mode='w', fileobj=gz,
                             format=tarfile.PAX_FORMAT)

        try:
            files_to_add = self.apply_includes_excludes(self.select_files())

            for relpath in files_to_add:
                path = str(self.cfgdir / relpath)
                ti = tf.gettarinfo(path, arcname=pjoin(self.dir_name, relpath))
                ti = clean_tarinfo(ti, mtime)

                if ti.issym() and _symlink_target_escapes(relpath, ti.linkname):
                    raise Exception(
                        f"Refusing to build sdist: the symlink {relpath!r} points "
                        f"outside the project directory (target: {ti.linkname!r}). "
                        f"Such a link would escape the extraction directory when "
                        f"the sdist is unpacked (path traversal)."
                    )

                if ti.isreg():
                    with open(path, 'rb') as f:
                        tf.addfile(ti, f)
                else:
                    tf.addfile(ti)  # Symlinks (kept only if within the tree)

            stream = io.StringIO()
            self.metadata.write_metadata_file(stream)
            pkg_info = stream.getvalue().encode()
            ti = tarfile.TarInfo(pjoin(self.dir_name, 'PKG-INFO'))
            ti.size = len(pkg_info)
            tf.addfile(ti, io.BytesIO(pkg_info))

        finally:
            tf.close()
            gz.close()

        log.info("Built sdist: %s", target)
        return target
