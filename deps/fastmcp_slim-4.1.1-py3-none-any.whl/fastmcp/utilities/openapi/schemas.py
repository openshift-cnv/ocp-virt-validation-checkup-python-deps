"""Schema manipulation utilities for OpenAPI operations."""

import re
from collections import Counter
from typing import Any

from fastmcp.utilities.logging import get_logger

from .json_schema_converter import convert_openapi_schema_to_json_schema
from .models import HTTPRoute, JsonSchema, ResponseInfo

logger = get_logger(__name__)


def clean_schema_for_display(schema: JsonSchema | None) -> JsonSchema | None:
    """
    Clean up a schema dictionary for display by removing internal/complex fields.
    """
    if not schema or not isinstance(schema, dict):
        return schema

    # Make a copy to avoid modifying the input schema
    cleaned = schema.copy()

    # Fields commonly removed for simpler display to LLMs or users
    fields_to_remove = [
        "allOf",
        "anyOf",
        "oneOf",
        "not",  # Composition keywords
        "nullable",  # Handled by type unions usually
        "discriminator",
        "readOnly",
        "writeOnly",
        "deprecated",
        "xml",
        "externalDocs",
        # Can be verbose, maybe remove based on flag?
        # "pattern", "minLength", "maxLength",
        # "minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum",
        # "multipleOf", "minItems", "maxItems", "uniqueItems",
        # "minProperties", "maxProperties"
    ]

    for field in fields_to_remove:
        if field in cleaned:
            cleaned.pop(field)

    # Recursively clean properties and items
    if "properties" in cleaned:
        cleaned["properties"] = {
            k: clean_schema_for_display(v) for k, v in cleaned["properties"].items()
        }
        # Remove properties section if empty after cleaning
        if not cleaned["properties"]:
            cleaned.pop("properties")

    if "items" in cleaned:
        cleaned["items"] = clean_schema_for_display(cleaned["items"])
        # Remove items section if empty after cleaning
        if not cleaned["items"]:
            cleaned.pop("items")

    if "additionalProperties" in cleaned:
        # Often verbose, can be simplified
        if isinstance(cleaned["additionalProperties"], dict):
            cleaned["additionalProperties"] = clean_schema_for_display(
                cleaned["additionalProperties"]
            )
        elif cleaned["additionalProperties"] is True:
            # Maybe keep 'true' or represent as 'Allows additional properties' text?
            pass  # Keep simple boolean for now

    return cleaned


def _replace_ref_with_defs(
    info: dict[str, Any], description: str | None = None
) -> dict[str, Any]:
    """
    Replace openapi $ref with jsonschema $defs recursively.

    Examples:
    - {"type": "object", "properties": {"$ref": "#/components/schemas/..."}}
    - {"type": "object", "additionalProperties": {"$ref": "#/components/schemas/..."}, "properties": {...}}
    - {"$ref": "#/components/schemas/..."}
    - {"items": {"$ref": "#/components/schemas/..."}}
    - {"anyOf": [{"$ref": "#/components/schemas/..."}]}
    - {"allOf": [{"$ref": "#/components/schemas/..."}]}
    - {"oneOf": [{"$ref": "#/components/schemas/..."}]}

    Args:
        info: dict[str, Any]
        description: str | None

    Returns:
        dict[str, Any]
    """
    schema = info.copy()
    if ref_path := schema.get("$ref"):
        if isinstance(ref_path, str):
            if ref_path.startswith("#/components/schemas/"):
                schema_name = ref_path.split("/")[-1]
                schema["$ref"] = f"#/$defs/{schema_name}"
            elif not ref_path.startswith("#/"):
                raise ValueError(
                    f"External or non-local reference not supported: {ref_path}. "
                    f"FastMCP only supports local schema references starting with '#/'. "
                    f"Please include all schema definitions within the OpenAPI document."
                )
    if properties := schema.get("properties"):
        if "$ref" in properties:
            schema["properties"] = _replace_ref_with_defs(properties)
        else:
            schema["properties"] = {
                prop_name: _replace_ref_with_defs(prop_schema)
                for prop_name, prop_schema in properties.items()
            }
    if item_schema := schema.get("items"):
        schema["items"] = _replace_ref_with_defs(item_schema)
    if "prefixItems" in schema:
        schema["prefixItems"] = [
            _replace_ref_with_defs(item) if isinstance(item, dict) else item
            for item in schema["prefixItems"]
        ]
    for section in ["anyOf", "allOf", "oneOf"]:
        if section in schema:
            schema[section] = [_replace_ref_with_defs(item) for item in schema[section]]
    if additionalProperties := schema.get("additionalProperties"):
        if not isinstance(additionalProperties, bool):
            schema["additionalProperties"] = _replace_ref_with_defs(
                additionalProperties
            )
    # Handle propertyNames
    if property_names := schema.get("propertyNames"):
        if isinstance(property_names, dict):
            schema["propertyNames"] = _replace_ref_with_defs(property_names)
    # Handle patternProperties
    if pattern_properties := schema.get("patternProperties"):
        if isinstance(pattern_properties, dict):
            schema["patternProperties"] = {
                pattern: _replace_ref_with_defs(subschema)
                if isinstance(subschema, dict)
                else subschema
                for pattern, subschema in pattern_properties.items()
            }
    if info.get("description", description) and not schema.get("description"):
        schema["description"] = description
    return schema


def _make_optional_parameter_nullable(schema: dict[str, Any]) -> dict[str, Any]:
    """
    Make an optional parameter schema nullable to allow None values.

    For optional parameters, we need to allow null values in addition to the
    specified type to handle cases where None is passed for optional parameters.
    """
    # If schema already has multiple types or is already nullable, don't modify
    if "anyOf" in schema or "oneOf" in schema or "allOf" in schema:
        return schema

    # If it's already nullable (type includes null), don't modify
    if isinstance(schema.get("type"), list) and "null" in schema["type"]:
        return schema

    # Create a new schema that allows null in addition to the original type
    if "type" in schema:
        original_type = schema["type"]
        if isinstance(original_type, str):
            # Handle different types appropriately
            if original_type in ("array", "object"):
                # For complex types (array/object), preserve the full structure
                # and allow null as an alternative
                if original_type == "array" and "items" in schema:
                    # Array with items - preserve items in anyOf branch
                    array_schema = schema.copy()
                    top_level_fields = ["default", "description", "title", "example"]
                    nullable_schema = {}

                    # Move top-level fields to the root
                    for field in top_level_fields:
                        if field in array_schema:
                            nullable_schema[field] = array_schema.pop(field)

                    nullable_schema["anyOf"] = [array_schema, {"type": "null"}]
                    return nullable_schema

                elif original_type == "object" and "properties" in schema:
                    # Object with properties - preserve properties in anyOf branch
                    object_schema = schema.copy()
                    top_level_fields = ["default", "description", "title", "example"]
                    nullable_schema = {}

                    # Move top-level fields to the root
                    for field in top_level_fields:
                        if field in object_schema:
                            nullable_schema[field] = object_schema.pop(field)

                    nullable_schema["anyOf"] = [object_schema, {"type": "null"}]
                    return nullable_schema
                else:
                    # Simple object/array without items/properties
                    nullable_schema = {}
                    original_schema = schema.copy()
                    top_level_fields = ["default", "description", "title", "example"]

                    for field in top_level_fields:
                        if field in original_schema:
                            nullable_schema[field] = original_schema.pop(field)

                    nullable_schema["anyOf"] = [original_schema, {"type": "null"}]
                    return nullable_schema
            else:
                # Simple types (string, integer, number, boolean)
                top_level_fields = ["default", "description", "title", "example"]
                nullable_schema = {}
                original_schema = schema.copy()

                for field in top_level_fields:
                    if field in original_schema:
                        nullable_schema[field] = original_schema.pop(field)

                nullable_schema["anyOf"] = [original_schema, {"type": "null"}]
                return nullable_schema

    return schema


_MAX_COMPOSITION_MEMBERS = 100_000


def _allof_members(
    schema: dict[str, Any],
    schema_defs: dict[str, Any],
    resolving: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Collect local composition members, reusing shared definition results."""
    cached: dict[int, tuple[dict[str, Any], list[dict[str, Any]], frozenset[str]]] = {}
    active: set[tuple[int, frozenset[str]]] = set()
    retained = 0
    visits = 0
    merged = 0

    def collect(
        node: dict[str, Any], refs: set[str]
    ) -> tuple[list[dict[str, Any]], frozenset[str], bool]:
        nonlocal retained, visits, merged
        visits += 1
        if visits > _MAX_COMPOSITION_MEMBERS:
            raise ValueError("Schema composition has too many visited members")
        identity = id(node)
        context = (identity, frozenset(refs))
        if context in active:
            return [node], frozenset(), True
        cached_entry = cached.get(identity)
        if cached_entry is not None and not refs.intersection(cached_entry[2]):
            return cached_entry[1], cached_entry[2], False
        active.add(context)
        members: dict[int, dict[str, Any]] = {}
        dependencies: set[str] = set()
        contextual = False

        def append(items: list[dict[str, Any]]) -> None:
            nonlocal merged
            merged += len(items)
            if merged > _MAX_COMPOSITION_MEMBERS:
                raise ValueError("Schema composition has too many merged members")
            # Preserve the last occurrence's position, which determines the
            # existing property merge order when definitions share a field.
            for item in items:
                key = id(item)
                members.pop(key, None)
                members[key] = item

        ref = node.get("$ref")
        referenced = None
        name = ""
        if isinstance(ref, str):
            for prefix in ("#/$defs/", "#/components/schemas/"):
                if ref.startswith(prefix):
                    name = ref.removeprefix(prefix)
                    dependencies.add(name)
                    referenced = schema_defs.get(name) if name not in refs else None
                    contextual |= name in refs
                    break
        children: list[tuple[dict[str, Any], set[str]]] = []
        trailing: list[dict[str, Any]] = []
        if isinstance(referenced, dict):
            children.append((referenced, refs | {name}))
            siblings = {key: value for key, value in node.items() if key != "$ref"}
            if siblings:
                children.append((siblings, refs))
        elif isinstance(node.get("allOf"), list):
            children.extend(
                (member, refs) for member in node["allOf"] if isinstance(member, dict)
            )
            siblings = {key: value for key, value in node.items() if key != "allOf"}
            if siblings:
                trailing.append(siblings)
        else:
            trailing.append(node)
        for child, child_refs in children:
            items, child_dependencies, child_contextual = collect(child, child_refs)
            merged += len(child_dependencies)
            append(items)
            dependencies.update(child_dependencies)
            contextual |= child_contextual
        append(trailing)
        active.remove(context)
        result = list(members.values())
        dependency_names = frozenset(dependencies)
        retained += len(result) + len(dependency_names)
        if retained > _MAX_COMPOSITION_MEMBERS:
            raise ValueError("Schema composition has too many collected members")
        # A cycle cut depends on this traversal's ancestors. Only reuse complete
        # results, and only when none of their references is currently active.
        if not contextual:
            cached[identity] = (node, result, dependency_names)
        return result, dependency_names, contextual

    return collect(schema, resolving or set())[0]


# Keywords the properties/required merge represents, or that only annotate.
# A discriminator is carried through and expanded by
# _flatten_discriminator_subtypes, which also accounts for its oneOf.
_MERGEABLE_OBJECT_KEYWORDS = frozenset(
    {
        "type",
        "properties",
        "required",
        "title",
        "description",
        "example",
        "examples",
        "deprecated",
        "discriminator",
        "oneOf",
    }
)


def _is_mergeable_object(schema: dict[str, Any]) -> bool:
    """Whether flattening *schema* into ``properties``/``required`` loses nothing.

    Only keywords the merge fully represents are allowed; any other constraint
    (``anyOf``, ``not``, ``patternProperties``, ``additionalProperties``, ...)
    would vanish from the merged schema, so the ``$ref`` is kept instead. A
    ``oneOf`` is representable only beside a discriminator mapping, whose
    subtype fields are flattened in afterwards.
    """
    if schema.get("type", "object") != "object":
        return False
    if not set(schema) <= _MERGEABLE_OBJECT_KEYWORDS:
        return False
    if "oneOf" in schema:
        discriminator = schema.get("discriminator")
        return (
            isinstance(discriminator, dict)
            and isinstance(discriminator.get("propertyName"), str)
            and isinstance(discriminator.get("mapping"), dict)
        )
    return True


def _ref_is_mergeable_object(
    schema: dict[str, Any], schema_defs: dict[str, Any]
) -> bool:
    """Whether *schema*'s ``$ref`` (if any) can be dropped by a property merge."""
    if "$ref" not in schema:
        return True
    return all(
        _is_mergeable_object(member)
        for member in _allof_members({"$ref": schema["$ref"]}, schema_defs)
    )


def _discriminator_target_name(target: str) -> str | None:
    """Resolve a ``discriminator.mapping`` value to a local schema name.

    Mapping values hold "schema names or references", so a bare ``"Cat"`` means
    the ``Cat`` component just as ``"#/components/schemas/Cat"`` does. Anything
    else — a remote URL, a pointer outside the component schemas — has no local
    definition to flatten.
    """
    for prefix in ("#/$defs/", "#/components/schemas/"):
        if target.startswith(prefix):
            return target.removeprefix(prefix) or None
    if target.startswith("#") or "/" in target:
        return None
    return target or None


def _flatten_discriminator_subtypes(
    schema: dict[str, Any],
    schema_defs: dict[str, Any],
) -> dict[str, Any] | None:
    """Flatten the subtypes named by an OpenAPI ``discriminator.mapping``.

    A parent schema carrying a discriminator describes its children only
    through ``mapping``, so the child fields are unreachable from the parent's
    own ``properties``. Rather than emitting a branch per subtype, the fields
    are merged in as optional and the variants are spelled out on the
    discriminator property's description. Top-level ``oneOf`` is filled in
    poorly by LLM tool-calling APIs, and the upstream API remains the real
    validator either way: a field from the wrong variant is rejected there
    rather than locally.

    Only the mapping on *schema* itself is expanded. A subtype carrying its own
    discriminator is left alone, which also keeps the parent/child reference
    cycle from recursing.

    Returns replacement ``properties`` for *schema*, or None when there is no
    usable discriminator mapping to flatten.
    """
    discriminator = schema.get("discriminator")
    if not isinstance(discriminator, dict):
        return None

    property_name = discriminator.get("propertyName")
    mapping = discriminator.get("mapping")
    if not isinstance(property_name, str) or not isinstance(mapping, dict):
        return None

    own_props = schema.get("properties", {})
    # Variants that disagree about a property are unioned rather than resolved:
    # keeping whichever came first would advertise one variant's constraint
    # (a `const` tag, say) while claiming to accept all of them.
    alternatives: dict[str, list[Any]] = {}
    values: list[str] = []
    variants: list[str] = []

    for value, target in mapping.items():
        if not isinstance(target, str):
            continue

        name = _discriminator_target_name(target)
        subtype = schema_defs.get(name) if name else None
        if not isinstance(subtype, dict):
            continue

        # Fields the parent already declares are shared, not variant-specific.
        variant_fields: list[str] = []
        for member in _allof_members(subtype, schema_defs):
            for prop_name, prop_schema in member.get("properties", {}).items():
                if prop_name in own_props:
                    continue
                if prop_name not in variant_fields:
                    variant_fields.append(prop_name)
                seen = alternatives.setdefault(prop_name, [])
                if prop_schema not in seen:
                    seen.append(prop_schema)

        values.append(repr(value))
        if variant_fields:
            variants.append(f"{value!r} uses {', '.join(variant_fields)}")

    # Every resolved variant is a legal tag even when it adds no fields of its
    # own, so the accepted values are worth advertising on their own.
    if not values:
        return None

    subtype_props = {
        prop_name: schemas[0] if len(schemas) == 1 else {"anyOf": schemas}
        for prop_name, schemas in alternatives.items()
    }
    properties = {**own_props, **subtype_props}

    note = f"Selects the variant. Accepted values: {', '.join(values)}."
    if variants:
        note += (
            f" {'; '.join(variants)}."
            " Send only the fields belonging to the selected variant."
        )

    # A discriminator names a property of the payload, so give it a schema even
    # when the parent left it undeclared — it is otherwise required and unusable.
    tag_schema = properties.get(property_name)
    if not isinstance(tag_schema, dict):
        tag_schema = {"type": "string"}
    existing = tag_schema.get("description")
    properties[property_name] = {
        **tag_schema,
        "description": f"{existing} {note}" if existing else note,
    }

    return properties


def _combine_schemas_and_map_params(
    route: HTTPRoute,
    convert_refs: bool = True,
) -> tuple[dict[str, Any], dict[str, dict[str, str]]]:
    """
    Combines parameter and request body schemas into a single schema.
    Handles parameter name collisions by adding location suffixes.
    Also returns parameter mapping for request director.

    Args:
        route: HTTPRoute object

    Returns:
        Tuple of (combined schema dictionary, parameter mapping)
        Parameter mapping format: {'flat_arg_name': {'location': 'path', 'openapi_name': 'id'}}
    """
    properties = {}
    required = []
    parameter_map = {}  # Track mapping from flat arg names to OpenAPI locations

    # First pass: collect parameter names by location and body properties
    param_names_by_location = {
        "path": set(),
        "query": set(),
        "header": set(),
        "cookie": set(),
    }
    body_schema: dict[str, Any] = {}
    body_props: dict[str, Any] = {}

    for param in route.parameters:
        param_names_by_location[param.location].add(param.name)

    if route.request_body and route.request_body.content_schema:
        content_type = next(iter(route.request_body.content_schema))

        # Convert refs if needed
        if convert_refs:
            body_schema = _replace_ref_with_defs(
                route.request_body.content_schema[content_type]
            )
        else:
            body_schema = route.request_body.content_schema[content_type]

        if route.request_body.description and not body_schema.get("description"):
            body_schema["description"] = route.request_body.description

        # Handle allOf at the top level by merging all schemas. A $ref that
        # sits beside its own properties is merged the same way; there, a
        # property defined by both sides must satisfy both definitions.
        has_all_of = isinstance(body_schema.get("allOf"), list)
        ref_is_object = _ref_is_mergeable_object(body_schema, route.request_schemas)
        has_ref_with_properties = (
            "$ref" in body_schema
            and isinstance(body_schema.get("properties"), dict)
            and ref_is_object
        )
        if has_all_of or has_ref_with_properties:
            merged_props = {}
            merged_required = []

            for sub_schema in _allof_members(body_schema, route.request_schemas):
                # Merge properties
                for prop_name, prop_schema in sub_schema.get("properties", {}).items():
                    if (
                        not has_all_of
                        and prop_name in merged_props
                        and merged_props[prop_name] != prop_schema
                    ):
                        prop_schema = {"allOf": [merged_props[prop_name], prop_schema]}
                    merged_props[prop_name] = prop_schema
                # Merge required fields
                if "required" in sub_schema:
                    merged_required.extend(sub_schema["required"])
                # The referenced schema's discriminator is kept so its subtypes
                # are flattened below; the sibling schema comes last and wins.
                if not has_all_of and isinstance(sub_schema.get("discriminator"), dict):
                    body_schema["discriminator"] = sub_schema["discriminator"]

            # Update body_schema with merged properties
            body_schema["properties"] = merged_props
            if merged_required:
                body_schema["required"] = list(dict.fromkeys(merged_required))
            # The $ref is dropped only when the merge represents the whole
            # referenced schema; otherwise it keeps carrying the target's type.
            body_schema.pop("allOf", None)
            if ref_is_object:
                body_schema.pop("$ref", None)

        # A kept $ref is paired with its siblings through allOf: resolving a
        # $ref that has siblings lets the siblings overwrite the target's keywords.
        if not ref_is_object:
            ref = body_schema.pop("$ref")
            if not body_schema.get("properties"):
                body_schema.pop("properties", None)
            body_schema = (
                {"allOf": [{"$ref": ref}, body_schema]}
                if body_schema
                else {"$ref": ref}
            )

        # Merge discriminated subtype fields in as optional. The discriminator
        # itself is dropped: its mapping points at definitions that are pruned
        # from $defs once nothing references them, which would leave the
        # emitted schema with dangling refs.
        flattened_props = _flatten_discriminator_subtypes(
            body_schema, route.request_schemas
        )
        if flattened_props is not None:
            body_schema["properties"] = flattened_props
            body_schema.pop("discriminator", None)

        # A kept $ref still carries constraints the properties cannot express,
        # so the whole schema is exposed as one argument.
        body_props = {} if not ref_is_object else body_schema.get("properties", {})

    # Detect collisions: parameters that exist in multiple non-body locations
    # or between body and path/query/header/cookie.
    all_non_body_params = set()
    for location_params in param_names_by_location.values():
        all_non_body_params.update(location_params)

    body_param_names = set(body_props.keys())
    body_param_name = "body"
    if route.request_body and route.request_body.content_schema and not body_props:
        # Whole-body arguments participate in collision detection too. References
        # keep the name "body"; other schemas use their normalized title.
        if "$ref" not in body_schema:
            body_param_name = re.sub(
                r"[^a-zA-Z0-9_]", "_", body_schema.get("title", "body").lower()
            )
            if not body_param_name or body_param_name[0].isdigit():
                body_param_name = "body_data"
        body_param_names.add(body_param_name)
    non_body_param_counts = Counter(param.name for param in route.parameters)
    colliding_params = (all_non_body_params & body_param_names) | {
        name for name, count in non_body_param_counts.items() if count > 1
    }

    # Add parameters with suffixes for collisions
    for param in route.parameters:
        if param.name in colliding_params:
            # Add suffix for non-body parameters when collision detected
            suffixed_name = f"{param.name}__{param.location}"
            if param.required:
                required.append(suffixed_name)

            # Track parameter mapping
            parameter_map[suffixed_name] = {
                "location": param.location,
                "openapi_name": param.name,
            }

            # Convert refs if needed
            if convert_refs:
                param_schema = _replace_ref_with_defs(param.schema_, param.description)
            else:
                param_schema = param.schema_.copy()
                if param.description and not param_schema.get("description"):
                    param_schema["description"] = param.description
            original_desc = param_schema.get("description", "")
            location_desc = f"({param.location.capitalize()} parameter)"
            if original_desc:
                param_schema["description"] = f"{original_desc} {location_desc}"
            else:
                param_schema["description"] = location_desc

            # Don't make optional parameters nullable - they can simply be omitted
            # The OpenAPI specification doesn't require optional parameters to accept null values

            properties[suffixed_name] = param_schema
        else:
            # No collision, use original name
            if param.required:
                required.append(param.name)

            # Track parameter mapping
            parameter_map[param.name] = {
                "location": param.location,
                "openapi_name": param.name,
            }

            # Convert refs if needed
            if convert_refs:
                param_schema = _replace_ref_with_defs(param.schema_, param.description)
            else:
                param_schema = param.schema_.copy()
                if param.description and not param_schema.get("description"):
                    param_schema["description"] = param.description

            # Don't make optional parameters nullable - they can simply be omitted
            # The OpenAPI specification doesn't require optional parameters to accept null values

            properties[param.name] = param_schema

    # Add request body properties (no suffixes for body parameters)
    if route.request_body and route.request_body.content_schema:
        if body_props:
            # Normal case: body has properties
            for prop_name, prop_schema in body_props.items():
                properties[prop_name] = prop_schema

                # Track parameter mapping for body properties
                parameter_map[prop_name] = {
                    "location": "body",
                    "openapi_name": prop_name,
                }

            if route.request_body.required:
                required.extend(body_schema.get("required", []))
        else:
            properties[body_param_name] = body_schema
            if route.request_body.required:
                required.append(body_param_name)
            parameter_map[body_param_name] = {
                "location": "body",
                "openapi_name": body_param_name,
            }

    result = {
        "type": "object",
        "properties": properties,
        "required": required,
    }
    # Add schema definitions if available
    schema_defs = route.request_schemas
    if schema_defs:
        if convert_refs:
            # Need to convert refs and prune
            all_defs = schema_defs.copy()
            # Convert each schema definition recursively
            for name, schema in all_defs.items():
                if isinstance(schema, dict):
                    all_defs[name] = _replace_ref_with_defs(schema)

            # Prune to only needed schemas
            used_refs = set()

            def find_refs_in_value(value):
                """Recursively find all $ref references."""
                if isinstance(value, dict):
                    if "$ref" in value and isinstance(value["$ref"], str):
                        ref = value["$ref"]
                        if ref.startswith("#/$defs/"):
                            used_refs.add(ref.split("/")[-1])
                    for v in value.values():
                        find_refs_in_value(v)
                elif isinstance(value, list):
                    for item in value:
                        find_refs_in_value(item)

            # Find refs in properties
            find_refs_in_value(properties)

            # Collect transitive dependencies
            if used_refs:
                collected_all = False
                while not collected_all:
                    initial_count = len(used_refs)
                    for name in list(used_refs):
                        if name in all_defs:
                            find_refs_in_value(all_defs[name])
                    collected_all = len(used_refs) == initial_count

                result["$defs"] = {
                    name: def_schema
                    for name, def_schema in all_defs.items()
                    if name in used_refs
                }
        else:
            # From parser - already converted and pruned
            result["$defs"] = schema_defs

    if route.openapi_version and route.openapi_version.startswith("3"):
        result = convert_openapi_schema_to_json_schema(result, route.openapi_version)

    return result, parameter_map


def _combine_schemas(route: HTTPRoute) -> dict[str, Any]:
    """
    Combines parameter and request body schemas into a single schema.
    Handles parameter name collisions by adding location suffixes.

    This is a backward compatibility wrapper around _combine_schemas_and_map_params.

    Args:
        route: HTTPRoute object

    Returns:
        Combined schema dictionary
    """
    schema, _ = _combine_schemas_and_map_params(route)
    return schema


def extract_output_schema_from_responses(
    responses: dict[str, ResponseInfo],
    schema_definitions: dict[str, Any] | None = None,
    openapi_version: str | None = None,
) -> dict[str, Any] | None:
    """
    Extract output schema from OpenAPI responses for use as MCP tool output schema.

    This function finds the first successful response (200, 201, 202, 204) with a
    JSON-compatible content type and extracts its schema. If the schema is not an
    object type, it wraps it to comply with MCP requirements.

    Args:
        responses: Dictionary of ResponseInfo objects keyed by status code
        schema_definitions: Optional schema definitions to include in the output schema
        openapi_version: OpenAPI version string, used to optimize nullable field handling

    Returns:
        dict: MCP-compliant output schema with potential wrapping, or None if no suitable schema found
    """
    if not responses:
        return None

    # Priority order for success status codes
    success_codes = ["200", "201", "202", "204"]

    # Find the first successful response
    response_info = None
    for status_code in success_codes:
        if status_code in responses:
            response_info = responses[status_code]
            break

    # If no explicit success codes, try any 2xx response
    if response_info is None:
        for status_code, resp_info in responses.items():
            if status_code.startswith("2"):
                response_info = resp_info
                break

    if response_info is None or not response_info.content_schema:
        return None

    # Prefer application/json, then fall back to other JSON-compatible types
    json_compatible_types = [
        "application/json",
        "application/vnd.api+json",
        "application/hal+json",
        "application/ld+json",
        "text/json",
    ]

    schema = None
    for content_type in json_compatible_types:
        if content_type in response_info.content_schema:
            schema = response_info.content_schema[content_type]
            break

    # If no JSON-compatible type found, try the first available content type
    if schema is None and response_info.content_schema:
        first_content_type = next(iter(response_info.content_schema))
        schema = response_info.content_schema[first_content_type]
        logger.debug(
            f"Using non-JSON content type for output schema: {first_content_type}"
        )

    if not schema or not isinstance(schema, dict):
        return None

    # Convert refs if needed
    output_schema = _replace_ref_with_defs(schema)

    # If schema has a $ref, resolve it first before processing nullable fields
    if "$ref" in output_schema and schema_definitions:
        ref_path = output_schema["$ref"]
        if ref_path.startswith("#/$defs/"):
            schema_name = ref_path.split("/")[-1]
            if schema_name in schema_definitions:
                # Replace $ref with the actual schema definition
                output_schema = _replace_ref_with_defs(schema_definitions[schema_name])

    # Unconverted definitions, so $ref targets still carry their access annotations
    definitions = {
        name: _replace_ref_with_defs(def_schema)
        if isinstance(def_schema, dict)
        else def_schema
        for name, def_schema in (schema_definitions or {}).items()
    }

    if openapi_version and openapi_version.startswith("3"):
        # Convert OpenAPI 3.x schema to JSON Schema format for proper handling
        # of constructs like oneOf, anyOf, and nullable fields. writeOnly
        # properties belong to requests only, so responses never contain them.
        output_schema = convert_openapi_schema_to_json_schema(
            output_schema,
            openapi_version,
            remove_write_only=True,
            definitions=definitions,
        )

    # MCP requires output schemas to be objects. If this schema is not an object,
    # we need to wrap it similar to how ParsedFunction.from_function() does it
    if output_schema.get("type") != "object":
        # Create a wrapped schema that contains the original schema under a "result" key
        wrapped_schema = {
            "type": "object",
            "properties": {"result": output_schema},
            "required": ["result"],
            "x-fastmcp-wrap-result": True,
        }
        output_schema = wrapped_schema

    # Add schema definitions if available
    if schema_definitions:
        processed_defs = definitions.copy()

        # Convert OpenAPI schema definitions to JSON Schema format if needed
        if openapi_version and openapi_version.startswith("3"):
            for def_name in list(processed_defs.keys()):
                processed_defs[def_name] = convert_openapi_schema_to_json_schema(
                    processed_defs[def_name],
                    openapi_version,
                    remove_write_only=True,
                    definitions=definitions,
                )

        output_schema["$defs"] = processed_defs

    return output_schema


# Export public symbols
__all__ = [
    "_combine_schemas",
    "_combine_schemas_and_map_params",
    "_make_optional_parameter_nullable",
    "clean_schema_for_display",
    "extract_output_schema_from_responses",
]
