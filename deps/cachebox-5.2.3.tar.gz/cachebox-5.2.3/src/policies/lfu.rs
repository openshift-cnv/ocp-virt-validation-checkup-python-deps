use crate::common::Entry;
use crate::common::Observed;
use crate::common::PreHashObject;
use crate::common::TryFindMethods;
use crate::lazyheap;
use std::ptr::NonNull;

type TupleValue = (PreHashObject, pyo3::Py<pyo3::PyAny>, usize, usize);

pub struct LFUPolicy {
    table: hashbrown::raw::RawTable<NonNull<TupleValue>>,
    heap: lazyheap::LazyHeap<TupleValue>,
    maxsize: std::num::NonZeroUsize,
    maxmemory: std::num::NonZeroUsize,
    memory: usize,
    pub observed: Observed,
}

pub struct LFUPolicyOccupied<'a> {
    instance: &'a mut LFUPolicy,
    bucket: hashbrown::raw::Bucket<NonNull<TupleValue>>,
}

pub struct LFUPolicyAbsent<'a> {
    instance: &'a mut LFUPolicy,
    insert_slot: Option<hashbrown::raw::InsertSlot>,
}

pub type LFUIterator = lazyheap::Iter<(PreHashObject, pyo3::Py<pyo3::PyAny>, usize, usize)>;

impl LFUPolicy {
    pub fn new(maxsize: usize, mut capacity: usize, maxmemory: usize) -> pyo3::PyResult<Self> {
        let maxsize = non_zero_or!(maxsize, isize::MAX as usize);
        let maxmemory = non_zero_or!(maxmemory, isize::MAX as usize);
        capacity = capacity.min(maxsize.get());

        Ok(Self {
            table: new_table!(capacity)?,
            heap: lazyheap::LazyHeap::new(),
            maxsize,
            maxmemory,
            memory: 0,
            observed: Observed::new(),
        })
    }

    pub fn maxsize(&self) -> usize {
        self.maxsize.get()
    }

    pub fn maxmemory(&self) -> usize {
        self.maxmemory.get()
    }

    pub fn memory(&self) -> usize {
        self.memory
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.table.len()
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.table.is_empty()
    }

    pub fn is_full(&self) -> bool {
        self.table.len() == self.maxsize.get() || self.memory >= self.maxmemory.get()
    }

    pub fn capacity(&self) -> usize {
        self.table.capacity()
    }

    #[inline]
    pub fn popitem(&mut self) -> Option<TupleValue> {
        self.heap.sort_by(|a, b| a.2.cmp(&b.2));
        let front = self.heap.front()?;

        unsafe {
            self.table
                .remove_entry(front.as_ref().0.hash, |x| {
                    std::ptr::eq(x.as_ptr(), front.as_ptr())
                })
                .unwrap();
        }

        self.observed.change();
        let item = self.heap.pop_front(|a, b| a.2.cmp(&b.2)).unwrap();
        self.memory = self.memory.saturating_sub(item.3);
        Some(item)
    }

    #[inline]
    #[rustfmt::skip]
    pub fn entry(
        &'_ mut self,
        py: pyo3::Python<'_>,
        key: &PreHashObject,
    ) -> pyo3::PyResult<Entry<LFUPolicyOccupied<'_>, LFUPolicyAbsent<'_>>> {
        match self
            .table
            .try_find(key.hash, |ptr| unsafe { ptr.as_ref().0.equal(py, key) })?
        {
            Some(bucket) => {
                Ok(
                    Entry::Occupied(LFUPolicyOccupied { instance: self, bucket })
                )
            },
            None => {
                Ok(
                    Entry::Absent(LFUPolicyAbsent { instance: self, insert_slot: None })
                )
            }
        }
    }

    #[inline]
    #[rustfmt::skip]
    pub fn entry_with_slot(
        &'_ mut self,
        py: pyo3::Python<'_>,
        key: &PreHashObject,
    ) -> pyo3::PyResult<Entry<LFUPolicyOccupied<'_>, LFUPolicyAbsent<'_>>> {
        match self.table.try_find_or_find_insert_slot(
                key.hash,
                |ptr| unsafe { ptr.as_ref().0.equal(py, key) },
                |ptr| unsafe { ptr.as_ref().0.hash },
        )? {
            Ok(bucket) => {
                Ok(
                    Entry::Occupied(LFUPolicyOccupied { instance: self, bucket })
                )
            },
            Err(slot) => {
                Ok(
                    Entry::Absent(LFUPolicyAbsent { instance: self, insert_slot: Some(slot) })
                )
            }
        }
    }

    #[inline]
    pub fn lookup(
        &mut self,
        py: pyo3::Python<'_>,
        key: &PreHashObject,
    ) -> pyo3::PyResult<Option<&pyo3::Py<pyo3::PyAny>>> {
        match self.entry(py, key)? {
            Entry::Occupied(x) => unsafe {
                x.bucket.as_mut().as_mut().2 += 1;
                x.instance.heap.queue_sort();

                Ok(Some(&x.bucket.as_ref().as_ref().1))
            },
            Entry::Absent(_) => Ok(None),
        }
    }

    pub fn peek(
        &self,
        py: pyo3::Python<'_>,
        key: &PreHashObject,
    ) -> pyo3::PyResult<Option<&pyo3::Py<pyo3::PyAny>>> {
        let result = self
            .table
            .try_find(key.hash, |x| unsafe { x.as_ref().0.equal(py, key) })?
            .map(|x| unsafe { &x.as_ref().as_ref().1 });

        Ok(result)
    }

    pub fn clear(&mut self) {
        self.table.clear();
        self.heap.clear();
        self.memory = 0;
        self.observed.change();
    }

    pub fn shrink_to_fit(&mut self) {
        self.table
            .shrink_to(self.table.len(), |x| unsafe { x.as_ref().0.hash });

        self.heap.shrink_to_fit();
        self.observed.change();
    }

    pub fn equal(&self, py: pyo3::Python<'_>, other: &Self) -> pyo3::PyResult<bool> {
        if self.maxsize != other.maxsize {
            return Ok(false);
        }

        if self.maxmemory != other.maxmemory {
            return Ok(false);
        }

        if self.table.len() != other.table.len() {
            return Ok(false);
        }

        unsafe {
            for node in self.table.iter().map(|x| x.as_ref()) {
                let (key1, value1, _, _) = node.as_ref();

                match other
                    .table
                    .try_find(key1.hash, |x| key1.equal(py, &x.as_ref().0))?
                {
                    Some(bucket) => {
                        let (_, value2, _, _) = bucket.as_ref().as_ref();

                        if !crate::common::pyobject_equal(py, value1.as_ptr(), value2.as_ptr())? {
                            return Ok(false);
                        }
                    }
                    None => return Ok(false),
                }
            }
        }

        Ok(true)
    }

    #[inline]
    pub fn extend(
        &mut self,
        py: pyo3::Python<'_>,
        iterable: pyo3::Py<pyo3::PyAny>,
    ) -> pyo3::PyResult<()> {
        use pyo3::types::{PyAnyMethods, PyDictMethods};

        if unsafe { pyo3::ffi::PyDict_CheckExact(iterable.as_ptr()) == 1 } {
            let dict = unsafe { iterable.cast_bound_unchecked::<pyo3::types::PyDict>(py) };

            for (key, value) in dict.iter() {
                let hk =
                    unsafe { PreHashObject::from_pyobject(py, key.unbind()).unwrap_unchecked() };

                match self.entry_with_slot(py, &hk)? {
                    Entry::Occupied(entry) => {
                        entry.update(py, value.unbind())?;
                    }
                    Entry::Absent(entry) => {
                        entry.insert(py, hk, value.unbind(), 0)?;
                    }
                }
            }
        } else {
            for pair in iterable.bind(py).try_iter()? {
                let (key, value) =
                    pair?.extract::<(pyo3::Py<pyo3::PyAny>, pyo3::Py<pyo3::PyAny>)>()?;

                let hk = PreHashObject::from_pyobject(py, key)?;

                match self.entry_with_slot(py, &hk)? {
                    Entry::Occupied(entry) => {
                        entry.update(py, value)?;
                    }
                    Entry::Absent(entry) => {
                        entry.insert(py, hk, value, 0)?;
                    }
                }
            }
        }

        Ok(())
    }

    pub fn iter(&mut self) -> LFUIterator {
        self.heap.iter(|a, b| a.2.cmp(&b.2))
    }

    pub fn least_frequently_used(&mut self, n: usize) -> Option<NonNull<TupleValue>> {
        self.heap.sort_by(|a, b| a.2.cmp(&b.2));
        let node = self.heap.get(n)?;

        Some(*node)
    }

    #[allow(clippy::wrong_self_convention)]
    pub fn from_pickle(
        &mut self,
        py: pyo3::Python<'_>,
        state: *mut pyo3::ffi::PyObject,
    ) -> pyo3::PyResult<()> {
        use pyo3::types::PyAnyMethods;

        unsafe {
            let (maxsize, iterable, capacity, maxmemory) = extract_pickle_tuple!(py, state => list);

            // SAFETY: we check `iterable` type in `extract_pickle_tuple` macro
            if maxsize < (pyo3::ffi::PyObject_Size(iterable.as_ptr()) as usize) {
                return Err(pyo3::PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    "iterable object size is greater than maxsize",
                ));
            }

            let mut new = Self::new(maxsize, capacity, maxmemory)?;

            for pair in iterable.bind(py).try_iter()? {
                let (key, value, freq) =
                    pair?.extract::<(pyo3::Py<pyo3::PyAny>, pyo3::Py<pyo3::PyAny>, usize)>()?;

                let hk = PreHashObject::from_pyobject(py, key)?;

                match new.entry_with_slot(py, &hk)? {
                    Entry::Absent(entry) => {
                        entry.insert(py, hk, value, freq)?;
                    }
                    _ => std::hint::unreachable_unchecked(),
                }
            }

            new.heap.sort_by(|a, b| a.2.cmp(&b.2));

            *self = new;
            Ok(())
        }
    }
}

impl LFUPolicyOccupied<'_> {
    #[inline]
    pub fn update(
        self,
        py: pyo3::Python<'_>,
        value: pyo3::Py<pyo3::PyAny>,
    ) -> pyo3::PyResult<pyo3::Py<pyo3::PyAny>> {
        let item = unsafe { self.bucket.as_mut() };
        let (old_value, old_size, new_size) = {
            let element = unsafe { item.as_mut() };
            let new_size = crate::common::entry_size(py, &element.0, &value)?;

            if new_size > self.instance.maxmemory.get() {
                return Err(pyo3::PyErr::new::<pyo3::exceptions::PyOverflowError, _>(
                    "The cache has reached the bound",
                ));
            }

            let old_size = element.3;
            let old_value = std::mem::replace(&mut element.1, value);
            element.3 = new_size;
            element.2 += 1;
            (old_value, old_size, new_size)
        };

        self.instance.heap.queue_sort();
        self.instance.memory = self
            .instance
            .memory
            .saturating_sub(old_size)
            .saturating_add(new_size);

        // In update we don't need to change this; because this does not change the memory address ranges
        // self.instance.observed.change();

        while self.instance.memory > self.instance.maxmemory.get() {
            if self.instance.popitem().is_none() {
                break;
            }
        }

        Ok(old_value)
    }

    #[inline]
    pub fn remove(self) -> TupleValue {
        let (item, _) = unsafe { self.instance.table.remove(self.bucket) };
        let item = self.instance.heap.remove(item, |a, b| a.2.cmp(&b.2));

        self.instance.memory = self.instance.memory.saturating_sub(item.3);
        self.instance.observed.change();
        item
    }

    pub fn into_value(self) -> NonNull<TupleValue> {
        let item = unsafe { self.bucket.as_mut() };
        *item
    }
}

impl LFUPolicyAbsent<'_> {
    #[inline]
    pub fn insert(
        self,
        py: pyo3::Python<'_>,
        key: PreHashObject,
        value: pyo3::Py<pyo3::PyAny>,
        freq: usize,
    ) -> pyo3::PyResult<()> {
        let entry_size = crate::common::entry_size(py, &key, &value)?;
        if entry_size > self.instance.maxmemory.get() {
            return Err(pyo3::PyErr::new::<pyo3::exceptions::PyOverflowError, _>(
                "The cache has reached the bound",
            ));
        }

        while self.instance.table.len() >= self.instance.maxsize.get()
            || self.instance.memory.saturating_add(entry_size) > self.instance.maxmemory.get()
        {
            if self.instance.popitem().is_none() {
                break;
            }
        }

        let hash = key.hash;
        let node = self.instance.heap.push((key, value, freq, entry_size));

        match self.insert_slot {
            Some(slot) => unsafe {
                self.instance.table.insert_in_slot(hash, slot, node);
            },
            None => {
                self.instance
                    .table
                    .insert(hash, node, |x| unsafe { x.as_ref().0.hash });
            }
        }

        self.instance.memory = self.instance.memory.saturating_add(entry_size);
        self.instance.observed.change();
        Ok(())
    }
}

unsafe impl Send for LFUPolicy {}
