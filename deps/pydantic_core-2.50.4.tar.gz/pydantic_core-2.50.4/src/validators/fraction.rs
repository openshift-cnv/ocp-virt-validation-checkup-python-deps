use std::sync::Arc;

use pyo3::exceptions::{PyOverflowError, PyTypeError, PyValueError, PyZeroDivisionError};
use pyo3::intern;
use pyo3::sync::PyOnceLock;
use pyo3::types::{IntoPyDict, PyDict, PyInt, PyString, PyType};
use pyo3::{PyTypeInfo, prelude::*};

use crate::build_tools::is_strict;
use crate::errors::ErrorTypeDefaults;
use crate::errors::ValResult;
use crate::errors::{ErrorType, Number, ToErrorValue, ValError};
use crate::input::Input;

use super::{BuildValidator, CombinedValidator, DefinitionsBuilder, ValidationState, Validator};

static FRACTION_TYPE: PyOnceLock<Py<PyType>> = PyOnceLock::new();

pub fn get_fraction_type(py: Python<'_>) -> PyResult<&Bound<'_, PyType>> {
    FRACTION_TYPE.import(py, "fractions", "Fraction")
}

fn validate_as_fraction(
    py: Python,
    schema: &Bound<'_, PyDict>,
    key: &Bound<'_, PyString>,
) -> PyResult<Option<Py<PyAny>>> {
    match schema.get_item(key)? {
        Some(value) => match value.validate_fraction(false, py) {
            Ok(v) => Ok(Some(v.into_inner().unbind())),
            Err(_) => Err(PyValueError::new_err(format!(
                "'{key}' must be coercible to a Fraction instance",
            ))),
        },
        None => Ok(None),
    }
}

#[derive(Debug, Clone)]
pub struct FractionValidator {
    strict: bool,
    multiple_of: Option<Py<PyAny>>,
    le: Option<Py<PyAny>>,
    lt: Option<Py<PyAny>>,
    ge: Option<Py<PyAny>>,
    gt: Option<Py<PyAny>>,
}

impl BuildValidator for FractionValidator {
    const EXPECTED_TYPE: &'static str = "fraction";
    fn build(
        schema: &Bound<'_, PyDict>,
        config: Option<&Bound<'_, PyDict>>,
        _definitions: &mut DefinitionsBuilder<Arc<CombinedValidator>>,
    ) -> PyResult<Arc<CombinedValidator>> {
        let py = schema.py();

        let multiple_of = validate_as_fraction(py, schema, intern!(py, "multiple_of"))?;
        if let Some(ref m) = multiple_of
            && !m.bind(py).gt(0)?
        {
            return Err(PyValueError::new_err("'multiple_of' must be greater than 0"));
        }

        Ok(CombinedValidator::Fraction(Self {
            strict: is_strict(schema, config)?,
            multiple_of,
            le: validate_as_fraction(py, schema, intern!(py, "le"))?,
            lt: validate_as_fraction(py, schema, intern!(py, "lt"))?,
            ge: validate_as_fraction(py, schema, intern!(py, "ge"))?,
            gt: validate_as_fraction(py, schema, intern!(py, "gt"))?,
        })
        .into())
    }
}

impl_py_gc_traverse!(FractionValidator {
    multiple_of,
    le,
    lt,
    ge,
    gt
});

impl Validator for FractionValidator {
    fn validate<'py>(
        &self,
        py: Python<'py>,
        input: &(impl Input<'py> + ?Sized),
        state: &mut ValidationState<'_, 'py>,
    ) -> ValResult<Py<PyAny>> {
        let fraction = input.validate_fraction(state.strict_or(self.strict), py)?.unpack(state);

        if let Some(multiple_of) = &self.multiple_of
            && !fraction.rem(multiple_of)?.eq(0)?
        {
            return Err(ValError::new(
                ErrorType::MultipleOf {
                    multiple_of: Number::String(multiple_of.to_string()),
                    context: Some([("multiple_of", multiple_of)].into_py_dict(py)?.into()),
                },
                input,
            ));
        }

        if let Some(le) = &self.le
            && !fraction.le(le)?
        {
            return Err(ValError::new(
                ErrorType::LessThanEqual {
                    le: Number::String(le.to_string()),
                    context: Some([("le", le)].into_py_dict(py)?.into()),
                },
                input,
            ));
        }
        if let Some(lt) = &self.lt
            && !fraction.lt(lt)?
        {
            return Err(ValError::new(
                ErrorType::LessThan {
                    lt: Number::String(lt.to_string()),
                    context: Some([("lt", lt)].into_py_dict(py)?.into()),
                },
                input,
            ));
        }
        if let Some(ge) = &self.ge
            && !fraction.ge(ge)?
        {
            return Err(ValError::new(
                ErrorType::GreaterThanEqual {
                    ge: Number::String(ge.to_string()),
                    context: Some([("ge", ge)].into_py_dict(py)?.into()),
                },
                input,
            ));
        }
        if let Some(gt) = &self.gt
            && !fraction.gt(gt)?
        {
            return Err(ValError::new(
                ErrorType::GreaterThan {
                    gt: Number::String(gt.to_string()),
                    context: Some([("gt", gt)].into_py_dict(py)?.into()),
                },
                input,
            ));
        }

        Ok(fraction.into())
    }

    fn get_name(&self) -> &str {
        Self::EXPECTED_TYPE
    }
}

/// Maximum absolute value of the exponent accepted in string inputs (e.g. `'1e4300'`).
///
/// `Fraction` computes `10**exp` for exponent notation, producing an integer with `|exp| + 1`
/// decimal digits, which can be very expensive and lead to DoS. Cap it so the result is
/// no larger than what we accept for `int` inputs.
const MAX_FRACTION_EXPONENT: u64 = 4300;

/// Whether the string uses exponent notation with an exponent larger than `MAX_FRACTION_EXPONENT`.
fn exponent_too_large(s: &Bound<'_, PyString>) -> bool {
    // Based on https://github.com/python/cpython/blob/v3.14.8/Lib/fractions.py#L257-L283:

    // A string that isn't valid UTF-8 is rejected by `Fraction` anyway.
    let Ok(str) = s.to_str() else {
        return false;
    };
    // In a valid `Fraction` string, `e`/`E` can only appear as the exponent marker.
    let Some(pos) = str.rfind(['e', 'E']) else {
        return false;
    };
    let py = s.py();
    // `Fraction` parses the exponent with `int()`:
    let Ok(exp) = PyString::new(py, &str[pos + 1..])
        .call_method0(intern!(py, "strip"))
        .and_then(|exp| PyInt::type_object(py).call1((exp,)))
    else {
        // Not a valid exponent, `Fraction` will reject the string itself.
        return false;
    };
    // Not fitting in an `i64` means it's way above the limit.
    exp.extract::<i64>()
        .map_or(true, |exp| exp.unsigned_abs() > MAX_FRACTION_EXPONENT)
}

pub(crate) fn create_fraction<'py>(arg: &Bound<'py, PyAny>, input: impl ToErrorValue) -> ValResult<Bound<'py, PyAny>> {
    let py = arg.py();
    if let Ok(s) = arg.cast::<PyString>()
        && exponent_too_large(s)
    {
        return Err(ValError::new(ErrorTypeDefaults::FractionParsing, input));
    }
    get_fraction_type(py)?
        .call1((arg,))
        .map_err(|e| handle_fraction_new_error(input, e))
}

fn handle_fraction_new_error(input: impl ToErrorValue, error: PyErr) -> ValError {
    Python::attach(|py| {
        if error.matches(py, PyTypeError::type_object(py)).unwrap_or(false) {
            ValError::new(ErrorTypeDefaults::FractionType, input)
        } else if error
            .matches(
                py,
                (
                    PyValueError::type_object(py),
                    PyZeroDivisionError::type_object(py),
                    PyOverflowError::type_object(py),
                ),
            )
            .unwrap_or(false)
        {
            ValError::new(ErrorTypeDefaults::FractionParsing, input)
        } else {
            // Let other exceptions bubble up
            ValError::InternalErr(error)
        }
    })
}
