#include "test_common.h"
#include "wcwidth/textwrap.h"
#include "wcwidth/utf8.h"
#include <string.h>
#include <stdlib.h>

/*
 * Count '\n'-separated lines in output and extract them into an array.
 * Caller must free each returned string and the array.
 */
static size_t
split_lines(char *buf, size_t len, char ***out)
{
    size_t count = 0, cap = 8, i;
    char *start = buf;
    char **lines = malloc(cap * sizeof(char *));
    if (lines == NULL)
        return 0;

    for (i = 0; i <= len; i++) {
        if (i == len || buf[i] == '\n') {
            if (count >= cap) {
                cap *= 2;
                char **nd = realloc(lines, cap * sizeof(char *));
                if (nd == NULL)
                    goto fail;
                lines = nd;
            }
            lines[count] = malloc((size_t) (buf + i - start) + 1);
            if (lines[count] == NULL)
                goto fail;
            memcpy(lines[count], start, (size_t) (buf + i - start));
            lines[count][buf + i - start] = '\0';
            count++;
            start = buf + i + 1;
        }
    }
    *out = lines;
    return count;

fail:
    for (i = 0; i < count; i++)
        free(lines[i]);
    free(lines);
    return 0;
}

static void
free_lines(char **lines, size_t n)
{
    size_t i;
    for (i = 0; i < n; i++)
        free(lines[i]);
    free(lines);
}

static void
check_lines(char *out, size_t out_len, const char **expected, size_t nexpected)
{
    char **lines = NULL;
    size_t nlines = split_lines(out, out_len, &lines);
    size_t i;
    ASSERT_EQ((int64_t) nexpected, (int64_t) nlines);
    for (i = 0; i < nlines; i++) {
        ASSERT_STREQ(expected[i], lines[i]);
    }
    free_lines(lines, nlines);
}

TEST(wrap_basic)
{
    char *out;
    size_t len;
    wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;
    const char *exp[] = {"hello", "world"};

    o.width = 5;
    ASSERT_EQ(0, wcwidth_wrap_u8("hello world", 11, &o, &out, &len));
    check_lines(out, len, exp, 2);
    free(out);

    o = WCWIDTH_WRAP_OPTS_DEFAULT;
    o.width = 4;
    const char *exp2[] = {"\xe4\xb8\xad\xe6\x96\x87", "\xe5\xad\x97\xe7\xac\xa6"};
    ASSERT_EQ(
        0, wcwidth_wrap_u8("\xe4\xb8\xad\xe6\x96\x87\xe5\xad\x97\xe7\xac\xa6", 12, &o, &out, &len));
    check_lines(out, len, exp2, 2);
    free(out);

    ASSERT_EQ(0, wcwidth_wrap_u8("", 0, &WCWIDTH_WRAP_OPTS_DEFAULT, &out, &len));
    ASSERT_EQ((int64_t) 0, (int64_t) len);
    free(out);
}

TEST(wrap_text_basic)
{
    char *out;
    size_t len;
    wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;
    const char *exp[] = {"line one", "", "line two"};

    o.width = 40;
    ASSERT_EQ(0, wcwidth_wrap_u8_text("line one\n\nline two", 18, &o, &out, &len));
    check_lines(out, len, exp, 3);
    free(out);
}

TEST(wrap_embedded_nul)
{
    char *out;
    size_t len;
    wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;

    o.width = 5;
    ASSERT_EQ(0, wcwidth_wrap_u8("ab\x00"
                                 "cd ef",
                                 8, &o, &out, &len));
    ASSERT_EQ((int64_t) 8, (int64_t) len);
    ASSERT_EQ(0, memcmp(out,
                        "ab\x00"
                        "cd\nef",
                        8));
    free(out);
}

TEST(wrap_u32_parity)
{
    char *out8;
    size_t len8;
    uint32_t stack[64];
    size_t count;
    const uint32_t *expect;
    uint32_t *out32;
    size_t len32;
    const uint32_t cps[] = {'h', 0x00E9, 'l', 'l', 'o', ' ', 'w', 0x00F6, 'r', 'l', 'd'};
    wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;

    o.width = 5;
    ASSERT_EQ(0, wcwidth_wrap_u8("h\xc3\xa9llo w\xc3\xb6rld", 13, &o, &out8, &len8));
    ASSERT_EQ(0, wcwidth_wrap_u32(cps, 11, &o, &out32, &len32));
    expect = wcwidth_decode_u32(out8, len8, stack, 64, &count);
    ASSERT_EQ((int64_t) count, (int64_t) len32);
    ASSERT_EQ(0, memcmp(expect, out32, count * sizeof(uint32_t)));
    free(out8);
    free(out32);
}

TEST(wrap_text_u32_parity)
{
    char *out8;
    size_t len8;
    uint32_t stack[64];
    size_t count;
    const uint32_t *expect;
    uint32_t *out32;
    size_t len32;
    const uint32_t cps[] = {'l',  'i', 'n', 'e', ' ', 'o', 'n', 'e', '\n',
                            '\n', 'l', 'i', 'n', 'e', ' ', 't', 'w', 'o'};
    wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;

    o.width = 40;
    ASSERT_EQ(0, wcwidth_wrap_u8_text("line one\n\nline two", 18, &o, &out8, &len8));
    ASSERT_EQ(0, wcwidth_wrap_u32_text(cps, 18, &o, &out32, &len32));
    expect = wcwidth_decode_u32(out8, len8, stack, 64, &count);
    ASSERT_EQ((int64_t) count, (int64_t) len32);
    ASSERT_EQ(0, memcmp(expect, out32, count * sizeof(uint32_t)));
    free(out8);
    free(out32);
}

TEST(wrap_lines_u8)
{
    char *out;
    size_t len;
    size_t *offsets;
    size_t count;
    wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;

    o.width = 7;
    o.max_lines = 1;
    o.placeholder = "\n[..]";
    ASSERT_EQ(0, wcwidth_wrap_lines_u8("one two three four", 18, &o, &out, &len, &offsets, &count));
    ASSERT_EQ((int64_t) 1, (int64_t) count);
    /* a line may itself contain '\n' from the placeholder */
    ASSERT_EQ((int64_t) 8, (int64_t) len);
    ASSERT_EQ(0, memcmp(out, "one\n[..]", 8));
    ASSERT_EQ((size_t) 0, offsets[0]);
    free(out);
    free(offsets);

    /* placeholder that cannot fit */
    o.placeholder = "xxxxxxxx";
    ASSERT_EQ(-2,
              wcwidth_wrap_lines_u8("one two three four", 18, &o, &out, &len, &offsets, &count));

    /* empty input yields no lines */
    ASSERT_EQ(0, wcwidth_wrap_lines_u8("", 0, &o, &out, &len, &offsets, &count));
    ASSERT_EQ((size_t) 0, count);
    free(out);
}

/*
 * tabsize <= 0 is documented to pass tabs through unchanged; disabling
 * replace_whitespace isolates that from the whitespace-normalization pass.
 */
TEST(wrap_tabsize_zero)
{
    char *out = NULL;
    size_t len = 0;
    wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;

    o.width = 3;
    o.tabsize = 0;
    o.replace_whitespace = false;
    ASSERT_EQ(0, wcwidth_wrap_u8("a\tb", 3, &o, &out, &len));
    ASSERT_EQ(3, len);
    ASSERT_EQ(0, memcmp(out, "a\tb", 3));
    free(out);
}

/*
 * A run of UTF-8 continuation bytes reaching the start of the buffer must
 * not read before it while backing up to find a lead byte.
 */
TEST(wrap_lone_continuation_bytes)
{
    static const char *const inputs[] = {"\xBF", "\x80", "\xBF\xBF\xBF"};
    size_t i;

    for (i = 0; i < sizeof(inputs) / sizeof(inputs[0]); i++) {
        char *out = NULL;
        size_t len = 0;
        wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;
        size_t in_len = strlen(inputs[i]);

        o.width = 3;
        int rv = wcwidth_wrap_u8(inputs[i], in_len, &o, &out, &len);
        ASSERT_EQ(0, rv);
        free(out);
    }
}

TEST(wrap_max_lines_placeholder)
{
    char *out;
    size_t len;
    wcwidth_wrap_opts_t o = WCWIDTH_WRAP_OPTS_DEFAULT;
    const char *exp[] = {"aa bb [...]"};

    o.width = 11;
    o.max_lines = 1;
    ASSERT_EQ(0, wcwidth_wrap_u8("aa bb cccccccc", 14, &o, &out, &len));
    check_lines(out, len, exp, 1);
    free(out);

    o = WCWIDTH_WRAP_OPTS_DEFAULT;
    o.width = 4;
    o.max_lines = 1;
    ASSERT_EQ(-2, wcwidth_wrap_u8("aaaa bbbb", 9, &o, &out, &len));

    o = WCWIDTH_WRAP_OPTS_DEFAULT;
    o.width = 6;
    o.max_lines = 1;
    ASSERT_EQ(0, wcwidth_wrap_u8("aa bbbb", 7, &o, &out, &len));
    free(out);

    o = WCWIDTH_WRAP_OPTS_DEFAULT;
    o.width = 6;
    o.max_lines = 2;
    ASSERT_EQ(0, wcwidth_wrap_u8("aa bb cc dd ee", 14, &o, &out, &len));
    free(out);

    o = WCWIDTH_WRAP_OPTS_DEFAULT;
    o.width = 11;
    o.max_lines = 2;
    ASSERT_EQ(0, wcwidth_wrap_u8("aa bb ccccccccc dd", 18, &o, &out, &len));
    free(out);

    o = WCWIDTH_WRAP_OPTS_DEFAULT;
    o.width = 3;
    o.expand_tabs = false;
    ASSERT_EQ(0, wcwidth_wrap_u8("a\tb", 3, &o, &out, &len));
    free(out);

    o = WCWIDTH_WRAP_OPTS_DEFAULT;
    o.width = 2;
    o.break_long_words = false;
    ASSERT_EQ(0, wcwidth_wrap_u8("abcdef", 6, &o, &out, &len));
    free(out);
}

int
main(void)
{
    RUN_TEST(wrap_basic);
    RUN_TEST(wrap_text_basic);
    RUN_TEST(wrap_embedded_nul);
    RUN_TEST(wrap_u32_parity);
    RUN_TEST(wrap_text_u32_parity);
    RUN_TEST(wrap_lines_u8);
    RUN_TEST(wrap_tabsize_zero);
    RUN_TEST(wrap_lone_continuation_bytes);
    RUN_TEST(wrap_max_lines_placeholder);
    return test_summary();
}
