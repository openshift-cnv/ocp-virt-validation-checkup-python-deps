# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import functools
from collections.abc import Callable, Generator, Sequence
import queue
from typing import Any, ClassVar, Literal, overload

from openstack._utils import renamed_param
from openstack.load_balancer.v2 import amphora as _amphora
from openstack.load_balancer.v2 import availability_zone as _availability_zone
from openstack.load_balancer.v2 import (
    availability_zone_profile as _availability_zone_profile,
)
from openstack.load_balancer.v2 import flavor as _flavor
from openstack.load_balancer.v2 import flavor_profile as _flavor_profile
from openstack.load_balancer.v2 import health_monitor as _hm
from openstack.load_balancer.v2 import l7_policy as _l7policy
from openstack.load_balancer.v2 import l7_rule as _l7rule
from openstack.load_balancer.v2 import listener as _listener
from openstack.load_balancer.v2 import load_balancer as _lb
from openstack.load_balancer.v2 import member as _member
from openstack.load_balancer.v2 import pool as _pool
from openstack.load_balancer.v2 import provider as _provider
from openstack.load_balancer.v2 import quota as _quota
from openstack import proxy
from openstack import resource


class Proxy(proxy.Proxy):
    api_version: ClassVar[Literal['2']] = '2'

    _resource_registry = {
        "amphora": _amphora.Amphora,
        "availability_zone": _availability_zone.AvailabilityZone,
        "availability_zone_profile": _availability_zone_profile.AvailabilityZoneProfile,  # noqa: E501
        "flavor": _flavor.Flavor,
        "flavor_profile": _flavor_profile.FlavorProfile,
        "health_monitor": _hm.HealthMonitor,
        "l7_policy": _l7policy.L7Policy,
        "l7_rule": _l7rule.L7Rule,
        "load_balancer": _lb.LoadBalancer,
        "member": _member.Member,
        "pool": _pool.Pool,
        "provider": _provider.Provider,
        "quota": _quota.Quota,
    }

    # ====== Load Balancers ======

    def create_load_balancer(self, **attrs: Any) -> _lb.LoadBalancer:
        """Create a new load balancer from attributes

        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.load_balancer.v2.load_balancer.LoadBalancer`,
            comprised of the properties on the
            LoadBalancer class.

        :returns: The results of load balancer creation
        """
        return self._create(_lb.LoadBalancer, **attrs)

    def get_load_balancer(
        self, load_balancer: str | _lb.LoadBalancer
    ) -> _lb.LoadBalancer:
        """Get a load balancer

        :param load_balancer: The value can be the ID of a load balancer
            or :class:`~openstack.load_balancer.v2.load_balancer.LoadBalancer`
            instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.load_balancer.LoadBalancer`
        """
        return self._get(_lb.LoadBalancer, load_balancer)

    def get_load_balancer_statistics(
        self, load_balancer: str | _lb.LoadBalancer
    ) -> _lb.LoadBalancerStats:
        """Get the load balancer statistics

        :param load_balancer: The value can be the ID of a load balancer
            or :class:`~openstack.load_balancer.v2.load_balancer.LoadBalancer`
            instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.load_balancer.LoadBalancerStats`
        """
        return self._get(
            _lb.LoadBalancerStats, lb_id=load_balancer, requires_id=False
        )

    def load_balancers(
        self,
        **query: Any,
    ) -> Generator[_lb.LoadBalancer, None, None]:
        """Retrieve a generator of load balancers

        :returns: A generator of load balancer instances
        """
        return self._list(_lb.LoadBalancer, **query)

    def delete_load_balancer(
        self,
        load_balancer: str | _lb.LoadBalancer,
        ignore_missing: bool = True,
        cascade: bool = False,
    ) -> None:
        """Delete a load balancer

        :param load_balancer: The load_balancer can be either the ID or a
            :class:`~openstack.load_balancer.v2.load_balancer.LoadBalancer`
            instance
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the load balancer does not exist. When set to ``True``, no
            exception will be set when attempting to delete a nonexistent load
            balancer.
        :param cascade: If true will delete all child objects of
            the load balancer.

        :returns: ``None``
        """
        params = {'cascade': True} if cascade else None
        self._delete(
            _lb.LoadBalancer,
            load_balancer,
            ignore_missing=ignore_missing,
            params=params,
        )

    @overload
    def find_load_balancer(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _lb.LoadBalancer: ...

    @overload
    def find_load_balancer(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _lb.LoadBalancer | None: ...

    def find_load_balancer(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _lb.LoadBalancer | None:
        """Find a single load balancer

        :param name_or_id: The name or ID of a load balancer
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the load balancer does not exist.
            When set to ``True``, no exception will be set when attempting
            to find a nonexistent load balancer.

        :returns: ``None``
        """
        return self._find(
            _lb.LoadBalancer, name_or_id, ignore_missing=ignore_missing
        )

    def update_load_balancer(
        self,
        load_balancer: str | _lb.LoadBalancer,
        **attrs: Any,
    ) -> _lb.LoadBalancer:
        """Update a load balancer

        :param load_balancer: The load_balancer can be either the ID or a
            :class:`~openstack.load_balancer.v2.load_balancer.LoadBalancer`
            instance
        :param attrs: The attributes to update on the load balancer
            represented by ``load_balancer``.

        :returns: The updated load_balancer
        """
        return self._update(_lb.LoadBalancer, load_balancer, **attrs)

    def wait_for_load_balancer(
        self,
        name_or_id: str,
        status: str = 'ACTIVE',
        failures: list[str] = ['ERROR'],
        interval: int = 2,
        wait: int = 300,
    ) -> _lb.LoadBalancer | None:
        """Wait for load balancer status

        :param name_or_id: The name or ID of the load balancer.
        :param status: Desired status.
        :param failures: Statuses that would be interpreted as failures.
            Default to ['ERROR'].
        :type failures: :py:class:`list`
        :param interval: Number of seconds to wait between consecutive
            checks. Defaults to 2.
        :param wait: Maximum number of seconds to wait before the status
            to be reached. Defaults to 300.
        :returns: The load balancer is returned on success.
        :raises: :class:`~openstack.exceptions.ResourceTimeout` if transition
            to the desired status failed to occur within the specified wait
            time.
        :raises: :class:`~openstack.exceptions.ResourceFailure` if the resource
            has transited to one of the failure statuses.
        :raises: :class:`~AttributeError` if the resource does not have a
            ``status`` attribute.
        """
        lb = self._find(_lb.LoadBalancer, name_or_id, ignore_missing=False)

        return resource.wait_for_status(
            self,
            lb,
            status,
            failures,
            interval,
            wait,
            attribute='provisioning_status',
        )

    def failover_load_balancer(
        self,
        load_balancer: str | _lb.LoadBalancer,
    ) -> None:
        """Failover a load balancer

        :param load_balancer: The value can be the ID of a load balancer
            or :class:`~openstack.load_balancer.v2.load_balancer.LoadBalancer`
            instance.

        :returns: ``None``
        """
        lb = self._get_resource(_lb.LoadBalancer, load_balancer)
        lb.failover(self)

    # ====== Listeners ======

    def create_listener(self, **attrs: Any) -> _listener.Listener:
        """Create a new listener from attributes

        :param attrs: Keyword arguments which will be used to create a
            :class:`~openstack.load_balancer.v2.listener.Listener`,
            comprised of the properties on the Listener class.

        :returns: The results of listener creation
        """
        return self._create(_listener.Listener, **attrs)

    def delete_listener(
        self, listener: str | _listener.Listener, ignore_missing: bool = True
    ) -> None:
        """Delete a listener

        :param listener: The value can be either the ID of a listener or a
            :class:`~openstack.load_balancer.v2.listener.Listener` instance.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the listner does not exist.
            When set to ``True``, no exception will be set when
            attempting to delete a nonexistent listener.

        :returns: ``None``
        """
        self._delete(
            _listener.Listener, listener, ignore_missing=ignore_missing
        )

    @overload
    def find_listener(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _listener.Listener: ...

    @overload
    def find_listener(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _listener.Listener | None: ...

    def find_listener(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _listener.Listener | None:
        """Find a single listener

        :param name_or_id: The name or ID of a listener.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the resource does not exist.
            When set to ``True``, None will be returned when
            attempting to find a nonexistent resource.

        :returns: One :class:`~openstack.load_balancer.v2.listener.Listener`
            or None
        """
        return self._find(
            _listener.Listener, name_or_id, ignore_missing=ignore_missing
        )

    def get_listener(
        self, listener: str | _listener.Listener
    ) -> _listener.Listener:
        """Get a single listener

        :param listener: The value can be the ID of a listener or a
            :class:`~openstack.load_balancer.v2.listener.Listener`
            instance.

        :returns: One :class:`~openstack.load_balancer.v2.listener.Listener`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        return self._get(_listener.Listener, listener)

    def get_listener_statistics(
        self, listener: str | _listener.Listener
    ) -> _listener.ListenerStats:
        """Get the listener statistics

        :param listener: The value can be the ID of a listener or a
            :class:`~openstack.load_balancer.v2.listener.Listener`
            instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.listener.ListenerStats`
        :raises: :class:`~openstack.exceptions.NotFoundException` when no
            resource can be found.
        """
        return self._get(
            _listener.ListenerStats, listener_id=listener, requires_id=False
        )

    def listeners(
        self,
        **query: Any,
    ) -> Generator[_listener.Listener, None, None]:
        """Return a generator of listeners

        :param query: Optional query parameters to be sent to limit
            the resources being returned. Valid parameters are:
        :returns: A generator of listener objects
        """
        return self._list(_listener.Listener, **query)

    def update_listener(
        self,
        listener: str | _listener.Listener,
        **attrs: Any,
    ) -> _listener.Listener:
        """Update a listener

        :param listener: Either the id of a listener or a
            :class:`~openstack.load_balancer.v2.listener.Listener`
            instance.
        :param attrs: The attributes to update on the listener
            represented by ``listener``.

        :returns: The updated listener
        """
        return self._update(_listener.Listener, listener, **attrs)

    # ====== Pools ======

    def create_pool(self, **attrs: Any) -> _pool.Pool:
        """Create a new pool from attributes

        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.load_balancer.v2.pool.Pool`, comprised of the
            properties on the Pool class.

        :returns: The results of Pool creation
        """
        return self._create(_pool.Pool, **attrs)

    def get_pool(self, pool: str | _pool.Pool) -> _pool.Pool:
        """Get a pool

        :param pool: Value is either a pool ID or a
            :class:`~openstack.load_balancer.v2.pool.Pool`
            instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.pool.Pool`
        """
        return self._get(_pool.Pool, pool)

    def pools(self, **query: Any) -> Generator[_pool.Pool, None, None]:
        """Retrieve a generator of pools

        :returns: A generator of Pool instances
        """
        return self._list(_pool.Pool, **query)

    # TODO(stephenfin): This method should return None
    def delete_pool(
        self, pool: str | _pool.Pool, ignore_missing: bool = True
    ) -> _pool.Pool | None:
        """Delete a pool

        :param pool: The pool is either a pool ID or a
            :class:`~openstack.load_balancer.v2.pool.Pool`
            instance
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the pool does not exist. When set to ``True``, no exception
            will be set when attempting to delete a nonexistent pool.

        :returns: The deleted pool.
        """
        return self._delete(_pool.Pool, pool, ignore_missing=ignore_missing)

    @overload
    def find_pool(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _pool.Pool: ...

    @overload
    def find_pool(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _pool.Pool | None: ...

    def find_pool(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _pool.Pool | None:
        """Find a single pool

        :param name_or_id: The name or ID of a pool
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the pool does not exist.
            When set to ``True``, no exception will be set when attempting
            to find a nonexistent pool.

        :returns: ``None``
        """
        return self._find(
            _pool.Pool, name_or_id, ignore_missing=ignore_missing
        )

    def update_pool(
        self,
        pool: str | _pool.Pool,
        **attrs: Any,
    ) -> _pool.Pool:
        """Update a pool

        :param pool: Either the id of a pool or a
            :class:`~openstack.load_balancer.v2.pool.Pool`
            instance.
        :param attrs: The attributes to update on the pool
            represented by ``pool``.

        :returns: The updated pool
        """
        return self._update(_pool.Pool, pool, **attrs)

    # ====== Members ======

    def create_member(
        self, pool: str | _pool.Pool, **attrs: Any
    ) -> _member.Member:
        """Create a new member from attributes

        :param pool: The pool can be either the ID of a pool or a
            :class:`~openstack.load_balancer.v2.pool.Pool` instance
            that the member will be created in.
        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.load_balancer.v2.member.Member`,
            comprised of the properties on the Member class.

        :returns: The results of member creation
        """
        poolobj = self._get_resource(_pool.Pool, pool)
        return self._create(_member.Member, pool_id=poolobj.id, **attrs)

    def delete_member(
        self,
        member: str | _member.Member,
        pool: str | _pool.Pool,
        ignore_missing: bool = True,
    ) -> None:
        """Delete a member

        :param member:
            The member can be either the ID of a member or a
            :class:`~openstack.load_balancer.v2.member.Member` instance.
        :param pool: The pool can be either the ID of a pool or a
            :class:`~openstack.load_balancer.v2.pool.Pool` instance
            that the member belongs to.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the member does not exist.
            When set to ``True``, no exception will be set when
            attempting to delete a nonexistent member.

        :returns: ``None``
        """
        poolobj = self._get_resource(_pool.Pool, pool)
        self._delete(
            _member.Member,
            member,
            ignore_missing=ignore_missing,
            pool_id=poolobj.id,
        )

    @overload
    def find_member(
        self,
        name_or_id: str,
        pool: str | _pool.Pool,
        ignore_missing: Literal[False],
    ) -> _member.Member: ...

    @overload
    def find_member(
        self,
        name_or_id: str,
        pool: str | _pool.Pool,
        ignore_missing: bool = True,
    ) -> _member.Member | None: ...

    def find_member(
        self,
        name_or_id: str,
        pool: str | _pool.Pool,
        ignore_missing: bool = True,
    ) -> _member.Member | None:
        """Find a single member

        :param name_or_id: The name or ID of a member.
        :param pool: The pool can be either the ID of a pool or a
            :class:`~openstack.load_balancer.v2.pool.Pool` instance
            that the member belongs to.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the resource does not exist.
            When set to ``True``, None will be returned when
            attempting to find a nonexistent resource.

        :returns: One :class:`~openstack.load_balancer.v2.member.Member`
            or None
        """
        poolobj = self._get_resource(_pool.Pool, pool)
        return self._find(
            _member.Member,
            name_or_id,
            ignore_missing=ignore_missing,
            pool_id=poolobj.id,
        )

    def get_member(
        self,
        member: str | _member.Member,
        pool: str | _pool.Pool,
    ) -> _member.Member:
        """Get a single member

        :param member: The member can be the ID of a member or a
            :class:`~openstack.load_balancer.v2.member.Member`
            instance.
        :param pool: The pool can be either the ID of a pool or a
            :class:`~openstack.load_balancer.v2.pool.Pool` instance
            that the member belongs to.

        :returns: One :class:`~openstack.load_balancer.v2.member.Member`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        poolobj = self._get_resource(_pool.Pool, pool)
        return self._get(_member.Member, member, pool_id=poolobj.id)

    def members(
        self,
        pool: str | _pool.Pool,
        **query: Any,
    ) -> Generator[_member.Member, None, None]:
        """Return a generator of members

        :param pool: The pool can be either the ID of a pool or a
            :class:`~openstack.load_balancer.v2.pool.Pool` instance
            that the member belongs to.
        :param query: Optional query parameters to be sent to limit
            the resources being returned. Valid parameters are:

        :returns: A generator of member objects
        """
        poolobj = self._get_resource(_pool.Pool, pool)
        return self._list(_member.Member, pool_id=poolobj.id, **query)

    def update_member(
        self,
        member: str | _member.Member,
        pool: str | _pool.Pool,
        **attrs: Any,
    ) -> _member.Member:
        """Update a member

        :param member: Either the ID of a member or a
            :class:`~openstack.load_balancer.v2.member.Member`
            instance.
        :param pool: The pool can be either the ID of a pool or a
            :class:`~openstack.load_balancer.v2.pool.Pool` instance
            that the member belongs to.
        :param attrs: The attributes to update on the member
            represented by ``member``.

        :returns: The updated member
        """
        poolobj = self._get_resource(_pool.Pool, pool)
        return self._update(
            _member.Member, member, pool_id=poolobj.id, **attrs
        )

    # ====== Health Monitors ======

    @overload
    def find_health_monitor(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _hm.HealthMonitor: ...

    @overload
    def find_health_monitor(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _hm.HealthMonitor | None: ...

    def find_health_monitor(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _hm.HealthMonitor | None:
        """Find a single health monitor

        :param name_or_id: The name or ID of a health monitor
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the health monitor does not exist.
            When set to ``True``, no exception will be set when attempting
            to find a nonexistent health monitor.

        :returns: The
            :class:`openstack.load_balancer.v2.healthmonitor.HealthMonitor`
            object matching the given name or id or None if nothing matches.

        :raises: :class:`openstack.exceptions.DuplicateResource` if more
            than one resource is found for this request.
        :raises: :class:`openstack.exceptions.NotFoundException` if nothing
            is found and ignore_missing is ``False``.
        """
        return self._find(
            _hm.HealthMonitor, name_or_id, ignore_missing=ignore_missing
        )

    def create_health_monitor(self, **attrs: Any) -> _hm.HealthMonitor:
        """Create a new health monitor from attributes

        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.load_balancer.v2.healthmonitor.HealthMonitor`,
            comprised of the properties on the HealthMonitor class.

        :returns: The results of HealthMonitor creation
        """

        return self._create(_hm.HealthMonitor, **attrs)

    def get_health_monitor(
        self, healthmonitor: str | _hm.HealthMonitor
    ) -> _hm.HealthMonitor:
        """Get a health monitor

        :param healthmonitor: The value can be the ID of a health monitor or
            :class:`~openstack.load_balancer.v2.healthmonitor.HealthMonitor`
            instance.

        :returns: One health monitor
        """
        return self._get(_hm.HealthMonitor, healthmonitor)

    def health_monitors(
        self,
        **query: Any,
    ) -> Generator[_hm.HealthMonitor, None, None]:
        """Retrieve a generator of health monitors

        :param query: Optional query parameters to be sent to limit
            the resources being returned. Valid parameters are:
            'name', 'created_at', 'updated_at', 'delay',
            'expected_codes', 'http_method', 'max_retries',
            'max_retries_down', 'pool_id',
            'provisioning_status', 'operating_status',
            'timeout', 'project_id', 'type', 'url_path',
            'is_admin_state_up'.

        :returns: A generator of health monitor instances
        """
        return self._list(_hm.HealthMonitor, **query)

    # TODO(stephenfin): This method should return None
    def delete_health_monitor(
        self,
        healthmonitor: str | _hm.HealthMonitor,
        ignore_missing: bool = True,
    ) -> _hm.HealthMonitor | None:
        """Delete a health monitor

        :param healthmonitor: The healthmonitor can be either the ID of the
            health monitor or a
            :class:`~openstack.load_balancer.v2.healthmonitor.HealthMonitor`
            instance
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the healthmonitor does not exist. When set to ``True``, no
            exception will be set when attempting to delete a nonexistent
            healthmonitor.

        :returns: The deleted health monitor.
        """
        return self._delete(
            _hm.HealthMonitor, healthmonitor, ignore_missing=ignore_missing
        )

    def update_health_monitor(
        self,
        healthmonitor: str | _hm.HealthMonitor,
        **attrs: Any,
    ) -> _hm.HealthMonitor:
        """Update a health monitor

        :param healthmonitor: The healthmonitor can be either the ID of the
            health monitor or a
            :class:`~openstack.load_balancer.v2.healthmonitor.HealthMonitor`
            instance
        :param attrs: The attributes to update on the health monitor
            represented by ``healthmonitor``.

        :returns: The updated health monitor
        """
        return self._update(_hm.HealthMonitor, healthmonitor, **attrs)

    # ====== L7 Policies ======

    def create_l7_policy(self, **attrs: Any) -> _l7policy.L7Policy:
        """Create a new l7policy from attributes

        :param attrs: Keyword arguments which will be used to create a
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`,
            comprised of the properties on the L7Policy class.

        :returns: The results of l7policy creation
        """
        return self._create(_l7policy.L7Policy, **attrs)

    def delete_l7_policy(
        self, l7_policy: str | _l7policy.L7Policy, ignore_missing: bool = True
    ) -> None:
        """Delete a l7policy

        :param l7_policy: The value can be either the ID of a l7policy or a
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy` instance.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the l7policy does not exist.
            When set to ``True``, no exception will be set when
            attempting to delete a nonexistent l7policy.

        :returns: ``None``
        """
        self._delete(
            _l7policy.L7Policy, l7_policy, ignore_missing=ignore_missing
        )

    @overload
    def find_l7_policy(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _l7policy.L7Policy: ...

    @overload
    def find_l7_policy(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _l7policy.L7Policy | None: ...

    def find_l7_policy(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _l7policy.L7Policy | None:
        """Find a single l7policy

        :param name_or_id: The name or ID of a l7policy.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the resource does not exist.
            When set to ``True``, None will be returned when
            attempting to find a nonexistent resource.

        :returns: One :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            or None
        """
        return self._find(
            _l7policy.L7Policy, name_or_id, ignore_missing=ignore_missing
        )

    def get_l7_policy(
        self, l7_policy: str | _l7policy.L7Policy
    ) -> _l7policy.L7Policy:
        """Get a single l7policy

        :param l7_policy: The value can be the ID of a l7policy or a
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            instance.

        :returns: One :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        return self._get(_l7policy.L7Policy, l7_policy)

    def l7_policies(
        self,
        **query: Any,
    ) -> Generator[_l7policy.L7Policy, None, None]:
        """Return a generator of l7policies

        :param query: Optional query parameters to be sent to limit
            the resources being returned. Valid parameters are:

        :returns: A generator of l7policy objects
        """
        return self._list(_l7policy.L7Policy, **query)

    def update_l7_policy(
        self,
        l7_policy: str | _l7policy.L7Policy,
        **attrs: Any,
    ) -> _l7policy.L7Policy:
        """Update a l7policy

        :param l7_policy: Either the id of a l7policy or a
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            instance.
        :param attrs: The attributes to update on the l7policy
            represented by ``l7policy``.

        :returns: The updated l7policy
        """
        return self._update(_l7policy.L7Policy, l7_policy, **attrs)

    # ====== L7 Rules ======

    def create_l7_rule(
        self, l7_policy: str | _l7policy.L7Policy, **attrs: Any
    ) -> _l7rule.L7Rule:
        """Create a new l7rule from attributes

        :param l7_policy: The l7_policy can be either the ID of a l7policy or
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            instance that the l7rule will be created in.
        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.load_balancer.v2.l7_rule.L7Rule`,
            comprised of the properties on the L7Rule class.

        :returns: The results of l7rule creation
        """
        l7policyobj = self._get_resource(_l7policy.L7Policy, l7_policy)
        return self._create(
            _l7rule.L7Rule, l7policy_id=l7policyobj.id, **attrs
        )

    def delete_l7_rule(
        self,
        l7rule: str | _l7rule.L7Rule,
        l7_policy: str | _l7policy.L7Policy,
        ignore_missing: bool = True,
    ) -> None:
        """Delete a l7rule

        :param l7rule: The l7rule can be either the ID of a l7rule or a
            :class:`~openstack.load_balancer.v2.l7_rule.L7Rule` instance.
        :param l7_policy: The l7_policy can be either the ID of a l7policy or
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            instance that the l7rule belongs to.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the l7rule does not exist.
            When set to ``True``, no exception will be set when
            attempting to delete a nonexistent l7rule.

        :returns: ``None``
        """
        l7policyobj = self._get_resource(_l7policy.L7Policy, l7_policy)
        self._delete(
            _l7rule.L7Rule,
            l7rule,
            ignore_missing=ignore_missing,
            l7policy_id=l7policyobj.id,
        )

    @overload
    def find_l7_rule(
        self,
        name_or_id: str,
        l7_policy: str | _l7policy.L7Policy,
        ignore_missing: Literal[False],
    ) -> _l7rule.L7Rule: ...

    @overload
    def find_l7_rule(
        self,
        name_or_id: str,
        l7_policy: str | _l7policy.L7Policy,
        ignore_missing: bool = True,
    ) -> _l7rule.L7Rule | None: ...

    def find_l7_rule(
        self,
        name_or_id: str,
        l7_policy: str | _l7policy.L7Policy,
        ignore_missing: bool = True,
    ) -> _l7rule.L7Rule | None:
        """Find a single l7rule

        :param name_or_id: The name or ID of a l7rule.
        :param l7_policy: The l7_policy can be either the ID of a l7policy or
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            instance that the l7rule belongs to.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the resource does not exist.
            When set to ``True``, None will be returned when
            attempting to find a nonexistent resource.

        :returns: One :class:`~openstack.load_balancer.v2.l7_rule.L7Rule`
            or None
        """
        l7policyobj = self._get_resource(_l7policy.L7Policy, l7_policy)
        return self._find(
            _l7rule.L7Rule,
            name_or_id,
            ignore_missing=ignore_missing,
            l7policy_id=l7policyobj.id,
        )

    def get_l7_rule(
        self,
        l7rule: str | _l7rule.L7Rule,
        l7_policy: str | _l7policy.L7Policy,
    ) -> _l7rule.L7Rule:
        """Get a single l7rule

        :param l7rule: The l7rule can be the ID of a l7rule or a
            :class:`~openstack.load_balancer.v2.l7_rule.L7Rule`
            instance.
        :param l7_policy: The l7_policy can be either the ID of a l7policy or
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            instance that the l7rule belongs to.

        :returns: One :class:`~openstack.load_balancer.v2.l7_rule.L7Rule`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        l7policyobj = self._get_resource(_l7policy.L7Policy, l7_policy)
        return self._get(_l7rule.L7Rule, l7rule, l7policy_id=l7policyobj.id)

    def l7_rules(
        self,
        l7_policy: str | _l7policy.L7Policy,
        **query: Any,
    ) -> Generator[_l7rule.L7Rule, None, None]:
        """Return a generator of l7rules

        :param l7_policy: The l7_policy can be either the ID of a l7_policy or
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            instance that the l7rule belongs to.
        :param query: Optional query parameters to be sent to limit
            the resources being returned. Valid parameters are:

        :returns: A generator of l7rule objects
        """
        l7policyobj = self._get_resource(_l7policy.L7Policy, l7_policy)
        return self._list(_l7rule.L7Rule, l7policy_id=l7policyobj.id, **query)

    def update_l7_rule(
        self,
        l7rule: str | _l7rule.L7Rule,
        l7_policy: str | _l7policy.L7Policy,
        **attrs: Any,
    ) -> _l7rule.L7Rule:
        """Update a l7rule

        :param l7rule: Either the ID of a l7rule or a
            :class:`~openstack.load_balancer.v2.l7_rule.L7Rule`
            instance.
        :param l7_policy: The l7_policy can be either the ID of a l7policy or
            :class:`~openstack.load_balancer.v2.l7_policy.L7Policy`
            instance that the l7rule belongs to.
        :param attrs: The attributes to update on the l7rule
            represented by ``l7rule``.

        :returns: The updated l7rule
        """
        l7policyobj = self._get_resource(_l7policy.L7Policy, l7_policy)
        return self._update(
            _l7rule.L7Rule, l7rule, l7policy_id=l7policyobj.id, **attrs
        )

    # ====== Quotas ======

    def quotas(self, **query: Any) -> Generator[_quota.Quota, None, None]:
        """Return a generator of quotas

        :param query: Optional query parameters to be sent to limit
            the resources being returned. Currently no query
            parameter is supported.

        :returns: A generator of quota objects
        """
        return self._list(_quota.Quota, **query)

    def get_quota(self, quota: str | _quota.Quota) -> _quota.Quota:
        """Get a quota

        :param quota: The value can be the ID of a quota or a
            :class:`~openstack.load_balancer.v2.quota.Quota`
            instance. The ID of a quota is the same as the project
            ID for the quota.

        :returns: One :class:`~openstack.load_balancer.v2.quota.Quota`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        return self._get(_quota.Quota, quota)

    def update_quota(
        self,
        quota: str | _quota.Quota,
        **attrs: Any,
    ) -> _quota.Quota:
        """Update a quota

        :param quota: Either the ID of a quota or a
            :class:`~openstack.load_balancer.v2.quota.Quota`
            instance. The ID of a quota is the same as the
            project ID for the quota.
        :param attrs: The attributes to update on the quota represented
            by ``quota``.

        :returns: The updated quota
        """
        return self._update(_quota.Quota, quota, **attrs)

    def get_quota_default(self) -> _quota.QuotaDefault:
        """Get a default quota

        :returns: One :class:`~openstack.load_balancer.v2.quota.QuotaDefault`
        """
        return self._get(_quota.QuotaDefault, requires_id=False)

    def delete_quota(
        self, quota: str | _quota.Quota, ignore_missing: bool = True
    ) -> None:
        """Delete a quota (i.e. reset to the default quota)

        :param quota: The value can be either the ID of a quota or a
            :class:`~openstack.load_balancer.v2.quota.Quota`
            instance. The ID of a quota is the same as the
            project ID for the quota.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when quota does not exist.
            When set to ``True``, no exception will be set when
            attempting to delete a nonexistent quota.

        :returns: ``None``
        """
        self._delete(_quota.Quota, quota, ignore_missing=ignore_missing)

    # ====== Providers ======

    def providers(
        self,
        **query: Any,
    ) -> Generator[_provider.Provider, None, None]:
        """Retrieve a generator of providers

        :returns: A generator of providers instances
        """
        return self._list(_provider.Provider, **query)

    def provider_flavor_capabilities(
        self,
        provider: str,
        **query: Any,
    ) -> Generator[_provider.ProviderFlavorCapabilities, None, None]:
        """Retrieve a generator of provider flavor capabilities

        :returns: A generator of provider flavor capabilities instances
        """
        return self._list(
            _provider.ProviderFlavorCapabilities, provider=provider, **query
        )

    # ====== Flavor Profiles ======

    def create_flavor_profile(
        self, **attrs: Any
    ) -> _flavor_profile.FlavorProfile:
        """Create a new flavor profile from attributes

        :param attrs: Keyword arguments which will be used to create a
            :class:`~openstack.load_balancer.v2.flavor_profile.FlavorProfile`,
            comprised of the properties on the FlavorProfile class.

        :returns: The results of profile creation creation
        """
        return self._create(_flavor_profile.FlavorProfile, **attrs)

    def get_flavor_profile(
        self, flavor_profile: str | _flavor_profile.FlavorProfile
    ) -> _flavor_profile.FlavorProfile:
        """Get a flavor profile

        :param flavor_profile: The value can be the name of a flavor profile or
            :class:`~openstack.load_balancer.v2.flavor_profile.FlavorProfile`
            instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.flavor_profile.FlavorProfile`
        """
        return self._get(_flavor_profile.FlavorProfile, flavor_profile)

    def flavor_profiles(
        self,
        **query: Any,
    ) -> Generator[_flavor_profile.FlavorProfile, None, None]:
        """Retrieve a generator of flavor profiles

        :returns: A generator of flavor profiles instances
        """
        return self._list(_flavor_profile.FlavorProfile, **query)

    def delete_flavor_profile(
        self,
        flavor_profile: str | _flavor_profile.FlavorProfile,
        ignore_missing: bool = True,
    ) -> None:
        """Delete a flavor profile

        :param flavor_profile: The flavor_profile can be either the ID or a
            :class:`~openstack.load_balancer.v2.flavor_profile.FlavorProfile`
            instance
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the flavor profile does not exist. When set to ``True``, no
            exception will be set when attempting to delete a nonexistent
            flavor profile.

        :returns: ``None``
        """
        self._delete(
            _flavor_profile.FlavorProfile,
            flavor_profile,
            ignore_missing=ignore_missing,
        )

    @overload
    def find_flavor_profile(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _flavor_profile.FlavorProfile: ...

    @overload
    def find_flavor_profile(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _flavor_profile.FlavorProfile | None: ...

    def find_flavor_profile(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _flavor_profile.FlavorProfile | None:
        """Find a single flavor profile

        :param name_or_id: The name or ID of a flavor profile
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the flavor profile does not exist.
            When set to ``True``, no exception will be set when attempting
            to find a nonexistent flavor profile.

        :returns: ``None``
        """
        return self._find(
            _flavor_profile.FlavorProfile,
            name_or_id,
            ignore_missing=ignore_missing,
        )

    def update_flavor_profile(
        self,
        flavor_profile: str | _flavor_profile.FlavorProfile,
        **attrs: Any,
    ) -> _flavor_profile.FlavorProfile:
        """Update a flavor profile

        :param flavor_profile: The flavor_profile can be either the ID or a
            :class:`~openstack.load_balancer.v2.flavor_profile.FlavorProfile`
            instance
        :param attrs: The attributes to update on the flavor profile
            represented by ``flavor_profile``.

        :returns: The updated flavor profile
        """
        return self._update(
            _flavor_profile.FlavorProfile, flavor_profile, **attrs
        )

    # ====== Flavors ======

    def create_flavor(self, **attrs: Any) -> _flavor.Flavor:
        """Create a new flavor from attributes

        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.load_balancer.v2.flavor.Flavor`,
            comprised of the properties on the Flavorclass.

        :returns: The results of flavor creation creation
        """
        return self._create(_flavor.Flavor, **attrs)

    def get_flavor(self, flavor: str | _flavor.Flavor) -> _flavor.Flavor:
        """Get a flavor

        :param flavor: The value can be the ID of a flavor
            or :class:`~openstack.load_balancer.v2.flavor.Flavor` instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.flavor.Flavor`
        """
        return self._get(_flavor.Flavor, flavor)

    def flavors(self, **query: Any) -> Generator[_flavor.Flavor, None, None]:
        """Retrieve a generator of flavors

        :returns: A generator of flavor instances
        """
        return self._list(_flavor.Flavor, **query)

    def delete_flavor(
        self, flavor: str | _flavor.Flavor, ignore_missing: bool = True
    ) -> None:
        """Delete a flavor

        :param flavor: The flavorcan be either the ID or a
            :class:`~openstack.load_balancer.v2.flavor.Flavor` instance
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the flavor does not exist. When set to ``True``, no exception
            will be set when attempting to delete a nonexistent flavor.

        :returns: ``None``
        """
        self._delete(_flavor.Flavor, flavor, ignore_missing=ignore_missing)

    @overload
    def find_flavor(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _flavor.Flavor: ...

    @overload
    def find_flavor(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _flavor.Flavor | None: ...

    def find_flavor(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _flavor.Flavor | None:
        """Find a single flavor

        :param name_or_id: The name or ID of a flavor
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the flavor does not exist.
            When set to ``True``, no exception will be set when attempting
            to find a nonexistent flavor.

        :returns: ``None``
        """
        return self._find(
            _flavor.Flavor, name_or_id, ignore_missing=ignore_missing
        )

    def update_flavor(
        self,
        flavor: str | _flavor.Flavor,
        **attrs: Any,
    ) -> _flavor.Flavor:
        """Update a flavor

        :param flavor: The flavor can be either the ID or a
            :class:`~openstack.load_balancer.v2.flavor.Flavor` instance
        :param attrs: The attributes to update on the flavor
            represented by ``flavor``.

        :returns: The updated flavor
        """
        return self._update(_flavor.Flavor, flavor, **attrs)

    # ====== Amphorae ======

    def amphorae(
        self,
        **query: Any,
    ) -> Generator[_amphora.Amphora, None, None]:
        """Retrieve a generator of amphorae

        :returns: A generator of amphora instances
        """
        return self._list(_amphora.Amphora, **query)

    def get_amphora(self, amphora: str | _amphora.Amphora) -> _amphora.Amphora:
        """Get a amphora

        :param amphora: The value can be the ID of an amphora
            or :class:`~openstack.load_balancer.v2.amphora.Amphora` instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.amphora.Amphora`
        """
        return self._get(_amphora.Amphora, amphora)

    @overload
    def find_amphora(
        self,
        amphora: str,
        ignore_missing: Literal[False],
    ) -> _amphora.Amphora: ...

    @overload
    def find_amphora(
        self,
        amphora: str,
        ignore_missing: bool = True,
    ) -> _amphora.Amphora | None: ...

    @renamed_param('amphora_id', 'amphora')
    def find_amphora(
        self,
        amphora: str,
        ignore_missing: bool = True,
    ) -> _amphora.Amphora | None:
        """Find a single amphora

        :param amphora: The ID or a
            :class:`~openstack.load_balancer.v2.amphora.Amphora` instance.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the amphora does not exist.
            When set to ``True``, no exception will be set when attempting
            to find a nonexistent amphora.

        :returns: ``None``
        """
        return self._find(
            _amphora.Amphora, amphora, ignore_missing=ignore_missing
        )

    @renamed_param('amphora_id', 'amphora')
    def configure_amphora(
        self,
        amphora: str | _amphora.Amphora,
    ) -> None:
        """Update the configuration of an amphora agent

        :param amphora: The ID or a
            :class:`~openstack.load_balancer.v2.amphora.Amphora` instance.

        :returns: ``None``
        """
        lb = self._get_resource(_amphora.Amphora, amphora)
        lb.configure(self)

    @renamed_param('amphora_id', 'amphora')
    def failover_amphora(
        self,
        amphora: str | _amphora.Amphora,
    ) -> None:
        """Failover an amphora

        :param amphora: The ID or a
            :class:`~openstack.load_balancer.v2.amphora.Amphora` instance.

        :returns: ``None``
        """
        lb = self._get_resource(_amphora.Amphora, amphora)
        lb.failover(self)

    # ====== Availability Zone Profiles ======

    def create_availability_zone_profile(
        self, **attrs: Any
    ) -> _availability_zone_profile.AvailabilityZoneProfile:
        """Create a new availability zone profile from attributes

        :param attrs: Keyword arguments which will be used to create a
            :class:`~openstack.load_balancer.v2.availability_zone_profile.AvailabilityZoneProfile`
            comprised of the properties on the AvailabilityZoneProfile
            class.

        :returns: The results of profile creation
        """
        return self._create(
            _availability_zone_profile.AvailabilityZoneProfile, **attrs
        )

    def get_availability_zone_profile(
        self,
        availability_zone_profile: str
        | _availability_zone_profile.AvailabilityZoneProfile,
    ) -> _availability_zone_profile.AvailabilityZoneProfile:
        """Get an availability zone profile

        :param availability_zone_profile: The value can be the ID of an
            availability_zone profile or
            :class:`~openstack.load_balancer.v2.availability_zone_profile.AvailabilityZoneProfile`
            instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.availability_zone_profile.AvailabilityZoneProfile`
        """
        return self._get(
            _availability_zone_profile.AvailabilityZoneProfile,
            availability_zone_profile,
        )

    def availability_zone_profiles(
        self,
        **query: Any,
    ) -> Generator[
        _availability_zone_profile.AvailabilityZoneProfile, None, None
    ]:
        """Retrieve a generator of availability zone profiles

        :returns: A generator of availability zone profiles instances
        """
        return self._list(
            _availability_zone_profile.AvailabilityZoneProfile, **query
        )

    def delete_availability_zone_profile(
        self,
        availability_zone_profile: str
        | _availability_zone_profile.AvailabilityZoneProfile,
        ignore_missing: bool = True,
    ) -> None:
        """Delete an availability zone profile

        :param availability_zone_profile: The availability_zone_profile can be
            either the ID or a
            :class:`~openstack.load_balancer.v2.availability_zone_profile.AvailabilityZoneProfile`
            instance
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the availability zone profile does not exist. When set to
            ``True``, no exception will be set when attempting to delete a
            nonexistent availability zone profile.

        :returns: ``None``
        """
        self._delete(
            _availability_zone_profile.AvailabilityZoneProfile,
            availability_zone_profile,
            ignore_missing=ignore_missing,
        )

    @overload
    def find_availability_zone_profile(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _availability_zone_profile.AvailabilityZoneProfile: ...

    @overload
    def find_availability_zone_profile(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _availability_zone_profile.AvailabilityZoneProfile | None: ...

    def find_availability_zone_profile(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _availability_zone_profile.AvailabilityZoneProfile | None:
        """Find a single availability zone profile

        :param name_or_id: The name or ID of a availability zone profile
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the availability zone profile does not exist.
            When set to ``True``, no exception will be set when attempting
            to find a nonexistent availability zone profile.

        :returns: ``None``
        """
        return self._find(
            _availability_zone_profile.AvailabilityZoneProfile,
            name_or_id,
            ignore_missing=ignore_missing,
        )

    def update_availability_zone_profile(
        self,
        availability_zone_profile: str
        | _availability_zone_profile.AvailabilityZoneProfile,
        **attrs: Any,
    ) -> _availability_zone_profile.AvailabilityZoneProfile:
        """Update an availability zone profile

        :param availability_zone_profile: The availability_zone_profile can be
            either the ID or a
            :class:`~openstack.load_balancer.v2.availability_zone_profile.AvailabilityZoneProfile`
            instance
        :param attrs: The attributes to update on the availability_zone
            profile represented by ``availability_zone_profile``.

        :returns: The updated availability zone profile
        """
        return self._update(
            _availability_zone_profile.AvailabilityZoneProfile,
            availability_zone_profile,
            **attrs,
        )

    # ====== Availability Zones ======

    def create_availability_zone(
        self, **attrs: Any
    ) -> _availability_zone.AvailabilityZone:
        """Create a new availability zone from attributes

        :param attrs: Keyword arguments which will be used to create a
            :class:`~openstack.load_balancer.v2.availability_zone.AvailabilityZone`
            comprised of the properties on the AvailabilityZoneclass.

        :returns: The results of availability_zone creation creation
        """
        return self._create(_availability_zone.AvailabilityZone, **attrs)

    def get_availability_zone(
        self,
        availability_zone: str | _availability_zone.AvailabilityZone,
    ) -> _availability_zone.AvailabilityZone:
        """Get an availability zone

        :param availability_zone: The value can be the ID of a
            availability_zone or
            :class:`~openstack.load_balancer.v2.availability_zone.AvailabilityZone`
            instance.

        :returns: One
            :class:`~openstack.load_balancer.v2.availability_zone.AvailabilityZone`
        """
        return self._get(
            _availability_zone.AvailabilityZone, availability_zone
        )

    def availability_zones(
        self,
        **query: Any,
    ) -> Generator[_availability_zone.AvailabilityZone, None, None]:
        """Retrieve a generator of availability zones

        :returns: A generator of availability zone instances
        """
        return self._list(_availability_zone.AvailabilityZone, **query)

    def delete_availability_zone(
        self,
        availability_zone: str | _availability_zone.AvailabilityZone,
        ignore_missing: bool = True,
    ) -> None:
        """Delete an availability_zone

        :param availability_zone: The availability_zone can be either the ID
            or a
            :class:`~openstack.load_balancer.v2.availability_zone.AvailabilityZone`
            instance
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the availability zone does not exist. When set to ``True``, no
            exception will be set when attempting to delete a nonexistent
            availability zone.

        :returns: ``None``
        """
        self._delete(
            _availability_zone.AvailabilityZone,
            availability_zone,
            ignore_missing=ignore_missing,
        )

    @overload
    def find_availability_zone(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _availability_zone.AvailabilityZone: ...

    @overload
    def find_availability_zone(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _availability_zone.AvailabilityZone | None: ...

    def find_availability_zone(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _availability_zone.AvailabilityZone | None:
        """Find a single availability zone

        :param name_or_id: The name or ID of a availability zone
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be raised
            when the availability zone does not exist.
            When set to ``True``, no exception will be set when attempting
            to find a nonexistent availability zone.

        :returns: ``None``
        """
        return self._find(
            _availability_zone.AvailabilityZone,
            name_or_id,
            ignore_missing=ignore_missing,
        )

    def update_availability_zone(
        self,
        availability_zone: str | _availability_zone.AvailabilityZone,
        **attrs: Any,
    ) -> _availability_zone.AvailabilityZone:
        """Update an availability zone

        :param availability_zone: The availability_zone can be either the ID
            or a
            :class:`~openstack.load_balancer.v2.availability_zone.AvailabilityZone`
            instance
        :param attrs: The attributes to update on the availability_zone
            represented by ``availability_zone``.

        :returns: The updated availability_zone
        """
        return self._update(
            _availability_zone.AvailabilityZone, availability_zone, **attrs
        )

    # ====== Utilities ======

    def wait_for_status(
        self,
        res: resource.ResourceT,
        status: str,
        failures: list[str] | None = None,
        interval: int | float | None = 2,
        wait: int | None = None,
        attribute: str = 'status',
        callback: Callable[[int], None] | None = None,
    ) -> resource.ResourceT:
        """Wait for the resource to be in a particular status.

        :param session: The session to use for making this request.
        :param resource: The resource to wait on to reach the status. The
            resource must have a status attribute specified via ``attribute``.
        :param status: Desired status of the resource.
        :param failures: Statuses that would indicate the transition
            failed such as 'ERROR'. Defaults to ['ERROR'].
        :param interval: Number of seconds to wait between checks.
        :param wait: Maximum number of seconds to wait for transition.
            Set to ``None`` to wait forever.
        :param attribute: Name of the resource attribute that contains the
            status.
        :param callback: A callback function. This will be called with a single
            value, progress. This is API specific but is generally a percentage
            value from 0-100.

        :returns: The updated resource.
        :raises: :class:`~openstack.exceptions.ResourceTimeout` if the
            transition to status failed to occur in ``wait`` seconds.
        :raises: :class:`~openstack.exceptions.ResourceFailure` if the resource
            transitioned to one of the states in ``failures``.
        :raises: :class:`~AttributeError` if the resource does not have a
            ``status`` attribute
        """
        return resource.wait_for_status(
            self, res, status, failures, interval, wait, attribute, callback
        )

    def wait_for_delete(
        self,
        res: resource.ResourceT,
        interval: int | float | None = 2,
        wait: int | None = 120,
        callback: Callable[[int], None] | None = None,
    ) -> resource.ResourceT:
        """Wait for a resource to be deleted.

        :param res: The resource to wait on to be deleted.
        :param interval: Number of seconds to wait before to consecutive
            checks.
        :param wait: Maximum number of seconds to wait before the change.
        :param callback: A callback function. This will be called with a single
            value, progress, which is a percentage value from 0-100.

        :returns: The resource is returned on success.
        :raises: :class:`~openstack.exceptions.ResourceTimeout` if transition
            to delete failed to occur in the specified seconds.
        """
        return resource.wait_for_delete(self, res, interval, wait, callback)

    def _get_cleanup_dependencies(self) -> dict[str, Any]:
        return {
            'load_balancer': {'before': ['compute', 'network']},
        }

    def _service_cleanup(
        self,
        dry_run: bool = True,
        client_status_queue: queue.Queue[resource.Resource] | None = None,
        identified_resources: dict[str, resource.Resource] | None = None,
        filters: dict[str, Any] | None = None,
        resource_evaluation_fn: Callable[
            [
                resource.Resource,
                dict[str, Any] | None,
                dict[str, resource.Resource] | None,
            ],
            bool,
        ]
        | None = None,
        skip_resources: Sequence[str] | None = None,
    ) -> None:
        if self.should_skip_resource_cleanup("load_balancer", skip_resources):
            return

        load_balancers = []
        for lb in self.load_balancers():
            need_delete = self._service_cleanup_del_res(
                functools.partial(self.delete_load_balancer, cascade=True),
                lb,
                dry_run=dry_run,
                client_status_queue=client_status_queue,
                identified_resources=identified_resources,
                filters=filters,
                resource_evaluation_fn=resource_evaluation_fn,
            )
            if not dry_run and need_delete:
                load_balancers.append(lb)

        for lb in load_balancers:
            try:
                self.wait_for_delete(lb)
            except Exception:
                self.log.exception(
                    "Failed to wait for load balancer %s deletion",
                    lb.id,
                )
