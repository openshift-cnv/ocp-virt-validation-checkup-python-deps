# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from openstack.tests.functional.block_storage.v3 import base


class ResourceFilters(base.BaseBlockStorageTest):
    def test_get(self):
        resource_filters = list(
            self.admin_block_storage_client.resource_filters()
        )

        for rf in resource_filters:
            self.assertIsInstance(rf.filters, list)
            self.assertIsInstance(rf.resource, str)
