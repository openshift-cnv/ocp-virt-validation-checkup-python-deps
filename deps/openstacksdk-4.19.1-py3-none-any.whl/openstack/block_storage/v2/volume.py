# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


from typing import Any, cast

import requests

from keystoneauth1 import adapter

from openstack.common import metadata
from openstack import format
from openstack import resource
from openstack import utils


class Volume(resource.Resource, metadata.MetadataMixin):
    resource_key = "volume"
    resources_key = "volumes"
    base_path = "/volumes"

    _query_mapping = resource.QueryParameters(
        'name', 'status', 'project_id', all_projects='all_tenants'
    )

    # capabilities
    allow_fetch = True
    allow_create = True
    allow_delete = True
    allow_commit = True
    allow_list = True

    # Properties
    #: TODO(briancurtin): This is currently undocumented in the API.
    attachments = resource.Body("attachments")
    #: The availability zone.
    availability_zone = resource.Body("availability_zone")
    #: ID of the consistency group.
    consistency_group_id = resource.Body("consistencygroup_id")
    #: The timestamp of this volume creation.
    created_at = resource.Body("created_at")
    #: The volume description.
    description = resource.Body("description")
    #: Extended replication status on this volume.
    extended_replication_status = resource.Body(
        "os-volume-replication:extended_status"
    )
    #: The volume's current back-end.
    host = resource.Body("os-vol-host-attr:host")
    #: The ID of the image from which you want to create the volume.
    #: Required to create a bootable volume.
    image_id = resource.Body("imageRef")
    #: Enables or disables the bootable attribute. You can boot an
    #: instance from a bootable volume. *Type: bool*
    is_bootable = resource.Body("bootable", type=format.BoolStr)
    #: ``True`` if this volume is encrypted, ``False`` if not.
    #: *Type: bool*
    is_encrypted = resource.Body("encrypted", type=format.BoolStr)
    #: Whether volume will be sharable or not.
    is_multiattach = resource.Body("multiattach", type=format.BoolStr)
    #: The volume ID that this volume's name on the back-end is based on.
    migration_id = resource.Body("os-vol-mig-status-attr:name_id")
    #: The status of this volume's migration (None means that a migration
    #: is not currently in progress).
    migration_status = resource.Body("os-vol-mig-status-attr:migstat")
    #: The project ID associated with current back-end.
    project_id = resource.Body("os-vol-tenant-attr:tenant_id")
    #: Data set by the replication driver
    replication_driver_data = resource.Body(
        "os-volume-replication:driver_data"
    )
    #: Status of replication on this volume.
    replication_status = resource.Body("replication_status")
    #: Scheduler hints for the volume
    scheduler_hints = resource.Body('OS-SCH-HNT:scheduler_hints', type=dict)
    #: The size of the volume, in gibibytes (GiB). *Type: int*
    size = resource.Body("size", type=int)
    #: To create a volume from an existing snapshot, specify the ID of
    #: the existing volume snapshot. If specified, the volume is created
    #: in same availability zone and with same size of the snapshot.
    snapshot_id = resource.Body("snapshot_id")
    #: To create a volume from an existing volume, specify the ID of
    #: the existing volume. If specified, the volume is created with
    #: same size of the source volume.
    source_volume_id = resource.Body("source_volid")
    #: One of the following values: creating, available, attaching, in-use
    #: deleting, error, error_deleting, backing-up, restoring-backup,
    #: error_restoring. For details on these statuses, see the
    #: Block Storage API documentation.
    status = resource.Body("status")
    #: The date and time when the resource was updated.
    updated_at = resource.Body("updated_at")
    #: The user ID associated with the volume
    user_id = resource.Body("user_id")
    #: One or more metadata key and value pairs about image
    volume_image_metadata = resource.Body("volume_image_metadata")
    #: The name of the associated volume type.
    volume_type = resource.Body("volume_type")

    def _action(
        self, session: adapter.Adapter, body: dict[str, Any]
    ) -> requests.Response:
        """Preform volume actions given the message body."""
        # NOTE: This is using Volume.base_path instead of self.base_path
        # as both Volume and VolumeDetail instances can be acted on, but
        # the URL used is sans any additional /detail/ part.
        url = utils.urljoin(Volume.base_path, self.id, 'action')
        return session.post(url, json=body)

    def extend(self, session: adapter.Adapter, size: int) -> None:
        """Extend a volume size."""
        body = {'os-extend': {'new_size': size}}
        self._action(session, body)

    def set_bootable_status(
        self, session: adapter.Adapter, bootable: bool = True
    ) -> None:
        """Set volume bootable status flag"""
        body = {'os-set_bootable': {'bootable': bootable}}
        self._action(session, body)

    def set_readonly(self, session: adapter.Adapter, readonly: bool) -> None:
        """Set volume readonly flag"""
        body = {'os-update_readonly_flag': {'readonly': readonly}}
        self._action(session, body)

    def set_image_metadata(
        self, session: adapter.Adapter, metadata: dict[str, str]
    ) -> None:
        """Sets image metadata key-value pairs on the volume"""
        body = {'os-set_image_metadata': {'metadata': metadata}}
        self._action(session, body)

    def delete_image_metadata(self, session: adapter.Adapter) -> None:
        """Remove all image metadata from the volume"""
        for key in self.metadata:
            body = {'os-unset_image_metadata': {'key': key}}
            self._action(session, body)

    def delete_image_metadata_item(
        self, session: adapter.Adapter, key: str
    ) -> None:
        """Remove a single image metadata from the volume"""
        body = {'os-unset_image_metadata': {'key': key}}
        self._action(session, body)

    def reset_status(
        self,
        session: adapter.Adapter,
        status: str | None = None,
        attach_status: str | None = None,
        migration_status: str | None = None,
    ) -> None:
        """Reset volume statuses (admin operation)"""
        body: dict[str, dict[str, str]] = {'os-reset_status': {}}
        if status:
            body['os-reset_status']['status'] = status
        if attach_status:
            body['os-reset_status']['attach_status'] = attach_status
        if migration_status:
            body['os-reset_status']['migration_status'] = migration_status
        self._action(session, body)

    def attach(
        self,
        session: adapter.Adapter,
        mountpoint: str,
        instance: str | None = None,
        host_name: str | None = None,
    ) -> None:
        """Attach volume to server"""
        body = {
            'os-attach': {'mountpoint': mountpoint},
        }
        if instance is not None:
            body['os-attach']['instance_uuid'] = instance
        elif host_name is not None:
            body['os-attach']['host_name'] = host_name
        else:
            raise ValueError(
                'Either instance_uuid or host_name must be specified'
            )

        self._action(session, body)

    def detach(
        self,
        session: adapter.Adapter,
        attachment: str,
        force: bool = False,
        connector: dict[str, Any] | None = None,
    ) -> None:
        """Detach volume from server"""
        if not force:
            body = {'os-detach': {'attachment_id': attachment}}
        if force:
            inner: dict[str, Any] = {'attachment_id': attachment}
            if connector:
                inner['connector'] = connector
            body = {'os-force_detach': inner}

        self._action(session, body)

    def unmanage(self, session: adapter.Adapter) -> None:
        """Unmanage volume"""
        body = {'os-unmanage': None}

        self._action(session, body)

    def retype(
        self,
        session: adapter.Adapter,
        new_type: str,
        migration_policy: str | None = None,
    ) -> None:
        """Change volume type"""
        body = {'os-retype': {'new_type': new_type}}
        if migration_policy:
            body['os-retype']['migration_policy'] = migration_policy

        self._action(session, body)

    def migrate(
        self,
        session: adapter.Adapter,
        host: str | None = None,
        force_host_copy: bool = False,
        lock_volume: bool = False,
    ) -> None:
        """Migrate volume"""
        req: dict[str, Any] = {}
        if host is not None:
            req['host'] = host
        if force_host_copy:
            req['force_host_copy'] = force_host_copy
        if lock_volume:
            req['lock_volume'] = lock_volume
        body = {'os-migrate_volume': req}

        self._action(session, body)

    def complete_migration(
        self,
        session: adapter.Adapter,
        new_volume_id: str,
        error: bool = False,
    ) -> None:
        """Complete volume migration"""
        body = {
            'os-migrate_volume_completion': {
                'new_volume': new_volume_id,
                'error': error,
            }
        }

        self._action(session, body)

    def force_delete(self, session: adapter.Adapter) -> None:
        """Force volume deletion"""
        body = {'os-force_delete': None}

        self._action(session, body)

    def upload_to_image(
        self,
        session: adapter.Adapter,
        image_name: str,
        *,
        force: bool = False,
        disk_format: str | None = None,
        container_format: str | None = None,
    ) -> dict[str, Any]:
        """Upload the volume to image service"""
        body = {
            'os-volume_upload_image': {
                'image_name': image_name,
                'force': force,
                'disk_format': disk_format,
                'container_format': container_format,
            },
        }

        resp = cast(dict[str, Any], self._action(session, body).json())
        return cast(dict[str, Any], resp['os-volume_upload_image'])


VolumeDetail = Volume
