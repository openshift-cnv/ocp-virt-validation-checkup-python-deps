# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from typing import Any, ClassVar, Literal, overload
from collections.abc import Callable, Generator

from openstack.database.v1 import database as _database
from openstack.database.v1 import flavor as _flavor
from openstack.database.v1 import instance as _instance
from openstack.database.v1 import user as _user
from openstack import proxy
from openstack import resource


class Proxy(proxy.Proxy):
    api_version: ClassVar[Literal['1']] = '1'

    _resource_registry = {
        "database": _database.Database,
        "flavor": _flavor.Flavor,
        "instance": _instance.Instance,
        "user": _user.User,
    }

    def create_database(
        self,
        instance: str | _instance.Instance,
        **attrs: Any,
    ) -> _database.Database:
        """Create a new database from attributes

        :param instance: This can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.database.v1.database.Database`,
            comprised of the properties on the Database class.

        :returns: The results of server creation
        """
        instance = self._get_resource(_instance.Instance, instance)
        return self._create(
            _database.Database, instance_id=instance.id, **attrs
        )

    def delete_database(
        self,
        database: str | _database.Database,
        instance: str | _instance.Instance | None = None,
        ignore_missing: bool = True,
    ) -> None:
        """Delete a database

        :param database: The value can be either the ID of a database or a
            :class:`~openstack.database.v1.database.Database` instance.
        :param instance: This parameter needs to be specified when
            an ID is given as `database`.
            It can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the database does not exist.
            When set to ``True``, no exception will be set when
            attempting to delete a nonexistent database.

        :returns: ``None``
        """
        instance_id = self._get_uri_attribute(
            database, instance, "instance_id"
        )
        self._delete(
            _database.Database,
            database,
            instance_id=instance_id,
            ignore_missing=ignore_missing,
        )

    @overload
    def find_database(
        self,
        name_or_id: str,
        instance: str | _instance.Instance,
        ignore_missing: Literal[False],
    ) -> _database.Database: ...

    @overload
    def find_database(
        self,
        name_or_id: str,
        instance: str | _instance.Instance,
        ignore_missing: bool = True,
    ) -> _database.Database | None: ...

    def find_database(
        self,
        name_or_id: str,
        instance: str | _instance.Instance,
        ignore_missing: bool = True,
    ) -> _database.Database | None:
        """Find a single database

        :param name_or_id: The name or ID of a database.
        :param instance: This can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the resource does not exist.
            When set to ``True``, None will be returned when
            attempting to find a nonexistent resource.
        :returns: One :class:`~openstack.database.v1.database.Database` or None
        """
        instance = self._get_resource(_instance.Instance, instance)
        return self._find(
            _database.Database,
            name_or_id,
            instance_id=instance.id,
            ignore_missing=ignore_missing,
        )

    def databases(
        self,
        instance: str | _instance.Instance,
        **query: Any,
    ) -> Generator[_database.Database, None, None]:
        """Return a generator of databases

        :param instance: This can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
            instance that the interface belongs to.
        :param query: Optional query parameters to be sent to limit
            the resources being returned.

        :returns: A generator of database objects
        """
        instance = self._get_resource(_instance.Instance, instance)
        return self._list(_database.Database, instance_id=instance.id, **query)

    def get_database(
        self,
        database: str | _database.Database,
        instance: str | _instance.Instance | None = None,
    ) -> _database.Database:
        """Get a single database

        :param instance: This parameter needs to be specified when
            an ID is given as `database`.
            It can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
        :param database: The value can be the ID of a database or a
            :class:`~openstack.database.v1.database.Database`
            instance.

        :returns: One :class:`~openstack.database.v1.database.Database`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        return self._get(_database.Database, database)

    @overload
    def find_flavor(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _flavor.Flavor: ...

    @overload
    def find_flavor(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _flavor.Flavor | None: ...

    def find_flavor(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _flavor.Flavor | None:
        """Find a single flavor

        :param name_or_id: The name or ID of a flavor.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the resource does not exist.
            When set to ``True``, None will be returned when
            attempting to find a nonexistent resource.
        :returns: One :class:`~openstack.database.v1.flavor.Flavor` or None
        """
        return self._find(
            _flavor.Flavor, name_or_id, ignore_missing=ignore_missing
        )

    def get_flavor(self, flavor: str | _flavor.Flavor) -> _flavor.Flavor:
        """Get a single flavor

        :param flavor: The value can be the ID of a flavor or a
            :class:`~openstack.database.v1.flavor.Flavor` instance.

        :returns: One :class:`~openstack.database.v1.flavor.Flavor`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        return self._get(_flavor.Flavor, flavor)

    def flavors(self, **query: Any) -> Generator[_flavor.Flavor, None, None]:
        """Return a generator of flavors

        :param query: Optional query parameters to be sent to limit
            the resources being returned.

        :returns: A generator of flavor objects
        """
        return self._list(_flavor.Flavor, **query)

    def create_instance(self, **attrs: Any) -> _instance.Instance:
        """Create a new instance from attributes

        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.database.v1.instance.Instance`,
            comprised of the properties on the Instance class.

        :returns: The results of server creation
        """
        return self._create(_instance.Instance, **attrs)

    def delete_instance(
        self, instance: str | _instance.Instance, ignore_missing: bool = True
    ) -> None:
        """Delete an instance

        :param instance: The value can be either the ID of an instance or a
            :class:`~openstack.database.v1.instance.Instance` instance.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the instance does not exist.
            When set to ``True``, no exception will be set when
            attempting to delete a nonexistent instance.

        :returns: ``None``
        """
        self._delete(
            _instance.Instance, instance, ignore_missing=ignore_missing
        )

    @overload
    def find_instance(
        self,
        name_or_id: str,
        ignore_missing: Literal[False],
    ) -> _instance.Instance: ...

    @overload
    def find_instance(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _instance.Instance | None: ...

    def find_instance(
        self,
        name_or_id: str,
        ignore_missing: bool = True,
    ) -> _instance.Instance | None:
        """Find a single instance

        :param name_or_id: The name or ID of a instance.
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the resource does not exist.
            When set to ``True``, None will be returned when
            attempting to find a nonexistent resource.
        :returns: One :class:`~openstack.database.v1.instance.Instance` or None
        """
        return self._find(
            _instance.Instance, name_or_id, ignore_missing=ignore_missing
        )

    def get_instance(
        self, instance: str | _instance.Instance
    ) -> _instance.Instance:
        """Get a single instance

        :param instance: The value can be the ID of an instance or a
            :class:`~openstack.database.v1.instance.Instance`
            instance.

        :returns: One :class:`~openstack.database.v1.instance.Instance`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        return self._get(_instance.Instance, instance)

    def instances(
        self,
        **query: Any,
    ) -> Generator[_instance.Instance, None, None]:
        """Return a generator of instances

        :param query: Optional query parameters to be sent to limit
            the resources being returned.

        :returns: A generator of instance objects
        """
        return self._list(_instance.Instance, **query)

    def update_instance(
        self, instance: str | _instance.Instance, **attrs: Any
    ) -> _instance.Instance:
        """Update a instance

        :param instance: Either the id of a instance or a
            :class:`~openstack.database.v1.instance.Instance` instance.
        :param attrs: The attributes to update on the instance represented
            by ``instance``.

        :returns: The updated instance
        """
        return self._update(_instance.Instance, instance, **attrs)

    def create_user(
        self,
        instance: str | _instance.Instance,
        **attrs: Any,
    ) -> _user.User:
        """Create a new user from attributes

        :param instance: This can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
        :param attrs: Keyword arguments which will be used to create
            a :class:`~openstack.database.v1.user.User`,
            comprised of the properties on the User class.

        :returns: The results of server creation
        """
        instance = self._get_resource(_instance.Instance, instance)
        return self._create(_user.User, instance_id=instance.id, **attrs)

    def delete_user(
        self,
        user: str | _user.User,
        instance: str | _instance.Instance | None = None,
        ignore_missing: bool = True,
    ) -> None:
        """Delete a user

        :param user: The value can be either the ID of a user or a
            :class:`~openstack.database.v1.user.User` instance.
        :param instance: This parameter needs to be specified when
            an ID is given as `user`.
            It can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the user does not exist.
            When set to ``True``, no exception will be set when
            attempting to delete a nonexistent user.

        :returns: ``None``
        """
        instance = self._get_resource(_instance.Instance, instance)
        self._delete(
            _user.User,
            user,
            ignore_missing=ignore_missing,
            instance_id=instance.id,
        )

    @overload
    def find_user(
        self,
        name_or_id: str,
        instance: str | _instance.Instance,
        ignore_missing: Literal[False],
    ) -> _user.User: ...

    @overload
    def find_user(
        self,
        name_or_id: str,
        instance: str | _instance.Instance,
        ignore_missing: bool = True,
    ) -> _user.User | None: ...

    def find_user(
        self,
        name_or_id: str,
        instance: str | _instance.Instance,
        ignore_missing: bool = True,
    ) -> _user.User | None:
        """Find a single user

        :param name_or_id: The name or ID of a user.
        :param instance: This can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
        :param ignore_missing: When set to ``False``
            :class:`~openstack.exceptions.NotFoundException` will be
            raised when the resource does not exist.
            When set to ``True``, None will be returned when
            attempting to find a nonexistent resource.
        :returns: One :class:`~openstack.database.v1.user.User` or None
        """
        instance = self._get_resource(_instance.Instance, instance)
        return self._find(
            _user.User,
            name_or_id,
            instance_id=instance.id,
            ignore_missing=ignore_missing,
        )

    def users(
        self,
        instance: str | _instance.Instance,
        **query: Any,
    ) -> Generator[_user.User, None, None]:
        """Return a generator of users

        :param instance: This can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`
        :param query: Optional query parameters to be sent to limit
            the resources being returned.

        :returns: A generator of user objects
        """
        instance = self._get_resource(_instance.Instance, instance)
        return self._list(_user.User, instance_id=instance.id, **query)

    def get_user(
        self,
        user: str | _user.User,
        instance: str | _instance.Instance | None = None,
    ) -> _user.User:
        """Get a single user

        :param user: The value can be the ID of a user or a
            :class:`~openstack.database.v1.user.User` instance.
        :param instance: This parameter needs to be specified when
            an ID is given as `database`.
            It can be either the ID of an instance
            or a :class:`~openstack.database.v1.instance.Instance`

        :returns: One :class:`~openstack.database.v1.user.User`
        :raises: :class:`~openstack.exceptions.NotFoundException`
            when no resource can be found.
        """
        instance = self._get_resource(_instance.Instance, instance)
        return self._get(_user.User, user)

    # ========== Utilities ==========

    def wait_for_status(
        self,
        res: resource.ResourceT,
        status: str,
        failures: list[str] | None = None,
        interval: int | float | None = 2,
        wait: int | None = None,
        attribute: str = 'status',
        callback: Callable[[int], None] | None = None,
    ) -> resource.ResourceT:
        """Wait for the resource to be in a particular status.

        :param session: The session to use for making this request.
        :param resource: The resource to wait on to reach the status. The
            resource must have a status attribute specified via ``attribute``.
        :param status: Desired status of the resource.
        :param failures: Statuses that would indicate the transition
            failed such as 'ERROR'. Defaults to ['ERROR'].
        :param interval: Number of seconds to wait between checks.
        :param wait: Maximum number of seconds to wait for transition.
            Set to ``None`` to wait forever.
        :param attribute: Name of the resource attribute that contains the
            status.
        :param callback: A callback function. This will be called with a single
            value, progress. This is API specific but is generally a percentage
            value from 0-100.

        :returns: The updated resource.
        :raises: :class:`~openstack.exceptions.ResourceTimeout` if the
            transition to status failed to occur in ``wait`` seconds.
        :raises: :class:`~openstack.exceptions.ResourceFailure` if the resource
            transitioned to one of the states in ``failures``.
        :raises: :class:`~AttributeError` if the resource does not have a
            ``status`` attribute
        """
        return resource.wait_for_status(
            self, res, status, failures, interval, wait, attribute, callback
        )

    def wait_for_delete(
        self,
        res: resource.ResourceT,
        interval: int | float | None = 2,
        wait: int | None = 120,
        callback: Callable[[int], None] | None = None,
    ) -> resource.ResourceT:
        """Wait for a resource to be deleted.

        :param res: The resource to wait on to be deleted.
        :param interval: Number of seconds to wait before to consecutive
            checks.
        :param wait: Maximum number of seconds to wait before the change.
        :param callback: A callback function. This will be called with a single
            value, progress, which is a percentage value from 0-100.

        :returns: The resource is returned on success.
        :raises: :class:`~openstack.exceptions.ResourceTimeout` if transition
            to delete failed to occur in the specified seconds.
        """
        return resource.wait_for_delete(self, res, interval, wait, callback)
