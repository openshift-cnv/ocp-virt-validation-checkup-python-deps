# Copyright (c) 2006-2026 Broadcom. All Rights Reserved.
# The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.

# ******* WARNING - AUTO GENERATED CODE - DO NOT EDIT *******

import pyVmomi.VmomiSupport



class SessionManager(pyVmomi.VmomiSupport.ManagedObject):
   def LoginByToken(self, delegatedTokenXml: str) -> None: ...
   def Logout(self) -> None: ...
