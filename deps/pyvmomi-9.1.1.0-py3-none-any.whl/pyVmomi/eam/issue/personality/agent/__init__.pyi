# Copyright (c) 2006-2026 Broadcom. All Rights Reserved.
# The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.

# ******* WARNING - AUTO GENERATED CODE - DO NOT EDIT *******

import pyVmomi.eam.issue


class AwaitingPMRemediation(PMIssue):
   pass

class BlockedByAgencyOperation(PMIssue):
   pass


class PMIssue(pyVmomi.eam.issue.AgentIssue):
   pass
