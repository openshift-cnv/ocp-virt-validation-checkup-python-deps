# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import abc
from collections.abc import Callable
import logging
from typing import Any, cast, Generic, TYPE_CHECKING, TypeVar

import stevedore
from stevedore import extension

from keystoneauth1 import exceptions
from keystoneauth1 import plugin

if TYPE_CHECKING:
    from keystoneauth1.loading import base
    from keystoneauth1.loading import opts

PLUGIN_NAMESPACE = 'keystoneauth1.plugin'

LOG = logging.getLogger(__name__)


__all__ = (
    'get_available_plugin_names',
    'get_available_plugin_loaders',
    'get_plugin_loader',
    'get_plugin_options',
    'BaseLoader',
    'PLUGIN_NAMESPACE',
)

T = TypeVar('T', covariant=True)


def _auth_plugin_available(
    ext: extension.Extension['base.BaseLoader[Any]'],
) -> bool:
    """Read the value of available for whether to load this plugin."""
    assert ext.obj is not None
    return ext.obj.available


def _prefer_out_of_tree_plugin(
    namespace: str, name: str, extensions: list[extension.Extension[Any]]
) -> extension.Extension[Any]:
    """Resolve duplicate plugin entry points, preferring out-of-tree ones.

    keystoneauth1 ships in-tree loaders for some plugins that also have an
    out-of-tree implementation (e.g. ``v3websso``). When both are installed
    they register the same entry-point name; prefer the out-of-tree
    implementation so deployers can override the one we ship.
    """

    def _is_in_tree(ext: extension.Extension[Any]) -> bool:
        dist = ext.entry_point.dist
        if dist is not None:
            return dist.name == 'keystoneauth1'
        # distribution metadata missing: fall back to the module path
        return ext.entry_point_target.startswith('keystoneauth1.')

    out_of_tree = [ext for ext in extensions if not _is_in_tree(ext)]
    chosen = (out_of_tree or extensions)[-1]
    LOG.debug(
        "multiple implementations found for '%s' in %s; using %s",
        name,
        namespace,
        chosen.entry_point_target,
    )
    return chosen


def get_available_plugin_names() -> frozenset[str]:
    """Get the names of all the plugins that are available on the system.

    This is particularly useful for help and error text to prompt a user for
    example what plugins they may specify.

    :returns: A list of names.
    """
    mgr = stevedore.EnabledExtensionManager(
        namespace=PLUGIN_NAMESPACE,
        check_func=_auth_plugin_available,
        invoke_on_load=True,
        propagate_map_exceptions=True,
        conflict_resolver=_prefer_out_of_tree_plugin,
    )
    return frozenset(mgr.names())


def get_available_plugin_loaders() -> dict[
    str, 'BaseLoader[plugin.BaseAuthPluginT]'
]:
    """Retrieve all the plugin classes available on the system.

    :returns: A dict with plugin entrypoint name as the key and the plugin
        loader as the value.
    """
    mgr: stevedore.EnabledExtensionManager[BaseLoader[plugin.BaseAuthPluginT]]
    mgr = stevedore.EnabledExtensionManager(
        namespace=PLUGIN_NAMESPACE,
        check_func=_auth_plugin_available,
        invoke_on_load=True,
        propagate_map_exceptions=True,
        conflict_resolver=_prefer_out_of_tree_plugin,
    )

    # Access the extensions by name so stevedore applies the conflict resolver.
    # We know obj is not None since we passed invoke_on_load=True above.
    return {
        name: cast('BaseLoader[plugin.BaseAuthPluginT]', ext.obj)
        for name, ext in mgr.items()
    }


def get_plugin_loader(name: str) -> 'BaseLoader[plugin.BaseAuthPluginT]':
    """Retrieve a plugin class by its entrypoint name.

    :param name: The name of the object to get.
    :returns: An auth plugin class.
    :raises keystoneauth1.exceptions.auth_plugins.NoMatchingPlugin:
        if a plugin cannot be created.
    """
    try:
        mgr: stevedore.DriverManager[BaseLoader[plugin.BaseAuthPluginT]]
        mgr = stevedore.DriverManager(
            namespace=PLUGIN_NAMESPACE,
            invoke_on_load=True,
            name=name,
            conflict_resolver=_prefer_out_of_tree_plugin,
        )
    except RuntimeError:
        raise exceptions.NoMatchingPlugin(name)

    # NOTE(stephenfin): We know this will return an instance of the BaseLoader
    # rather than the class itself since we passed invoke_on_load=True above.
    # The hints in stevedore need work.
    return cast('BaseLoader[plugin.BaseAuthPluginT]', mgr.driver)


def get_plugin_options(name: str) -> list['opts.Opt']:
    """Get the options for a specific plugin.

    This will be the list of options that is registered and loaded by the
    specified plugin.

    :returns: A list of :py:class:`keystoneauth1.loading.Opt` options.

    :raises keystoneauth1.exceptions.auth_plugins.NoMatchingPlugin:
        if a plugin cannot be created.
    """
    return get_plugin_loader(name).get_options()


class _BaseLoader(Generic[T], metaclass=abc.ABCMeta):
    @property
    def plugin_class(self) -> type[T]:
        raise NotImplementedError()

    def create_plugin(self, **kwargs: Any) -> T:
        """Create a plugin from the options available for the loader.

        Given the options that were specified by the loader create an
        appropriate plugin. You can override this function in your loader.

        This used to be specified by providing the plugin_class property and
        this is still supported, however specifying a property didn't let you
        choose a plugin type based upon the options that were presented.

        Override this function if you wish to return different plugins based on
        the options presented, otherwise you can simply provide the
        plugin_class property.

        Added 2.9
        """
        return self.plugin_class(**kwargs)

    @abc.abstractmethod
    def get_options(self) -> list['opts.Opt']:
        """Return the list of parameters associated with the auth plugin.

        This list may be used to generate CLI or config arguments.

        :returns: A list of Param objects describing available plugin
                  parameters.
        """
        return []

    @property
    def available(self) -> bool:
        """Return if the plugin is available for loading.

        If a plugin is missing dependencies or for some other reason should not
        be available to the current system it should override this property and
        return False to exclude itself from the plugin list.

        :returns: True if the plugin is available for loading, else False.
        """
        return True

    def load_from_options(self, **kwargs: Any) -> T:
        """Create a plugin from the arguments retrieved from get_options.

        A client can override this function to do argument validation or to
        handle differences between the registered options and what is required
        to create the plugin.
        """
        missing_required = [
            o
            for o in self.get_options()
            if o.required and kwargs.get(o.dest) is None
        ]

        if missing_required:
            raise exceptions.MissingRequiredOptions(missing_required)

        return self.create_plugin(**kwargs)

    def load_from_options_getter(
        self, getter: Callable[['opts.Opt'], Any], **kwargs: Any
    ) -> T:
        """Load a plugin from getter function that returns appropriate values.

        To handle cases other than the provided CONF and CLI loading you can
        specify a custom loader function that will be queried for the option
        value.
        The getter is a function that takes a
        :py:class:`keystoneauth1.loading.Opt` and returns a value to load with.

        :param getter: A function that returns a value for the given opt.
        :returns: An authentication Plugin.
        """
        for opt in (o for o in self.get_options() if o.dest not in kwargs):
            val = getter(opt)
            if val is not None:
                val = opt.type(val)
            kwargs[opt.dest] = val

        return self.load_from_options(**kwargs)


class BaseLoader(_BaseLoader[plugin.BaseAuthPluginT]): ...
