# Resource class generator

Utility to add a python module with class resources to openshift-python-wrapper based on `kind`

Some resources have the same kind, in this case the script will create two files.
For example `DNS` kind have two CRDs, one from `config.openshift.io` and one from `operator.openshift.io`
The output will be:

- dns_operator_openshift_io.py
- dns_config_openshift_io.py

## Installation

Install [uv](https://github.com/astral-sh/uv)

```bash
 uv tool install openshift-python-wrapper
```

- Using `pip`

```bash
python3 -m pip install openshift-python-wrapper
```

For shell completion Add this to ~/.bashrc or ~/.zshrc:

```bash
if type class-generator > /dev/null; then eval "$(_CLASS_GENERATOR_COMPLETE=zsh_source class-generator)"; fi
```

## Usage

- All available options:

```bash
class-generator --help
```

### Generating classes for specific resources

- Running in normal mode with `--kind` flags:
  - `--kind` can process multiple kinds at the same command, pass `--kind <kind1>,<kind2>,<kind3>`

```bash
class-generator --kind <kind>
```

- Review the resource file; make sure that the filename and attribute names are named correctly. For example:
  - `OATH` -> `oath`
  - `CDIConfig` -> `cdi_config`

### Overwriting existing files

When regenerating or updating existing resource files, you can use the `--overwrite` flag along with `--backup` to create a backup of existing files before overwriting them:

```bash
class-generator --kind <kind> --overwrite --backup
```

This creates a timestamped backup in `.backups/backup-YYYYMMDD-HHMMSS/` preserving the original directory structure of your files.

### Batch regeneration with backup

When regenerating all resources, backups are also stored in the unified `.backups/` directory:

```bash
class-generator --regenerate-all --backup
```

All backups preserve the original directory structure, making it easy to restore specific files or entire directories if needed.

### Verifying generated files

To check whether existing resource files were produced by class-generator (i.e. match its current output), use the verify modes. No file is modified:

```bash
# Verify specific kinds
class-generator --verify --kind <kind1>,<kind2>

# Verify all generated resources (only files with the generated marker are checked)
class-generator --verify-all

# Verify only resources changed relative to the branch's base —
# use this to verify that PR/branch changes were produced by class-generator
class-generator --verify-changed [--base <ref>]

# Narrow the scope with a glob filter
class-generator --verify-all --filter 'Pod*'
```

The command exits with code `0` when all files match, and code `1` listing the drifted files otherwise. Each drifted file is reported with a unified diff and a drift classification: `blank lines`, `docstring add`/`docstring delete`, `code add`/`code delete` (lines regeneration would introduce/remove), `signature code add`/`signature code remove` (`__init__` parameters added/removed — additions are non-breaking because every generated parameter carries a default, removals are not), `breaking change` (a parameter was removed, so callers passing it get a `TypeError`), and `schema incomplete` (the rendered class lost every parameter, meaning a schema `$ref` could not be resolved — flagged in addition to, not instead of, `breaking change`). A drifted file was either hand-edited inside the generated markers, or the generator/template changed since it was last generated — regenerate it with `class-generator --kind <Kind> --overwrite` instead of editing it manually.

#### Filtering failures by classification

All verify modes accept `--classification` to report (and fail on) only drifted files matching the given classification(s), comma-separated:

```bash
# failed files whose drift includes blank-lines drift (possibly among others)
class-generator --verify-all --classification "blank lines"

# failed files whose drift is only blank lines and/or code add, nothing else
# (e.g. "blank lines" alone, "code add" alone, or both)
class-generator --verify-all --classification "blank lines,code add" --match
```

Without `--match`, a file matches when its drift contains **at least one** of the given classifications. With `--match`, the file's drift must be **within** the given set — every classification the file has must be one of the given ones; files with additional classifications are excluded. Drifted files hidden by the filter are counted in the summary but do not fail the run.

`--verify-changed` is the mode intended for PR review: it checks only the generated files the branch actually modified, so pre-existing drift in untouched files does not produce noise. The same check is available as a tox environment:

```bash
tox -e validate-generated
```

### Discovering missing resources

The class-generator can automatically discover resources in your cluster that don't have wrapper classes yet. Resource discovery runs in parallel for improved performance, typically reducing discovery time by 3-5x compared to sequential discovery.

- Discover missing resources and generate a coverage report:

```bash
class-generator --discover-missing
```

- Generate JSON output for CI/CD integration:

```bash
class-generator --discover-missing --json
```

- Disable caching to force fresh discovery:

```bash
class-generator --discover-missing --no-cache
```

Discovery results are cached for 24 hours in `~/.cache/openshift-python-wrapper/` to improve performance.

### Coverage Report Options

The coverage report provides detailed information about resource implementation status:

- **Total Discovered Resources**: All resources found in the cluster (including CRDs)
- **Total Implemented**: Number of Python wrapper classes in `ocp_resources/`
- **Covered Resources**: Resources that have corresponding wrapper classes
- **Total Missing**: Resources without wrapper implementations
- **Coverage Percentage**: Percentage of discovered resources that have implementations

Resources are prioritized as:
- **CORE**: Essential Kubernetes resources (v1 API group)
- **HIGH**: Common workload resources (apps/v1, batch/v1)
- **MEDIUM**: Platform-specific resources (OpenShift, operators)
- **LOW**: Custom resources and less common APIs

### Example output

```text
Resource Coverage Report

╭─────────────────────────── Coverage Statistics ────────────────────────────╮
│ Total Discovered Resources: 397                                             │
│ Total Implemented: 197                                                      │
│ Covered Resources: 172                                                      │
│ Total Missing: 225                                                          │
│ Coverage Percentage: 43.32%                                                 │
╰─────────────────────────────────────────────────────────────────────────────╯

Missing Resources (sorted by priority)

┏━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Priority   ┃ Kind                          ┃ API Version                   ┃ Namespaced ┃ Command                                         ┃
┡━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ CORE       │ Binding                       │ v1                            │ Yes        │ class-generator -k Binding                      │
│ CORE       │ ComponentStatus               │ v1                            │ No         │ class-generator -k ComponentStatus              │
│ HIGH       │ ControllerRevision            │ apps/v1                       │ Yes        │ class-generator -k ControllerRevision           │
│ HIGH       │ PodTemplate                   │ v1                            │ Yes        │ class-generator -k PodTemplate                  │
│ MEDIUM     │ ClusterResourceQuota          │ quota.openshift.io/v1         │ No         │ class-generator -k ClusterResourceQuota         │
└────────────┴───────────────────────────────┴───────────────────────────────┴────────────┴─────────────────────────────────────────────────┘

Tip: You can generate multiple resources at once:

  class-generator -k Binding,ComponentStatus,ControllerRevision
```

### Caching

Discovery results are cached for 24 hours to improve performance. Cache location: `~/.cache/openshift-python-wrapper/discovery_cache.json`

## Adding tests

- Add a new test for the provided `kind` by passing `--add-tests` flag
- Replace `Pod` with the kind you want to add to the tests

```bash
class-generator --kind Pod --add-tests
```

## Update schema files

Schema files contain resource definitions used by the class generator. You can update these from a connected Kubernetes/OpenShift cluster.

### Dependencies

- Kubernetes/OpenShift cluster
- [oc](https://mirror.openshift.com/pub/openshift-v4/x86_64/clients/ocp/stable/) or [kubectl](https://kubernetes.io/docs/tasks/tools/) (latest version)
- [uv](https://github.com/astral-sh/uv)

### Setup

Clone this repository:

```bash
git clone https://github.com/RedHatQE/openshift-python-wrapper.git
cd openshift-python-wrapper
```

Login to the cluster using admin user and password.

### Full schema update

Update the entire schema from the connected cluster:

```bash
class-generator --update-schema
```

This fetches all resource schemas from the cluster and updates the local cache.

**Note:** If connected to an older cluster, existing schemas are preserved and only missing resources are added.

### Single resource schema update

Update the schema for a single resource without affecting others:

```bash
class-generator --update-schema-for LlamaStackDistribution
```

This is useful when:

- Connected to an older cluster but need to update a specific CRD
- A new operator was installed and you need its resource schema
- You want to refresh just one resource without a full update

After updating the schema, regenerate the class:

```bash
class-generator --kind LlamaStackDistribution --overwrite
```

**Note:** `--update-schema` and `--update-schema-for` are mutually exclusive. Use one or the other, not both.
