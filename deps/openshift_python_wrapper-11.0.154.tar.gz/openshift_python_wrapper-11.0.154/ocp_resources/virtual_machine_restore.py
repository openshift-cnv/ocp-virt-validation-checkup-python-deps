from kubernetes.dynamic.exceptions import ResourceNotFoundError
from timeout_sampler import TimeoutSampler, TimeoutWatch

from ocp_resources.resource import NamespacedResource
from ocp_resources.utils.constants import PROTOCOL_ERROR_EXCEPTION_DICT, TIMEOUT_4MINUTES
from ocp_resources.virtual_machine import VirtualMachine


class VirtualMachineRestore(NamespacedResource):
    """
    VirtualMachineRestore object.
    """

    api_group = NamespacedResource.ApiGroup.SNAPSHOT_KUBEVIRT_IO

    def __init__(
        self,
        name=None,
        namespace=None,
        vm_name=None,
        snapshot_name=None,
        teardown=True,
        yaml_file=None,
        delete_timeout=TIMEOUT_4MINUTES,
        volume_restore_policy=None,
        **kwargs,
    ):
        super().__init__(
            name=name,
            namespace=namespace,
            teardown=teardown,
            yaml_file=yaml_file,
            delete_timeout=delete_timeout,
            **kwargs,
        )
        self.vm_name = vm_name
        self.snapshot_name = snapshot_name
        self.volume_restore_policy = volume_restore_policy

    def to_dict(self) -> None:
        super().to_dict()
        if not self.kind_dict and not self.yaml_file:
            spec = self.res.setdefault("spec", {})
            spec.setdefault("target", {})["apiGroup"] = NamespacedResource.ApiGroup.KUBEVIRT_IO
            spec["target"]["kind"] = VirtualMachine.kind
            spec["target"]["name"] = self.vm_name
            spec["virtualMachineSnapshotName"] = self.snapshot_name
            if self.volume_restore_policy:
                spec["volumeRestorePolicy"] = self.volume_restore_policy

    def wait_complete(self, status=True, timeout=TIMEOUT_4MINUTES):
        """
        Wait for VirtualMachineRestore to be in status complete

        Args:
            status: Expected status: True for a completed restore operation, False otherwise.
            timeout (int): Time to wait.

        Raises:
            TimeoutExpiredError: If timeout reached.
        """
        self.logger.info(f"Wait for {self.kind} {self.name} status to be complete = {status}")

        timeout_watcher = TimeoutWatch(timeout=timeout)
        for sample in TimeoutSampler(
            wait_timeout=timeout,
            sleep=1,
            func=lambda: self.exists,
        ):
            if sample:
                break

        samples = TimeoutSampler(
            wait_timeout=timeout_watcher.remaining_time(),
            sleep=1,
            exceptions_dict=PROTOCOL_ERROR_EXCEPTION_DICT,
            func=lambda: self.instance.get("status", {}).get("complete") == status,
        )
        for sample in samples:
            if sample:
                return

    def wait_restore_done(self, timeout=TIMEOUT_4MINUTES):
        """
        Wait for the the restore to be done. This check 2 parameters, the restore status to be complete
        and the VM status restoreInProgress to be None.

        Args:
            timeout (int): Time to wait.

        Raises:
            TimeoutExpiredError: If timeout reached.
        """
        self.wait_complete(timeout=timeout)

        vm = VirtualMachine(
            client=self.client,
            namespace=self.namespace,
            name=self.vm_name,
        )

        if vm.exists:
            return vm.wait_for_status_none(status="restoreInProgress", timeout=timeout)
        raise ResourceNotFoundError(f"VirtualMachine: {vm.name} not found")
