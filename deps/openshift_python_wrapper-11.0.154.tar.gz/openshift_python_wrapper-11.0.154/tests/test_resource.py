import os
from unittest.mock import patch

import kubernetes
import pytest
import yaml

from fake_kubernetes_client.dynamic_client import FakeDynamicClient
from ocp_resources.event import Event
from ocp_resources.exceptions import MissingClientError, ResourceTeardownError
from ocp_resources.namespace import Namespace
from ocp_resources.pod import Pod
from ocp_resources.resource import NamespacedResourceList, Resource, ResourceList
from ocp_resources.secret import Secret
from ocp_resources.utils.client_config import resolve_bearer_token, save_kubeconfig

BASE_NAMESPACE_NAME: str = "test-namespace"
BASE_POD_NAME: str = "test-pod"
POD_CONTAINERS: list[dict[str, str]] = [{"name": "test-container", "image": "nginx:latest"}]


class SecretTestExit(Secret):
    def deploy(self, wait: bool = False):
        return self

    def clean_up(self, wait: bool = True, timeout: int | None = None) -> bool:
        return False


@pytest.fixture(scope="class")
def namespace(fake_client):
    return Namespace(client=fake_client, name=BASE_NAMESPACE_NAME)


@pytest.fixture(scope="class")
def namespaces(fake_client):
    return ResourceList(client=fake_client, resource_class=Namespace, num_resources=3, name=BASE_NAMESPACE_NAME)


@pytest.fixture(scope="class")
def pod(fake_client):
    # Create a test pod for testing purposes
    test_pod = Pod(
        client=fake_client,
        name=BASE_POD_NAME,
        namespace="default",
        containers=POD_CONTAINERS,
        annotations={"fake-client.io/ready": "false"},  # Create pod with Ready status FALSE
    )
    deployed_pod = test_pod.deploy()
    yield deployed_pod
    # Cleanup after tests
    test_pod.clean_up()


@pytest.fixture(scope="class")
def pods(fake_client, namespaces):
    return NamespacedResourceList(
        client=fake_client,
        resource_class=Pod,
        namespaces=namespaces,
        name=BASE_POD_NAME,
        containers=POD_CONTAINERS,
    )


@pytest.mark.incremental
class TestResource:
    def test_get(self, fake_client):
        for ns in Namespace.get(client=fake_client):
            assert ns.name

    def test_create(self, namespace):
        ns = namespace.deploy()
        assert ns

    def test_kind(self, namespace):
        assert namespace.kind == "Namespace"

    def test_exists(self, namespace):
        assert namespace.exists

    def test_instance(self, namespace):
        assert namespace.instance

    def test_wait_for_condition(self, pod):
        pod.wait_for_condition(condition=pod.Condition.READY, status=pod.Condition.Status.FALSE, timeout=5)

    def test_wait_for_conditions(self, pod):
        pod.wait_for_conditions()

    def test_events(self, pod):
        events = list(pod.events(timeout=1))
        assert events

    def test_get_all_cluster_resources(self, fake_client):
        for _resources in Resource.get_all_cluster_resources(client=fake_client):
            if _resources:
                break

    def test_client_is_required(self, fake_client: FakeDynamicClient) -> None:
        # All client guards are eager: they raise at call time, before any iteration.
        with pytest.raises(TypeError, match="client"):
            Pod(name=BASE_POD_NAME, namespace="default", containers=POD_CONTAINERS)

        with pytest.raises(MissingClientError, match="client is required"):
            Pod(client=None, name=BASE_POD_NAME, namespace="default", containers=POD_CONTAINERS)  # type: ignore[arg-type]

        with pytest.raises(TypeError, match="client"):
            Namespace.get()

        with pytest.raises(MissingClientError, match="client is required"):
            Namespace.get(client=None)  # type: ignore[arg-type]

        with pytest.raises(TypeError, match="client"):
            Resource.get_all_cluster_resources()

        # get_all_cluster_resources validates eagerly even though it returns a generator
        with pytest.raises(MissingClientError, match="client is required"):
            Resource.get_all_cluster_resources(client=None)  # type: ignore[arg-type]

        # NamespacedResource.get is a separate override with its own client guard
        with pytest.raises(TypeError, match="client"):
            Pod.get()

        with pytest.raises(MissingClientError, match="client is required"):
            Pod.get(client=None)  # type: ignore[arg-type]

        # Valid construction still works with an explicit client
        pod = Pod(client=fake_client, name=BASE_POD_NAME, namespace="default", containers=POD_CONTAINERS)
        assert pod.client is fake_client

    def test_missing_client_error_is_type_error_subclass(self) -> None:
        """Callers do `except TypeError`, so the exception must stay a TypeError subclass."""
        assert issubclass(MissingClientError, TypeError)

    def test_removed_client_kwargs_rejected(self, fake_client: FakeDynamicClient) -> None:
        with pytest.raises(TypeError, match="Unsupported argument"):
            Namespace.get(client=fake_client, dyn_client=fake_client)

        with pytest.raises(TypeError, match="Unsupported argument"):
            # value is an arbitrary placeholder; the kwarg name triggers rejection
            Namespace.get(client=fake_client, config_file="kubeconfig")

        with pytest.raises(TypeError, match="Unsupported argument"):
            Resource.get_all_cluster_resources(client=fake_client, context="default")

        with pytest.raises(TypeError, match="Unsupported argument"):
            Resource.get_all_cluster_resources(client=fake_client, config_dict={})

        # Namespace.get uses * in its signature; Python rejects extra positional args
        with pytest.raises(TypeError, match="positional"):
            Namespace.get(fake_client, fake_client)

        # get_all_cluster_resources takes client as its only positional argument
        with pytest.raises(TypeError, match="positional"):
            Resource.get_all_cluster_resources(fake_client, "extra")

        # Constructors reject removed client kwargs with the migration hint
        with pytest.raises(TypeError, match="Unsupported argument"):
            Pod(
                client=fake_client,
                name=BASE_POD_NAME,
                namespace="default",
                containers=POD_CONTAINERS,
                dyn_client=fake_client,
            )

        # Unknown kwargs are rejected by name, naming the instantiated class
        with pytest.raises(TypeError, match="Pod.*unexpected keyword argument"):
            Pod(client=fake_client, name=BASE_POD_NAME, namespace="default", bogus_kwarg=True)

    def test_event_client_is_required(self) -> None:
        with pytest.raises(TypeError, match="client"):
            Event.get()

        # Event.get returns a generator but validates the client eagerly
        with pytest.raises(MissingClientError, match="client is required"):
            Event.get(client=None)  # type: ignore[arg-type]

        with pytest.raises(TypeError, match="client"):
            Event.list()

        with pytest.raises(MissingClientError, match="client is required"):
            Event.list(client=None)  # type: ignore[arg-type]

        with pytest.raises(TypeError, match="client"):
            Event.delete_events()

        with pytest.raises(MissingClientError, match="client is required"):
            Event.delete_events(client=None)  # type: ignore[arg-type]

    def test_get_condition_message(self, pod):
        assert pod.get_condition_message(
            condition_type=pod.Condition.READY, condition_status=pod.Condition.Status.FALSE
        )

    def test_wait(self, namespace):
        namespace.wait_for_status(status=Namespace.Status.ACTIVE, timeout=30)

    def test_status(self, namespace):
        assert namespace.status == Namespace.Status.ACTIVE

    def test_update(self, namespace):
        ns_dict = namespace.instance.to_dict()
        ns_dict["metadata"]["labels"].update({"test": "test"})
        namespace.update(resource_dict=ns_dict)
        assert namespace.labels["test"] == "test"

    def test_update_replace(self, namespace):
        ns_dict = namespace.instance.to_dict()
        ns_dict["metadata"]["labels"].pop("test")
        namespace.update_replace(resource_dict=ns_dict)
        assert "test" not in namespace.labels.keys()

    def test_cleanup(self, namespace):
        namespace.clean_up(wait=False)

    def test_resource_context_manager(self, fake_client):
        with Secret(name="test-context-manager", namespace="default", client=fake_client) as sec:
            pass

        assert not sec.exists

    def test_resource_context_manager_exit(self, fake_client):
        with pytest.raises(ResourceTeardownError):
            with SecretTestExit(name="test-context-manager-exit", namespace="default", client=fake_client):
                pass


@pytest.mark.incremental
class TestResourceList:
    def test_resource_list_deploy(self, namespaces):
        namespaces.deploy()
        assert namespaces

    def test_resource_list_len(self, namespaces):
        assert len(namespaces) == 3

    def test_resource_list_name(self, namespaces):
        for i, ns in enumerate(namespaces.resources, start=1):
            assert ns.name == f"{BASE_NAMESPACE_NAME}-{i}"

    def test_resource_list_teardown(self, namespaces):
        namespaces.clean_up(wait=False)

    def test_resource_list_context_manager(self, fake_client):
        with ResourceList(
            client=fake_client, resource_class=Namespace, name=BASE_NAMESPACE_NAME, num_resources=3
        ) as namespaces:
            assert namespaces


@pytest.mark.incremental
class TestNamespacedResourceList:
    def test_namespaced_resource_list_deploy(self, fake_client, pods):
        pods.deploy()
        assert pods

    def test_resource_list_len(self, namespaces, pods):
        assert len(pods) == len(namespaces)

    def test_resource_list_name(self, pods):
        for pod in pods.resources:
            assert pod.name == BASE_POD_NAME

    def test_namespaced_resource_list_namespace(self, namespaces, pods):
        for pod, namespace in zip(pods.resources, namespaces, strict=False):
            assert pod.namespace == namespace.name

    def test_resource_list_teardown(self, pods):
        pods.clean_up(wait=False)

    def test_namespaced_resource_list_context_manager(self, fake_client, namespaces):
        with NamespacedResourceList(
            client=fake_client,
            resource_class=Pod,
            namespaces=namespaces,
            name=BASE_POD_NAME,
            containers=POD_CONTAINERS,
        ) as pods:
            assert pods


@pytest.mark.xfail(reason="Need debug")
class TestClientProxy:
    @patch.dict(os.environ, {"HTTP_PROXY": "http://env-http-proxy.com"})
    def test_client_with_proxy(self, fake_client):
        http_proxy = "http://env-http-proxy.com"

        assert fake_client.configuration.proxy == http_proxy

    @patch.dict(os.environ, {"HTTP_PROXY": "http://env-http-proxy.com"})
    @patch.dict(os.environ, {"HTTPS_PROXY": "http://env-https-proxy.com"})
    def test_proxy_precedence(self, fake_client):
        https_proxy = "https://env-https-proxy.com"

        # Verify HTTPS_PROXY takes precedence over HTTP_PROXY
        assert fake_client.configuration.proxy == https_proxy


class TestSaveKubeconfig:
    def test_save_kubeconfig_with_host_and_token(self):
        host = "https://api.test-cluster.example.com:6443"
        token = "sha256~test-token-value"  # noqa: S105

        kubeconfig_path = save_kubeconfig(host=host, token=token, verify_ssl=False)
        try:
            assert os.path.exists(kubeconfig_path)
            assert os.stat(kubeconfig_path).st_mode & 0o777 == 0o600

            with open(kubeconfig_path) as f:
                config = yaml.safe_load(f)

            assert config["clusters"][0]["cluster"]["server"] == host
            assert config["clusters"][0]["cluster"]["insecure-skip-tls-verify"] is True
            assert config["users"][0]["user"]["token"] == token
            assert config["current-context"] == "context"
        finally:
            os.unlink(kubeconfig_path)

    def test_save_kubeconfig_with_config_dict(self):
        config_dict = {
            "apiVersion": "v1",
            "kind": "Config",
            "clusters": [{"name": "my-cluster", "cluster": {"server": "https://my-server:6443"}}],
            "users": [{"name": "my-user", "user": {"token": "my-token"}}],
            "contexts": [{"name": "my-context", "context": {"cluster": "my-cluster", "user": "my-user"}}],
            "current-context": "my-context",
        }

        kubeconfig_path = save_kubeconfig(config_dict=config_dict)
        try:
            with open(kubeconfig_path) as f:
                saved_config = yaml.safe_load(f)

            assert saved_config == config_dict
        finally:
            os.unlink(kubeconfig_path)

    def test_save_kubeconfig_insufficient_data(self):
        with pytest.raises(ValueError, match="Not enough data to build kubeconfig"):
            save_kubeconfig()

    def test_save_kubeconfig_file_permissions(self):
        _test_token = "test-token"  # noqa: S105

        kubeconfig_path = save_kubeconfig(host="https://api.example.com:6443", token=_test_token)
        try:
            assert os.stat(kubeconfig_path).st_mode & 0o777 == 0o600
        finally:
            os.unlink(kubeconfig_path)

    def test_save_kubeconfig_verify_ssl_not_false(self):
        _test_token = "test-token"  # noqa: S105

        kubeconfig_path_true = save_kubeconfig(host="https://api.example.com:6443", token=_test_token, verify_ssl=True)
        try:
            with open(kubeconfig_path_true) as f:
                config_true = yaml.safe_load(f)

            assert "insecure-skip-tls-verify" not in config_true["clusters"][0]["cluster"]
        finally:
            os.unlink(kubeconfig_path_true)

        kubeconfig_path_none = save_kubeconfig(host="https://api.example.com:6443", token=_test_token, verify_ssl=None)
        try:
            with open(kubeconfig_path_none) as f:
                config_none = yaml.safe_load(f)
        finally:
            os.unlink(kubeconfig_path_none)

        assert "insecure-skip-tls-verify" not in config_none["clusters"][0]["cluster"]

    def testresolve_bearer_token_from_api_key(self):
        """Test that resolve_bearer_token extracts token from Bearer api_key."""
        cfg = kubernetes.client.Configuration()
        cfg.api_key = {"authorization": "Bearer sha256~oauth-resolved-token"}  # noqa: S105
        result = resolve_bearer_token(token=None, client_configuration=cfg)
        assert result == "sha256~oauth-resolved-token"

    def testresolve_bearer_token_explicit_takes_precedence(self):
        """Test that an explicit token takes precedence over Bearer in api_key."""
        cfg = kubernetes.client.Configuration()
        cfg.api_key = {"authorization": "Bearer sha256~oauth-token"}  # noqa: S105
        explicit_token = "explicit-token"  # noqa: S105
        result = resolve_bearer_token(token=explicit_token, client_configuration=cfg)
        assert result == "explicit-token"

    def testresolve_bearer_token_no_bearer_prefix(self):
        """Test that api_key without Bearer prefix does not resolve a token."""
        cfg = kubernetes.client.Configuration()
        cfg.api_key = {"authorization": "Basic some-basic-auth"}
        result = resolve_bearer_token(token=None, client_configuration=cfg)
        assert result is None

    def testresolve_bearer_token_empty_api_key(self):
        """Test that empty api_key does not resolve a token."""
        cfg = kubernetes.client.Configuration()
        cfg.api_key = {}
        result = resolve_bearer_token(token=None, client_configuration=cfg)
        assert result is None

    def test_save_kubeconfig_write_failure(self):
        _test_token = "test-token"  # noqa: S105

        with pytest.raises(OSError, match="Permission denied"):
            with patch(
                "ocp_resources.utils.client_config.tempfile.mkstemp",
                side_effect=OSError("Permission denied"),
            ):
                save_kubeconfig(host="https://api.example.com:6443", token=_test_token)
