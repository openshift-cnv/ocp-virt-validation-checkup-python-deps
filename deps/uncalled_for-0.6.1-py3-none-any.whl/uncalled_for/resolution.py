"""Dependency resolution: resolving, wrapping, and failure handling."""

from __future__ import annotations

import inspect
from collections.abc import AsyncGenerator, Callable
from contextlib import AsyncExitStack, asynccontextmanager
from functools import lru_cache
from typing import Any

from .annotations import get_annotation_dependencies
from .frames import frame_scope
from .functional import _Depends  # pyright: ignore[reportPrivateUsage]
from .introspection import get_dependency_parameters, get_signature
from .references import get_call_argument_parameters


class FailedDependency:
    """Placeholder for a dependency that raised during resolution."""

    def __init__(self, parameter: str, error: Exception) -> None:
        self.parameter = parameter
        self.error = error


@asynccontextmanager
async def resolved_dependencies(
    function: Callable[..., Any],
    kwargs: dict[str, Any] | None = None,
) -> AsyncGenerator[dict[str, Any]]:
    """Resolve all dependencies declared on a function's signature.

    Yields a dict mapping parameter names to resolved values. Dependencies
    are entered as async context managers and cleaned up when the context
    exits.

    Parameters already present in *kwargs* are passed through without
    resolution, allowing callers to override specific dependencies.
    """
    provided = kwargs or {}
    cache_token = _Depends.cache.set({})

    try:
        async with AsyncExitStack() as stack:
            stack_token = _Depends.stack.set(stack)
            try:
                with frame_scope(function, provided) as frame:
                    arguments: dict[str, Any] = {}

                    for parameter in get_dependency_parameters(function):
                        try:
                            arguments[parameter] = await frame.resolve(parameter)
                        except Exception as error:
                            arguments[parameter] = FailedDependency(parameter, error)

                    annotation_dependencies = get_annotation_dependencies(function)
                    for parameter_name, dependencies in annotation_dependencies.items():
                        value = provided.get(
                            parameter_name, arguments.get(parameter_name)
                        )
                        for dependency in dependencies:
                            bound = dependency.bind_to_parameter(parameter_name, value)
                            await stack.enter_async_context(bound)

                    yield arguments
            finally:
                _Depends.stack.reset(stack_token)
    finally:
        _Depends.cache.reset(cache_token)


@lru_cache(maxsize=5_000)
def without_dependencies(function: Callable[..., Any]) -> Callable[..., Any]:
    """Produce a wrapper whose signature hides dependency parameters.

    If *function* has no ``Dependency`` defaults, it is returned unchanged.
    Otherwise an async wrapper is returned that resolves dependencies
    automatically and forwards user-supplied keyword arguments.

    The wrapper's signature also gains the parameters from
    ``get_call_argument_parameters``. Their values reach the dependencies that
    reference them, never *function* itself.
    """
    dependency_names = set(get_dependency_parameters(function))
    annotation_dependencies = get_annotation_dependencies(function)
    if not dependency_names and not annotation_dependencies:
        return function

    referenced = get_call_argument_parameters(function)
    referenced_names = {parameter.name for parameter in referenced}

    original_signature = get_signature(function)
    filtered_parameters = [
        p
        for name, p in original_signature.parameters.items()
        if name not in dependency_names
    ]
    variadic = [
        p for p in filtered_parameters if p.kind is inspect.Parameter.VAR_KEYWORD
    ]
    filtered_parameters = [
        p for p in filtered_parameters if p.kind is not inspect.Parameter.VAR_KEYWORD
    ]
    new_signature = original_signature.replace(
        parameters=[*filtered_parameters, *referenced, *variadic],
        return_annotation=inspect.Parameter.empty,
    )

    is_async = inspect.iscoroutinefunction(function)

    async def wrapper(**kwargs: Any) -> Any:
        async with resolved_dependencies(function, kwargs) as resolved:
            all_kwargs = {
                name: value
                for name, value in {**resolved, **kwargs}.items()
                if name not in referenced_names
            }
            if is_async:
                return await function(**all_kwargs)
            return function(**all_kwargs)

    wrapper.__name__ = function.__name__
    wrapper.__doc__ = function.__doc__
    wrapper.__signature__ = new_signature  # type: ignore[attr-defined]
    wrapper.__annotations__ = {
        k: v
        for k, v in function.__annotations__.items()
        if k not in dependency_names and k != "return"
    } | {parameter.name: parameter.annotation for parameter in referenced}

    return wrapper
